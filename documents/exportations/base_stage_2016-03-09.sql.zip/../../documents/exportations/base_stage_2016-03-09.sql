-- -----------------------------
-- creation de la table competence
-- -----------------------------
CREATE TABLE `competence` (
  `idcompetence` int(10) NOT NULL AUTO_INCREMENT,
  `nomcompetence` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`idcompetence`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table contact
-- -----------------------------
CREATE TABLE `contact` (
  `idcontact` int(10) NOT NULL AUTO_INCREMENT,
  `nomcontact` varchar(100) NOT NULL DEFAULT '',
  `prenomcontact` varchar(100) NOT NULL DEFAULT '',
  `telephone` varchar(20) NOT NULL,
  `telecopie` varchar(20) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `identreprise` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idcontact`),
  KEY `foreign_key_contact_identreprise` (`identreprise`)
) ENGINE=MyISAM AUTO_INCREMENT=715 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table convention
-- -----------------------------
CREATE TABLE `convention` (
  `idconvention` int(10) NOT NULL AUTO_INCREMENT,
  `sujetdestage` mediumtext NOT NULL,
  `asonresume` tinyint(4) NOT NULL DEFAULT '0',
  `note` decimal(4,2) NOT NULL DEFAULT '0.00',
  `idparrain` int(10) DEFAULT NULL,
  `idexaminateur` int(10) DEFAULT NULL,
  `idetudiant` int(10) NOT NULL DEFAULT '0',
  `idsoutenance` int(10) DEFAULT NULL,
  `idcontact` int(10) DEFAULT NULL,
  `idtheme` int(10) NOT NULL,
  PRIMARY KEY (`idconvention`),
  KEY `foreign_key_convention_idparrain` (`idparrain`),
  KEY `foreign_key_convention_idetudiant` (`idetudiant`),
  KEY `foreign_key_convention_idsoutenance` (`idsoutenance`),
  KEY `foreign_key_convention_idcontact` (`idcontact`),
  KEY `foreign_key_convention_idexaminateur` (`idexaminateur`)
) ENGINE=MyISAM AUTO_INCREMENT=461 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table couleur
-- -----------------------------
CREATE TABLE `couleur` (
  `idcouleur` int(10) NOT NULL AUTO_INCREMENT,
  `nomcouleur` varchar(100) NOT NULL,
  `codehexa` varchar(6) NOT NULL DEFAULT '000000',
  PRIMARY KEY (`idcouleur`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table datesoutenance
-- -----------------------------
CREATE TABLE `datesoutenance` (
  `iddatesoutenance` int(10) NOT NULL AUTO_INCREMENT,
  `jour` int(2) NOT NULL DEFAULT '0',
  `mois` int(2) NOT NULL DEFAULT '0',
  `annee` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`iddatesoutenance`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table entreprise
-- -----------------------------
CREATE TABLE `entreprise` (
  `identreprise` int(10) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL DEFAULT '',
  `adresse` varchar(100) NOT NULL DEFAULT '',
  `codepostal` varchar(8) NOT NULL DEFAULT '',
  `ville` varchar(100) NOT NULL DEFAULT '',
  `pays` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '""',
  `idtypeentreprise` int(10) NOT NULL,
  PRIMARY KEY (`identreprise`)
) ENGINE=MyISAM AUTO_INCREMENT=448 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table etudiant
-- -----------------------------
CREATE TABLE `etudiant` (
  `idetudiant` int(10) NOT NULL AUTO_INCREMENT,
  `nometudiant` varchar(100) NOT NULL DEFAULT '',
  `prenometudiant` varchar(100) NOT NULL DEFAULT '',
  `email_institutionnel` varchar(200) NOT NULL DEFAULT '',
  `email_personnel` varchar(200) DEFAULT NULL,
  `codeetudiant` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`idetudiant`)
) ENGINE=MyISAM AUTO_INCREMENT=381 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table filiere
-- -----------------------------
CREATE TABLE `filiere` (
  `idfiliere` int(10) NOT NULL AUTO_INCREMENT,
  `nomfiliere` varchar(50) NOT NULL DEFAULT '',
  `temps_soutenance` int(3) NOT NULL DEFAULT '20',
  `affDepot` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idfiliere`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table fluxrss
-- -----------------------------
CREATE TABLE `fluxrss` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `link` mediumtext NOT NULL,
  `timestamp` int(12) NOT NULL DEFAULT '0',
  `contents` mediumtext NOT NULL,
  `author` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table offredestage
-- -----------------------------
CREATE TABLE `offredestage` (
  `idoffre` int(10) NOT NULL AUTO_INCREMENT,
  `sujet` mediumtext NOT NULL,
  `titre` varchar(120) NOT NULL DEFAULT '',
  `listeenvironnement` mediumtext NOT NULL,
  `dureemin` varchar(50) NOT NULL DEFAULT '',
  `dureemax` varchar(50) NOT NULL DEFAULT '',
  `indemnite` double NOT NULL DEFAULT '0',
  `remarques` mediumtext NOT NULL,
  `estVisible` tinyint(4) NOT NULL DEFAULT '0',
  `idcontact` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idoffre`),
  KEY `foreign_key_offredestage_idcontact` (`idcontact`)
) ENGINE=MyISAM AUTO_INCREMENT=377 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table parcours
-- -----------------------------
CREATE TABLE `parcours` (
  `idparcours` int(10) NOT NULL AUTO_INCREMENT,
  `nomparcours` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`idparcours`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table parrain
-- -----------------------------
CREATE TABLE `parrain` (
  `idparrain` int(10) NOT NULL AUTO_INCREMENT,
  `nomparrain` varchar(100) NOT NULL DEFAULT '',
  `prenomparrain` varchar(100) NOT NULL DEFAULT '',
  `emailparrain` varchar(200) NOT NULL DEFAULT '',
  `idcouleur` int(10) DEFAULT NULL,
  PRIMARY KEY (`idparrain`),
  KEY `foreign_key_couleur_idcouleur` (`idcouleur`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table profilsouhaite_offredestage
-- -----------------------------
CREATE TABLE `profilsouhaite_offredestage` (
  `idoffre` int(10) NOT NULL DEFAULT '0',
  `idfiliere` int(10) NOT NULL DEFAULT '0',
  KEY `foreign_key_theme_offreDeStage_idfiliere` (`idfiliere`),
  KEY `foreign_key_theme_offreDeStage_idoffre` (`idoffre`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table promotion
-- -----------------------------
CREATE TABLE `promotion` (
  `idpromotion` int(10) NOT NULL AUTO_INCREMENT,
  `anneeuniversitaire` int(10) NOT NULL DEFAULT '0',
  `idparcours` int(10) DEFAULT NULL,
  `idfiliere` int(10) DEFAULT NULL,
  `email_promotion` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`idpromotion`),
  KEY `foreign_key_promotion_idfiliere` (`idfiliere`),
  KEY `foreign_key_promotion_idparcours` (`idparcours`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table relation_competence_offredestage
-- -----------------------------
CREATE TABLE `relation_competence_offredestage` (
  `idcompetence` int(10) NOT NULL DEFAULT '0',
  `idoffre` int(10) NOT NULL DEFAULT '0',
  KEY `foreign_key_relation_competence_offreDeStage_idcompetence` (`idcompetence`),
  KEY `foreign_key_relation_competence_offreDeStage_idoffre` (`idoffre`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table relation_promotion_datesoutenance
-- -----------------------------
CREATE TABLE `relation_promotion_datesoutenance` (
  `iddatesoutenance` int(10) NOT NULL DEFAULT '0',
  `idpromotion` int(10) NOT NULL DEFAULT '0',
  KEY `foreign_key_relation_promotion_dateSoutance_iddatesoutenance` (`iddatesoutenance`),
  KEY `foreign_key_relation_promotion_dateSoutance_idpromotion` (`idpromotion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table relation_promotion_etudiant_convention
-- -----------------------------
CREATE TABLE `relation_promotion_etudiant_convention` (
  `idetudiant` int(10) NOT NULL DEFAULT '0',
  `idconvention` int(10) DEFAULT '0',
  `idpromotion` int(10) NOT NULL DEFAULT '0',
  KEY `foreign_key_relation_promotion_etudiant_convention_idetudiant` (`idetudiant`),
  KEY `foreign_key_relation_promotion_etudiant_convention_idconvention` (`idconvention`),
  KEY `foreign_key_relation_promotion_etudiant_convention_idpromotion` (`idpromotion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table salle_soutenance
-- -----------------------------
CREATE TABLE `salle_soutenance` (
  `idsalle` int(10) NOT NULL AUTO_INCREMENT,
  `nomsalle` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`idsalle`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table soutenances
-- -----------------------------
CREATE TABLE `soutenances` (
  `idsoutenance` int(10) NOT NULL AUTO_INCREMENT,
  `heuredebut` int(2) NOT NULL DEFAULT '0',
  `mindebut` int(2) NOT NULL DEFAULT '0',
  `ahuitclos` tinyint(4) NOT NULL DEFAULT '0',
  `iddatesoutenance` int(10) DEFAULT NULL,
  `idsalle` int(10) DEFAULT NULL,
  PRIMARY KEY (`idsoutenance`),
  KEY `foreign_key_soutenances_idsalle` (`idsalle`),
  KEY `foreign_key_soutenances_iddatesoutenance` (`iddatesoutenance`)
) ENGINE=MyISAM AUTO_INCREMENT=484 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table sujetdestage
-- -----------------------------
CREATE TABLE `sujetdestage` (
  `idsujetdestage` int(10) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `valide` tinyint(4) NOT NULL DEFAULT '0',
  `enattente` tinyint(4) NOT NULL DEFAULT '0',
  `idetudiant` int(10) NOT NULL DEFAULT '0',
  `idpromotion` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idsujetdestage`),
  KEY `foreign_key_sujetdestage_idetudiant` (`idetudiant`)
) ENGINE=MyISAM AUTO_INCREMENT=298 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table taches
-- -----------------------------
CREATE TABLE `taches` (
  `idtache` int(10) NOT NULL AUTO_INCREMENT,
  `intitule` varchar(100) NOT NULL,
  `statut` varchar(20) NOT NULL DEFAULT 'Pas fait',
  `priorite` mediumint(9) NOT NULL DEFAULT '0',
  `datelimite` date NOT NULL,
  PRIMARY KEY (`idtache`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table theme_destage
-- -----------------------------
CREATE TABLE `theme_destage` (
  `idtheme` int(10) NOT NULL AUTO_INCREMENT,
  `theme` varchar(20) NOT NULL,
  `idcouleur` int(10) DEFAULT NULL,
  PRIMARY KEY (`idtheme`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table theme_offredestage
-- -----------------------------
CREATE TABLE `theme_offredestage` (
  `idparcours` int(10) NOT NULL DEFAULT '0',
  `idoffre` int(10) NOT NULL DEFAULT '0',
  KEY `foreign_key_profilSouhaite_offreDeStage_idoffre` (`idoffre`),
  KEY `foreign_key_profilSouhaite_offreDeStage_idparcours` (`idparcours`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- creation de la table type_entreprise
-- -----------------------------
CREATE TABLE `type_entreprise` (
  `idtypeentreprise` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `idcouleur` int(10) DEFAULT NULL,
  PRIMARY KEY (`idtypeentreprise`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;



-- -----------------------------
-- insertions dans la table competence
-- -----------------------------
INSERT INTO competence VALUES('1', 'Java SE');
INSERT INTO competence VALUES('2', 'Selon le stage');
INSERT INTO competence VALUES('3', 'DÃ©v. Web');
INSERT INTO competence VALUES('4', 'PHP');
INSERT INTO competence VALUES('5', 'MySQL');
INSERT INTO competence VALUES('6', 'JavaScript');
INSERT INTO competence VALUES('7', 'Ajax');
INSERT INTO competence VALUES('8', 'HTML');
INSERT INTO competence VALUES('9', 'CSS');
INSERT INTO competence VALUES('10', 'Voir l\'offre');
INSERT INTO competence VALUES('11', 'C');
INSERT INTO competence VALUES('62', 'Editique');
INSERT INTO competence VALUES('13', 'Log. embarquÃ©');
INSERT INTO competence VALUES('46', 'Symphony');
INSERT INTO competence VALUES('17', 'Adm. serveurs');
INSERT INTO competence VALUES('22', 'DÃ©v. smartphone');
INSERT INTO competence VALUES('18', 'Python');
INSERT INTO competence VALUES('19', 'PostgreSQL');
INSERT INTO competence VALUES('24', 'SQL Server');
INSERT INTO competence VALUES('25', 'Visual Studio');
INSERT INTO competence VALUES('26', 'C#');
INSERT INTO competence VALUES('27', 'C++');
INSERT INTO competence VALUES('28', 'XML');
INSERT INTO competence VALUES('29', 'Java EE');
INSERT INTO competence VALUES('61', 'GED');
INSERT INTO competence VALUES('31', '.NET');
INSERT INTO competence VALUES('32', 'RCP/RAP');
INSERT INTO competence VALUES('33', 'Labview');
INSERT INTO competence VALUES('34', 'Qt');
INSERT INTO competence VALUES('35', 'CRM');
INSERT INTO competence VALUES('36', 'Base de donnÃ©es');
INSERT INTO competence VALUES('37', 'DÃ©v. tablette');
INSERT INTO competence VALUES('38', 'JSF');
INSERT INTO competence VALUES('39', 'Perl');
INSERT INTO competence VALUES('40', 'A dÃ©finir');
INSERT INTO competence VALUES('41', 'Ruby');
INSERT INTO competence VALUES('42', 'Matlab');
INSERT INTO competence VALUES('43', 'jQuery');
INSERT INTO competence VALUES('47', 'Flex');
INSERT INTO competence VALUES('48', 'Rest');
INSERT INTO competence VALUES('49', 'JSON');
INSERT INTO competence VALUES('50', 'LAMP');
INSERT INTO competence VALUES('51', 'Could computing');
INSERT INTO competence VALUES('52', 'Android');
INSERT INTO competence VALUES('53', 'WinPhone');
INSERT INTO competence VALUES('64', 'Test logiciel');
INSERT INTO competence VALUES('55', 'Delphi');
INSERT INTO competence VALUES('56', 'Windev');
INSERT INTO competence VALUES('57', 'VBA');
INSERT INTO competence VALUES('65', 'UML');
INSERT INTO competence VALUES('63', 'SharePoint');
INSERT INTO competence VALUES('66', 'Scrum');
INSERT INTO competence VALUES('67', 'Git');
INSERT INTO competence VALUES('68', 'iOS');
INSERT INTO competence VALUES('69', 'Grails');
INSERT INTO competence VALUES('70', 'OpenGL');
INSERT INTO competence VALUES('71', 'OpenCV');

-- -----------------------------
-- insertions dans la table contact
-- -----------------------------
INSERT INTO contact VALUES('12', 'FOURNIER', 'FrÃ©dÃ©ric', '5149873000', '5149874414', 'fournier.frederic@uqam.ca', '12');
INSERT INTO contact VALUES('20', 'Colin', 'Christian', '0251858207', '0251858529', 'Christian.Colin@mines-nantes.fr', '19');
INSERT INTO contact VALUES('119', 'LAMBERT', 'Philippe', '0621734050', '', 'schedstar@wanadoo.fr', '67');
INSERT INTO contact VALUES('643', 'HECQUET', 'Bertrand', '02 43 20 63 40', '', 'bertrand.hecquet@soprasteria.com', '232');
INSERT INTO contact VALUES('521', 'LANOE', 'StÃ©phane', '02.43.41.89.78', '', 'stephane.lanoe@groupe-mma.fr', '53');
INSERT INTO contact VALUES('178', 'Pommier', ' ', ' 024341554', ' ', ' ', '53');
INSERT INTO contact VALUES('179', 'MARLART', 'ValÃ©rie', '0243417901', '', 'valerie.marlart@groupe-mma.fr', '53');
INSERT INTO contact VALUES('40', 'Fourreau', 'Bruno', '0243384618', '', 'bfourreau@harman.com', '29');
INSERT INTO contact VALUES('47', 'CHEMIN', 'BERNARD', '02 43 21 22 68', '', 'bernard.chemin@gkndriveline.com', '33');
INSERT INTO contact VALUES('117', 'Meunier', 'Adrien', '0243502750', '0243502751', 'adrien.meunier@datasyscom.fr', '57');
INSERT INTO contact VALUES('59', 'SERUSIER', 'FLORENCE', '0243782428', '', 'f.serusier@pixbank.org', '35');
INSERT INTO contact VALUES('177', 'SAELEN', 'JÃ©rÃ´me', ' ', '', 'jerome.saelen@groupe-mma.fr', '53');
INSERT INTO contact VALUES('62', 'BLANCHET', 'Johann', '0244718210', '0243470828', 'dpt.informatique@labosport.com', '38');
INSERT INTO contact VALUES('617', 'Belloir', 'Fabrice', '02 99 13 03 03', '', 'f.belloir@biocoop.fr', '394');
INSERT INTO contact VALUES('618', 'Rousseau', 'GÃ©rÃ´me', '02 43 23 55 58 ', '09.81.38.41.58', 'gerome.rousseau@sora.fr', '312');
INSERT INTO contact VALUES('81', 'MARY', 'Jean-Luc', '0243394646', '0243394647', 'jlmary@cttm-lemans.com', '50');
INSERT INTO contact VALUES('84', 'PLU', 'Mathilde', '0243465354', '0243465858', 'm.plu@lavigne.fr', '52');
INSERT INTO contact VALUES('85', 'De Colombel', 'Yvan', '0243412998', '', 'ivan.decolombel@groupe-mma.fr', '53');
INSERT INTO contact VALUES('89', 'LEFEVRE', 'Raymond', '0628139739', '', 'raymond.lefevre@orange.fr', '16');
INSERT INTO contact VALUES('176', 'TREVOAN', 'Cyril', '0140279114', '0140279118', '', '100');
INSERT INTO contact VALUES('120', 'MAUCLERC', 'Pascal', '0243412259', '0243412298', 'pascal.mauclerc@gkndriveline.com', '33');
INSERT INTO contact VALUES('116', 'GUILLIN', 'KÃ©vin', '0687109205', '', 'k.guillin@syneo.fr', '65');
INSERT INTO contact VALUES('338', 'Biguet', 'StÃ©phane', '0243715232', '', 'mail@cerivan.com', '200');
INSERT INTO contact VALUES('647', 'Saltis', 'Sam', ' ', '', 'Sam.Saltis@bwired.com', '417');
INSERT INTO contact VALUES('125', 'Pignon', 'Franck', ' ', '', 'fpignon@ch-lemans.fr', '70');
INSERT INTO contact VALUES('126', 'AUBRON', 'MAUD', '0243412160', '', 'maud.aubron@gkndriveline.com', '33');
INSERT INTO contact VALUES('127', 'MATHIEU', 'Erwann', '0223501212', '0223501200', 'emathieu@webmail.alten.fr', '71');
INSERT INTO contact VALUES('129', 'SICHEZ', 'Manuel', '0253465001', '0243872733', 'manuel.sichez@logica.com', '73');
INSERT INTO contact VALUES('130', 'BELMANS', 'Philippe', '0161626667', '', '', '59');
INSERT INTO contact VALUES('131', 'CLEDER', 'Catherine', '0243833854', '', 'catherine.cleder@lium.univ-lemans.fr', '74');
INSERT INTO contact VALUES('132', 'MEVEL', 'Bruno', '0450653169', '0450653033', 'bruno.mevel@snr.fr', '75');
INSERT INTO contact VALUES('133', 'HABHOUB', 'Sami', '0149225129', '', 'sami.habhoub@gdfsuez.com', '76');
INSERT INTO contact VALUES('134', 'LAFORCADE', 'Pierre', '0243594963', '', 'pierre.laforcade@univ-lemans.fr', '74');
INSERT INTO contact VALUES('135', 'LANGLOIS', ' Jean-FranÃ§ois ', '0299125710', '', 'jflanglois@sii.fr', '77');
INSERT INTO contact VALUES('136', 'LEMARCHAND', 'Marc', '0299054040', '', 'mlemarchand@assystem.com', '78');
INSERT INTO contact VALUES('137', 'LEPEROUX', 'Aymeric', '0299048060', '', 'a.leperoux@astellia.com', '22');
INSERT INTO contact VALUES('138', 'DORBES', 'StÃ©phane', '0244027462', '', '', '3');
INSERT INTO contact VALUES('139', 'VINAS', 'Eric', '0243604758', '', '', '79');
INSERT INTO contact VALUES('140', 'DELAMEZIERE', 'Fabien', '02 99 12 5', '', 'fdelameziere@sii.fr', '77');
INSERT INTO contact VALUES('141', 'BLANCHET', 'Samuel', '0243416529', '', 'samuel.blanchet@groupe-mma.fr', '53');
INSERT INTO contact VALUES('142', 'BLANCHARD', 'SÃ©bastien', '0228015470', '', 'sebastien.blanchard@logica.com', '73');
INSERT INTO contact VALUES('143', 'LE BOULAIRE', 'Christophe', '0251783884', '', 'cleboulaire@sopragroup.com', '80');
INSERT INTO contact VALUES('144', 'TEXIER', 'JÃ©rÃ©my', '0240389209', '', 'jtexier@sopragroup.com', '80');
INSERT INTO contact VALUES('145', 'PREVOST', 'Edouard', '0149886743', '', 'eprevost@sopragroup.com', '80');
INSERT INTO contact VALUES('146', 'PRAT', 'Nicolas', '0558976704', '', 'nicolas.prat@helileo.com', '23');
INSERT INTO contact VALUES('147', 'HERSENT', 'Yann', '0272749797', '', 'yann.hersent.sopra@cnp.fr', '80');
INSERT INTO contact VALUES('148', 'LAIGO', 'Tristan', '0223252832', '0223252526', 'tlaigo@sopragroup.com', '80');
INSERT INTO contact VALUES('149', 'BIRIOTTI', 'Pascale', '0149004687', '', 'pascale.biriotti@capgemini.com', '81');
INSERT INTO contact VALUES('150', 'DAVIAU', 'Camille', '0299842091', '', 'camille.daviau@atosorigin.com', '82');
INSERT INTO contact VALUES('151', 'LERAY', 'JÃ©rÃ´me', '0243502650', '', 'jerome.leray@oceanet.com', '83');
INSERT INTO contact VALUES('152', 'LEGUEUT', 'Pascal', '0240389090', '', 'plegueut@sopragroup.com', '80');
INSERT INTO contact VALUES('153', 'LE FLOHIC', 'Geoffroy', '0272749797', '', 'gleflohic@sopragroup.com', '80');
INSERT INTO contact VALUES('154', 'MESQAH', 'Rachid', '0251783845', '', 'rmesqah@sopragroup.com', '80');
INSERT INTO contact VALUES('155', 'PARIS', 'Vincent', '0155915050', '', '', '80');
INSERT INTO contact VALUES('160', 'COTASSON', 'Etienne', '0240683800', '0240683838', '', '87');
INSERT INTO contact VALUES('157', 'MARTEAU', 'Fabien', '02 43 78 30 40', '', 'fabien.marteau@groupe-sephira.fr', '26');
INSERT INTO contact VALUES('158', 'BRILLAND', 'Carole', '0243546610', '0243546551', 'brillant@sdis72.fr', '85');
INSERT INTO contact VALUES('159', 'STAEDELIN', 'Julien', ' ', '', 'j.staedelin@tally-weijl.com', '86');
INSERT INTO contact VALUES('161', 'MAOUT', 'Christian', '0244027462', '', 'christian.maout@stericsson.com', '3');
INSERT INTO contact VALUES('162', 'TROTTIER', 'Matthias', '0243725455', '0243782681', 'matthias.trottier@o2.fr', '88');
INSERT INTO contact VALUES('163', 'MICHALECZEK', 'Boris', '0233806667', '0233806695', 'michaleczek@maisonfc.fr', '89');
INSERT INTO contact VALUES('164', 'SCHEMBRI', 'Samuel', '0243503950', '0243503959', 'sschembri@mercuriale-data.com', '48');
INSERT INTO contact VALUES('165', 'FOUCAULT', 'Thierry', '0243163333', '0243160078', 'tfoucault@algrithmeinformatique.fr', '90');
INSERT INTO contact VALUES('166', 'MONSALLIER', 'Jean-Michel', '0233802150', '0233802151', '', '91');
INSERT INTO contact VALUES('167', 'PLANCHARD', ' Eddy', '0243435241', '', 'e.planchard@chs-sarthe.fr', '92');
INSERT INTO contact VALUES('168', 'FOUGERE', 'Alexandre', '0243392523', '0243392529', 'afougere@axians.com', '93');
INSERT INTO contact VALUES('169', 'TRIANTAFYLLIDES', 'Alain', '0494114539', '0494114986', 'cin_sm.proviseur@marine.dÃ©fense.gouv.fr', '94');
INSERT INTO contact VALUES('170', 'PAULMERY', 'StÃ©phane', '0243621596', '', 'spaulmery@fpee.fr', '95');
INSERT INTO contact VALUES('171', 'DIALLO', 'ALASSANE', ' ', ' ', '', '96');
INSERT INTO contact VALUES('172', 'HATTON', 'Anne-Marie', '0243521859', '0243521859', '', '97');
INSERT INTO contact VALUES('173', 'PENG', 'Danfeng', ' ', ' ', '', '98');
INSERT INTO contact VALUES('174', 'RENAULT', 'HervÃ©', ' ', '', 'herve.renault@ctcam.fr', '99');
INSERT INTO contact VALUES('175', 'COETMEUR', 'Nicolas', '0243511797', '0243511798', '', '30');
INSERT INTO contact VALUES('180', 'ROULIN', 'Dominique', '0153309060', '', 'dominique.roulin@omega-financial-solutions.com', '101');
INSERT INTO contact VALUES('181', 'LABUSSIERE', 'FrÃ©dÃ©ric', '0244027462', '0244027501', 'frederic.labussiere@stericsson.com', '3');
INSERT INTO contact VALUES('182', 'ARIBAUD', 'Guillaume', '0251953023', '', '', '102');
INSERT INTO contact VALUES('183', 'POUSSIN', 'Pierre', '0233266230', '', 'info@conceptmultimedia.fr', '103');
INSERT INTO contact VALUES('184', 'LEQUITTE', 'RÃ©my', '0233522937', '', 'remy.lequitte@equipement.gouv.fr', '104');
INSERT INTO contact VALUES('185', 'LE BERRE', 'GÃ©rard', ' ', '', 'gerard.leberre@groupe-sephira.fr', '26');
INSERT INTO contact VALUES('186', 'OLLU', 'Jean-FranÃ§ois', '0243500803', '0243500809', 'ollu.renaud@wanadoo.fr', '105');
INSERT INTO contact VALUES('187', 'DAUBA', 'CÃ©drick', '0243602917', '', 'cdauba@idexcorp.com', '106');
INSERT INTO contact VALUES('188', 'GARCIA', 'Pablo', '0145407256', '', 'communic.art@wanadoo.fr', '107');
INSERT INTO contact VALUES('189', 'LANGE', 'SÃ©bastien', '0233312210', '0233312214', 'contact@syleam.fr', '108');
INSERT INTO contact VALUES('190', 'ALLONNEAU', 'Emmanuel', '0247054950', '0247054950', 'alliance@numericable.fr', '109');
INSERT INTO contact VALUES('191', 'LUZZATI', 'Daniel', '0243833168', '0243833775', 'daniel.luzzati@univ-lemans.fr', '110');
INSERT INTO contact VALUES('192', 'FEIGENBAUM', 'Renaud', ' ', '', 'k.guillin@syneo.fr', '111');
INSERT INTO contact VALUES('193', 'BARRE', 'Patrice', '0243525271', '0243525253', 'patrice.barre@legrand.fr', '112');
INSERT INTO contact VALUES('194', 'DE SEDOUY', 'Thomas', '0555522004', '0555523040', 't.desedouy@3si.fr', '113');
INSERT INTO contact VALUES('195', 'PATERNE', 'Olivier', '0243280635', '', 'brin.de.soleil@wanadoo.fr', '114');
INSERT INTO contact VALUES('415', ' ', ' ', '02 43 62 70 00', '', '', '262');
INSERT INTO contact VALUES('350', 'BOUVET', 'Thierry', '02 43 75 02 39', '02 43 75 37 31', 'thierry.bouvet@dams.fr', '208');
INSERT INTO contact VALUES('351', 'LOUVEL', 'GUILLAUME', '02 85 52 00 51', '', 'louvel@akelio.fr', '209');
INSERT INTO contact VALUES('263', 'Carthy', 'Robert', '02 43 84 50 00', '02 43 61 55 05', 'RCarthy@i-cone.fr', '142');
INSERT INTO contact VALUES('265', 'Cahoreau', 'StÃ©phane', '02.53.04.85.70', '', 'hyc@wanadoo.fr', '144');
INSERT INTO contact VALUES('277', 'MOURLANNE', 'Thierry', '06 80 48 31 91', '', 'thierry@mourlanne.com', '153');
INSERT INTO contact VALUES('283', 'PECAULT', 'GrÃ©goire', '01 49 00 40 00', '01 47 78 45 52', '', '158');
INSERT INTO contact VALUES('284', 'ZHANG', 'Rong-e', '010 518 958 85', '', 'zhang.ronge@gmail.com', '159');
INSERT INTO contact VALUES('285', 'Le Lain', 'Franck', '02 40 38 93 79', '', 'flelain@sopragroup.com', '160');
INSERT INTO contact VALUES('286', 'GUILLAUMOND', 'Olivier', '+31 (0) 6 162 698 46', '', 'olivier.guillaumond@smile-benelux.com', '161');
INSERT INTO contact VALUES('287', 'LE HAN', 'Erwan', '02 99 32 90 90', '02 99 32 90 99', 'elehan@avantias.com', '162');
INSERT INTO contact VALUES('288', 'ALBESA', 'Franck', '02 44 02 70 03', '02 44 02 70 00', 'franck.albesa@stericsson.com', '3');
INSERT INTO contact VALUES('289', 'LEPAGE', 'StÃ©phane', '02 99 04 86 63', '', 's.lepage@astellia.com', '22');
INSERT INTO contact VALUES('290', 'BOURGOIS', 'Laurent', '06 xx', '', 'laurent.bourgois@cgi.com', '163');
INSERT INTO contact VALUES('291', 'SERTIER', 'Nathalie', '01 58 98 00 44', '', 'nathalie.sertier@sgcib.com', '164');
INSERT INTO contact VALUES('292', 'GANDON', 'SÃ©bastien', '06 24 54 15 63', '', 'sebastien.gandon@stericsson.com', '3');
INSERT INTO contact VALUES('293', 'BRODIER', 'Julien', '06 19 79 40 99', '', 'julien.brodier@novae-conseil.fr', '165');
INSERT INTO contact VALUES('294', 'RAOUST', 'Maxime', '01 75 57 92 63', '', 'max@nadeo.com', '166');
INSERT INTO contact VALUES('295', 'ZHOU', 'Hang', '00 86 45 48 69 55 28', '', '', '167');
INSERT INTO contact VALUES('296', 'LASNIER REDDAN', 'Edouard', '02 40 38 94 42', '', 'elasnier@sopragroup.com', '160');
INSERT INTO contact VALUES('297', 'RAMONA', 'Vincent', ' ', '', 'vincent.ramona@logica.com', '73');
INSERT INTO contact VALUES('298', 'BALEYDIER', 'Pierre', '01 55 00 57 24', '', 'pbaleydier@nds.com', '168');
INSERT INTO contact VALUES('299', 'LIU', 'Yu', '0086 242 382 6016', '', 'chinarock@126.com', '169');
INSERT INTO contact VALUES('300', 'CHANTARAUD', 'Samuel', '01 55 78 24 23', '', 'schantaraud@avantias.com', '123');
INSERT INTO contact VALUES('301', 'WANG', 'Zengyou', '03 44 32 14 36', '', '', '170');
INSERT INTO contact VALUES('302', 'RIBEIRO', 'Jean-Philippe', '02 43 72 54 61', '', 'jp.ribeiro@o2.fr', '88');
INSERT INTO contact VALUES('303', 'PLANARD', 'Marc', '06 60 18 09 48', '', 'case@mekensleep.com', '171');
INSERT INTO contact VALUES('304', 'CARADEC', 'Bertrand', '02 99 67 00 22', '', '', '172');
INSERT INTO contact VALUES('305', 'LABUSSIERE', 'Christophe', '01 80 80 12 33', '', 'christophe@ventes-responsables.com', '173');
INSERT INTO contact VALUES('311', 'de CARLINI', ' Pierre-FranÃ§ois', '02 43 47 38 26', '02 43 47 45 52', 'dsi@ville-lemans.fr', '178');
INSERT INTO contact VALUES('312', 'MAINGUET', 'Isabelle', ' 02 28 20 11 00', ' ', ' ', '179');
INSERT INTO contact VALUES('313', 'JAMES', 'SÃ©bastien', '02 28 20 11 00', '', '', '179');
INSERT INTO contact VALUES('314', 'OUALET', 'Denis', '02 43 78 67 06', '02 47 78 65 47', 'denis.oualet@sncf.fr', '180');
INSERT INTO contact VALUES('315', 'FAUCHERE', 'Yannick', '01 46 25 82 00', '', '', '181');
INSERT INTO contact VALUES('316', 'LANGEN', 'Nils', '02 43 29 16 50', '', 'nils@tripall.fr', '182');
INSERT INTO contact VALUES('317', 'ANQUETIL', 'Nicolas', '02 43 18 36 18', '02 43 18 36 36', 'nicolas.anquetil@72mis.fr', '183');
INSERT INTO contact VALUES('318', 'FROGER', 'Alban', '02 43 82 06 63', '', 'alban.froger@ets-conty.fr', '184');
INSERT INTO contact VALUES('319', 'BESLIER', 'Denis', '02 43 81 28 65', '', 'denis.beslier@lycee-st-charles.com', '185');
INSERT INTO contact VALUES('320', 'HUWART', 'Gilles', '02 43 46 53 54', '', 'g.huwart@lavigne.fr', '52');
INSERT INTO contact VALUES('321', 'OZAN', 'Manuel', '02 43 82 97 97', '', 'm.ozan@nozicaa.com', '186');
INSERT INTO contact VALUES('322', 'BOUZFOUR', 'Sarah', '02 43 76 93 20', '', 'sarah.bouzfour1@ac-nantes.fr', '187');
INSERT INTO contact VALUES('323', 'ROCHARD', 'VÃ©ronique', '02 41 21 56 00', '', 'v-rochard@specinov.fr', '188');
INSERT INTO contact VALUES('324', 'DESMIERS', 'JÃ©rÃ´me', '02 43 81 98 47', '', 'jerome.desmiers@cafe-frappe.fr', '125');
INSERT INTO contact VALUES('325', 'BOIS', 'Francis', '02 43 39 70 19', '', '', '189');
INSERT INTO contact VALUES('326', 'STUBER', 'Matthias', '+49 0 30 6576 3390', '', 'matthias@stuber.de', '190');
INSERT INTO contact VALUES('327', 'MAUNOURY', 'SÃ©bastien', '02 43 41 76 49', '', 'sebastien.maunoury@groupe-mma.fr', '53');
INSERT INTO contact VALUES('328', 'VILLENEUVE', 'Laurence', '02 43 39 28 33', '', 'dired.dir@sms.asso.fr', '191');
INSERT INTO contact VALUES('329', 'LE DRESSAY', 'CÃ©dric', '01 40 27 91 14', '', 'cledressay@eugensystems.com', '100');
INSERT INTO contact VALUES('330', 'MUGUET', 'StÃ©phane', '06 07 87 36 81', '', 'muguet.stephane@free.fr', '192');
INSERT INTO contact VALUES('331', 'TROJANOWSKA', 'Alicja', '02 43 24 88 08', '', 'communication.adimc72@gmail.com', '193');
INSERT INTO contact VALUES('332', 'MARIOT', 'StÃ©phane', '02 43 500 150', '', 'stephane@calendrier.fr', '194');
INSERT INTO contact VALUES('333', 'VOLKOVICH', 'Vladimir', '+380 44 2399897', '', 'volk@pnn.com.ua', '195');
INSERT INTO contact VALUES('335', 'SAUVAGE', 'AurÃ©lien', '02 43 67 02 21', '', 'anexderv@gmail.com', '197');
INSERT INTO contact VALUES('574', 'POSTEC', 'Nicolas', '02 43 83 36 03', '', 'Nicolas.Postec@univ-lemans.fr', '377');
INSERT INTO contact VALUES('695', 'Colombo', 'StÃ©phane', '0299274545', '', 'stephane.colombo@capgemini.com', '337');
INSERT INTO contact VALUES('428', 'BOUGARD', 'AmaÃ«l', '02 43 14 16 16', '', 'abougard@coclico.fr', '272');
INSERT INTO contact VALUES('651', 'DENIS', 'Thibault', '02 53 46 50 16', '', 'thibault.denis@cgi.com', '73');
INSERT INTO contact VALUES('649', 'PEAN', 'Erwan', ' ', '', 'erwan.pean@capgemini.com', '337');
INSERT INTO contact VALUES('358', 'BREAT', 'Jean-Louis', '01 76 86 44 00', '', 'jean-louis.breat@renault.com', '215');
INSERT INTO contact VALUES('683', 'Bouttier', 'Meggie', '02 77 27 77 25', '', 'mbouttier@umanis.com', '284');
INSERT INTO contact VALUES('684', 'Lehan', 'Erwan', ' ', '', 'erwan.lehan@sword-group.com', '436');
INSERT INTO contact VALUES('685', 'Sarrazin', 'Samuel', '06 98 00 25 34', '', 'ssarrazin@groupehelice.fr', '436');
INSERT INTO contact VALUES('523', 'LE BORGNE', 'Ludivine', '02 14 37 81 89', '', 'ludivine.le.borgne@cgi.com', '332');
INSERT INTO contact VALUES('520', 'TEMPERAULT', 'Pierrick', '02.43.41.60.44', '', 'pierrick.temperault@groupe-mma.fr', '53');
INSERT INTO contact VALUES('425', 'Belperche', 'Aurore', '02 43 41 55 65', '', 'aurore.belperche@groupe-mma.fr', '53');
INSERT INTO contact VALUES('644', 'OLLIVIER-LAPEYRE', 'Johann', '02 51 89 78 78', '', 'johann.ollivier-lapeyre@novia-systems.fr', '414');
INSERT INTO contact VALUES('414', 'SIMON', 'Jean-FranÃ§ois', '02 43 16 16 31', '', 'jean-francois.simon@apotamox.com', '261');
INSERT INTO contact VALUES('372', 'CHESNET', 'Didier', '02.33.52.79.65', '02.33.52.03.42', 'didier.chesnet@developpement-durable.gouv.fr', '227');
INSERT INTO contact VALUES('373', 'de Cara', 'Arnaud', '09 74 76 89 01', '', 'arnaud@kocka.fr', '228');
INSERT INTO contact VALUES('374', 'SENLIS', 'Yves', '02 43 52 10 52', '02 43 20 77 69', 'yves.senlis@sanders.fr', '229');
INSERT INTO contact VALUES('375', 'de BAROLET', 'Henry', '06 10 59 67 57', '', 'henri.debarolet@oxylane.com', '230');
INSERT INTO contact VALUES('376', 'BENCHALLAL', 'Abderrahmane', '06 48 63 60 33', '', 'abderrahmane.benchallal@logica.com', '231');
INSERT INTO contact VALUES('377', 'PETILLON', 'Thierry', '06 03 09 78 12', '', 'tpetillon@sopragroup.com', '232');
INSERT INTO contact VALUES('378', 'GRANDIN', 'Emmanuel', '02 44 02 71 88', '02 44 02 70 00', 'emmanuel.grandin@stericsson.com', '3');
INSERT INTO contact VALUES('380', 'PINAULT', 'Samuel', '02 37 33 32 04', '', 'samuel.pinault@leoni.com', '234');
INSERT INTO contact VALUES('697', 'LECUREUR', 'Jacques', '02 43 57 42 46', '', 'jacques.lecureur@sesam-vitale.fr', '294');
INSERT INTO contact VALUES('556', 'LUTTMANN', 'Geoffroy', '02.53.43.75.55', '', 'gluttmann@m-i-e.fr', '361');
INSERT INTO contact VALUES('383', 'BERNARD', 'Jean-Louis', '01 76 86 42 34', '', 'jean-louis.bernard@renault.com', '237');
INSERT INTO contact VALUES('385', 'ZAHI', 'Chaddad', '06 63 59 39 89', '', 'z.chaddad@citinfo.fr', '238');
INSERT INTO contact VALUES('386', 'DENIS', 'Xavier', '02 43 43 78 00', '02 43 43 78 17', 'xdenis@jacques-denis.com', '239');
INSERT INTO contact VALUES('387', 'MARCEAU', 'Dominique', '02 43 21 40 30', '', 'dmarceau@ismans.fr', '240');
INSERT INTO contact VALUES('388', 'TRONCHET', 'Philippe', '02 33 32 41 75', '', 'philippe.tronchet@ville-alencon.fr', '241');
INSERT INTO contact VALUES('389', 'SIMON', 'Jean-Marie', '06 09 71 24 02', '', 'jm.simon@pole-formations.fr', '235');
INSERT INTO contact VALUES('390', 'CALTRE', 'Stanislas', '06 08 98 14 77', '', 'sta@fimor.fr', '242');
INSERT INTO contact VALUES('391', 'DUPONT', 'Eric', '02 43 25 25 00', '', 'edupont@sodifrance.fr', '243');
INSERT INTO contact VALUES('392', 'ThÃ©tis Interactive', 'Contact', '02 43 29 08 00', '', 'contact@tethis-interactive.com', '244');
INSERT INTO contact VALUES('393', 'LUSTREMENT', 'Fabrice', '02 43 93 14 90', '02 43 71 21 66', 'lustrementf@applimo.fr', '245');
INSERT INTO contact VALUES('394', 'SIMON', 'Julien', '02 43 41 21 98', '', 'julien.simon@gkndriveline.com', '33');
INSERT INTO contact VALUES('395', 'BONNARD', 'Pierre', '06 85 06 08 51', '', 'pierre@idexlab.com', '246');
INSERT INTO contact VALUES('396', 'CABANNES', 'Alain', '02 43 28 58 58', '02 43 28 58 68', 'contact@cenomans.fr', '247');
INSERT INTO contact VALUES('694', 'Bonnetier', 'Cyrille', '02 28 01 89 50', '', 'cyrille.weisse-bonnetier@cgi.com', '163');
INSERT INTO contact VALUES('398', 'MONNERET', 'Etienne', '02 43 67 99 58', '', 'em@lingua-et-machina.com', '249');
INSERT INTO contact VALUES('399', 'PICOT', 'Vincent', ' ', '', 'vincent.picot@logica.com', '73');
INSERT INTO contact VALUES('400', 'DUMONT', 'Sylvain', '02 43 47 00 30', '02 43 47 00 39', 'sylvain.dumont@montjoie.asso.fr', '250');
INSERT INTO contact VALUES('401', 'MICHEL', 'Olivier', '02 43 41 82 80', '', 'olivier.michel@groupe-mma.fr', '53');
INSERT INTO contact VALUES('402', 'BARBE', 'RÃ©mi', ' ', '', 'remi.barbe@mysportconnect.net', '251');
INSERT INTO contact VALUES('403', 'MORE', 'SÃ©bastien', '02 43 84 13 12', '02 43 84 13 44', 'sebastien@phoneaxe.fr', '252');
INSERT INTO contact VALUES('404', 'BOITEUX', 'FrÃ©dÃ©ric', '02 43 78 72 82', '', 'frederic.boiteux@groupe-sephira.fr', '26');
INSERT INTO contact VALUES('405', 'FEYS', 'JÃ©rÃ´me', ' ', '', 'info@vescape.com', '254');
INSERT INTO contact VALUES('406', 'KERLIKOWSKI', 'Ingo', ' ', '', 'ingo.kerlikowski@thalesgroup.com', '255');
INSERT INTO contact VALUES('407', 'RAUX', 'FrÃ©dÃ©ric', ' ', '', 'frederic.raux@thalesgroup.com', '256');
INSERT INTO contact VALUES('408', 'LOTZKE', 'Matthias', ' ', '', 'matthias.loetzke@sysgo.com', '257');
INSERT INTO contact VALUES('409', 'HEMON', 'Yann', ' ', '', 'yann.hemon@stericsson.com', '3');
INSERT INTO contact VALUES('410', 'GUYARD', 'Patrick', '+33 22 347 05 01', '+33 22 347 04 00', 'patrick.guyard@stericsson.com', '3');
INSERT INTO contact VALUES('436', 'BONNET', 'Cyril', '06 89 53 38 03', '', 'dired.dir@sms.asso.fr', '280');
INSERT INTO contact VALUES('416', ' ', ' ', '03.80.53.95.95', '', '', '263');
INSERT INTO contact VALUES('417', 'MAILHAN', 'Jean-Christophe', '02.43.63.24.00', '', '', '264');
INSERT INTO contact VALUES('418', ' ', ' ', '02 37 18 76 00', '', 'france@fci.com', '265');
INSERT INTO contact VALUES('638', 'Le Roux', 'FranÃ§ois', '01 46 08 46 83', '', 'francois.leroux@futurmaster.com', '409');
INSERT INTO contact VALUES('641', 'Laforcade', 'Pierre', '02 43 59 49 63', '', 'pierre.laforcade@univ-lemans.fr', '412');
INSERT INTO contact VALUES('686', 'LAURANT', 'BenoÃ®t', '02 99 23 42 15', '', 'benoit.laurant@infotel.com', '343');
INSERT INTO contact VALUES('465', 'GUIN', 'Eric', '02 99 32 90 92', '', 'eric.guin@capgemini.com', '337');
INSERT INTO contact VALUES('693', 'Martello', 'Daniel', '00352.49.48.48.1', '', 'pwcpeopleshare@lu.pwc.com', '442');
INSERT INTO contact VALUES('635', 'Schwenk', 'Holger', '02 43 83 38 55', '', 'holger.schwenk@lium.univ-lemans.fr', '74');
INSERT INTO contact VALUES('519', 'GAUTIER', 'Fabrice', '02 43 16 16 30', '', 'fabrice.gautier@apotamox.com', '261');
INSERT INTO contact VALUES('501', 'DELMASTRO', 'Christine', '02 33 32 35 45', '', ' ', '292');
INSERT INTO contact VALUES('453', 'Deshaies', 'Gilles', '02  43 41 77  44', '', 'gilles.deshaies@groupe-mma.fr', '53');
INSERT INTO contact VALUES('639', 'Gabal', 'Ahmed', '02 53 43 24 98', '', ' ', '410');
INSERT INTO contact VALUES('524', 'LARSONNEUR', 'Armelle', ' ', '', '', '333');
INSERT INTO contact VALUES('681', 'Gahagnon', 'Thibaud', ' ', '', 'thibaud.gahagnon@cgi.com', '163');
INSERT INTO contact VALUES('457', 'DESPRES', 'Jean-Charles', '0243279909', '', 'jcdespres@datanaute.com', '296');
INSERT INTO contact VALUES('648', 'ANDRIEU', 'Emmanuel', '02 77 27 77 20', '', 'eandrieu@umanis.com', '284');
INSERT INTO contact VALUES('676', 'zdez', 'dezdez', '06', '', 'toto@titi.fr', '431');
INSERT INTO contact VALUES('677', 'Horhant', 'ClÃ©ment', ' ', '', 'clement.horhant@talentroc.com', '432');
INSERT INTO contact VALUES('678', 'zdez', 'dezdez', '06', '', 'toto@titi.fr', '433');
INSERT INTO contact VALUES('679', 'Carpentier', 'Alexis', ' ', '', 'alexis.carpentier@soprasteria.com', '232');
INSERT INTO contact VALUES('463', 'NORBERT', 'Janzen', ' ', '', 'norbert.janzen@aareal-bank.com', '301');
INSERT INTO contact VALUES('464', 'BOURNAND', 'Emilie', '01 49 00 39 79', '', 'emilie.bournand@capgemini.com', '179');
INSERT INTO contact VALUES('466', 'DURIEUX', 'David', '02 99 32 90 96', '', 'david.durieux@capgemini.com', '302');
INSERT INTO contact VALUES('467', 'MENAGER', 'BenoÃ®t', '02 99 27 64 74', '', 'benoit.menager@capgemini.com', '302');
INSERT INTO contact VALUES('468', 'LACHAMBRE', 'Vincent', ' ', '', 'vincent.lachambre@capgemini.com', '303');
INSERT INTO contact VALUES('469', 'BOUTAYEB', 'Abdelmajid', '01 49 67 28 14', '01 49 67 43 84', 'abdelmajid.boutayeb@gemini.com', '81');
INSERT INTO contact VALUES('470', 'CHIRITA', 'Irina', '01 49 67 59 98', '01 49 00 21 56', 'irina.chirita@capgemini.com', '304');
INSERT INTO contact VALUES('471', 'PONTOIRE', 'Maxime', '02 28 20 11 00', '02 28 20 11 01', 'maxime.pontoire@capgemini.com', '179');
INSERT INTO contact VALUES('522', 'BRUNET', 'Olivier', '02.43.41.59.59', '', 'olivier.brunet@groupe-mma.fr', '53');
INSERT INTO contact VALUES('473', 'HERVO', 'GuÃ©nolÃ©', ' ', '', 'guenole.hervo@devoteam.com', '306');
INSERT INTO contact VALUES('474', 'GUILLAUME', 'Bruno', '02 43 39 48 04', '', 'brunoguillaume@kasteepic.com', '307');
INSERT INTO contact VALUES('475', 'MAHE', 'Michel', '02 43 41 80 91', '', 'michel.mahe@groupe-mma.fr', '53');
INSERT INTO contact VALUES('476', 'GARIN', 'CÃ©dric', '02 43 41 28 96', '', 'cedric.garin@groupe-mma.fr', '53');
INSERT INTO contact VALUES('477', 'OUDET', 'Bertrand', '02 43 41 8 84', '', 'bertrand.oudet.sopra-group@groupe-mma.fr', '53');
INSERT INTO contact VALUES('478', 'LUCAS', 'Pascal', '02 49 62 00 26', '02 51 85 24 72', 'p.lucas@groupeonepoint.com', '308');
INSERT INTO contact VALUES('479', 'LELAQUET', 'StÃ©phane', '09 72 70 43 54', '', 'info06@blancmarine.com', '309');
INSERT INTO contact VALUES('480', 'LELIEVRE', 'Jean-Philippe', '06 83 38 65 55', '', 'lelievre.jp@free.fr', '310');
INSERT INTO contact VALUES('481', 'FAUR-PEY', 'Alain', '06 70 88 24 85', '', 'alain.faur-pey@sopragroup.com', '232');
INSERT INTO contact VALUES('482', 'FAURE', 'Patrick', '06 16 38 66 12', '', 'patrick.faure@sopragroup.com', '232');
INSERT INTO contact VALUES('483', 'VALENTE', 'FranÃ§ois', '02 43 20 63 40', '', 'francois.valente@sopra.com', '232');
INSERT INTO contact VALUES('485', 'CARRIERE', 'Etienne', '06 34 87 05 93', '', 'etienne.carriere@st.com', '3');
INSERT INTO contact VALUES('486', 'RUTER', 'Eric', '07 62 70 83 46', '', 'eruter@umanis.com', '313');
INSERT INTO contact VALUES('487', 'MARTIN', 'Guillaume', '01 76 85 27 45', '', 'guillaume.g.martin@renault.com', '314');
INSERT INTO contact VALUES('488', 'VALLEE', 'StÃ©phane', '06 12 76 51 26', '', 'svallee@groupe-leblanc.com', '315');
INSERT INTO contact VALUES('489', 'SERUS', 'Thomas', '02 43 39 06 14', '', 'thomas.serus@levrat.com', '316');
INSERT INTO contact VALUES('692', 'BONNEAU', 'Valentin', '02 47 46 26 26', '', 'bonneau@apside.fr', '441');
INSERT INTO contact VALUES('682', 'BONTEMPS', 'Corinne', '02.43.71.65.74', '', 'cbontemps@dic.fr', '435');
INSERT INTO contact VALUES('491', 'KNAKE', 'Jean-Marc', '02 53 49 10 00', '', 'jmknake@valorys.fr', '317');
INSERT INTO contact VALUES('492', 'REMARS', 'MickaÃ«l', '02 43 50 01 50', '', 'm.remars@calendrier.fr', '194');
INSERT INTO contact VALUES('493', 'SARRAILH', 'Fabien', '02 43 75 67 67', '', 'astlemans@orange.fr', '318');
INSERT INTO contact VALUES('494', 'DEZE', 'Christophe', '02 40 14 63 28', '', 'christophe.deze@ac-nantes.fr', '319');
INSERT INTO contact VALUES('495', 'RETIF', 'Olivier', '02 43 47 49 07', '', 'olivier.retif@ville-lemans.fr', '178');
INSERT INTO contact VALUES('496', 'FRESNAIS', 'Thierry', '02 43 72 15 48', '', 'lemans@atelierpc.fr', '320');
INSERT INTO contact VALUES('497', 'BAIN', 'Christophe', '02 53 41 19 20', '', 'contact@crayonsdecouleurs.fr', '321');
INSERT INTO contact VALUES('498', 'MIRILOVIC', 'Rodolphe', '01 83 64 51 08', '', 'rodolphe@antvoice.com', '322');
INSERT INTO contact VALUES('499', 'DAUZON', 'Robin', 'xx', '', 'robin@bankin.com', '323');
INSERT INTO contact VALUES('500', 'ELKORY', 'Mohamed', '*0022245241349', 'mkory@bci-banque.com', '', '324');
INSERT INTO contact VALUES('502', 'ZHANG', 'Qun', '*00867168278484', '', '1045907248@qq.com', '325');
INSERT INTO contact VALUES('503', 'COTARD', 'Jean-Baptiste', '02 43 57 42 00', '', ' ', '294');
INSERT INTO contact VALUES('504', 'CASSABOIS', 'LoÃ¯s', '02 43 41 58 65', '', 'lois.cassabois@groupe-mma.fr', '53');
INSERT INTO contact VALUES('505', 'ETIENNEY', 'Paul', '06 64 76 32 30', '', 'paul@octopolux.com', '326');
INSERT INTO contact VALUES('506', 'LARREUR', 'GrÃ©goire', '09 81 10 03 00', '', 'gregoire.larreur@ozytis.fr', '327');
INSERT INTO contact VALUES('507', 'CHOLEAU', 'FranÃ§ois', ' ', '', 'francois.choleau@stericsson.com', '3');
INSERT INTO contact VALUES('508', 'DELACOU', 'Julien', ' ', '', 'julien.delacou@stericsson.com', '3');
INSERT INTO contact VALUES('509', 'HAURIE', 'Thierry', '02 41 64 58 96', '', 'thierry.haurie@thalesgroup.com', '256');
INSERT INTO contact VALUES('510', 'MACHEFER', 'Remy', '02 77 27 77 20', '', 'rmachefer@umanis.com', '284');
INSERT INTO contact VALUES('511', 'PORTENSEIGNE', 'Luc', '02 77 27 77 20', '', 'lportenseigne@umanis.com', '284');
INSERT INTO contact VALUES('512', 'GRAIGNIC', 'Michel', '02 43 92 84 85', '', 'michel.graignic@valeo.com', '288');
INSERT INTO contact VALUES('513', 'Chardonnet', 'Christophe ', '06 76 95 37 09 ', '', 'christophe.chardonnet@synergieassocies.com ', '328');
INSERT INTO contact VALUES('514', 'MALET', 'Yonathan', '06 xx', '', 'yonathan.malet@nbmgroupe.com', '329');
INSERT INTO contact VALUES('515', 'SOUBRIER', 'Christophe', '01 58 01 80 00', '', 'christophe.soubrier@ingenico.com', '181');
INSERT INTO contact VALUES('516', 'ANDURAND', 'LoÃ¯c', 'xx', '', ' loic.andurand@conix.fr', '305');
INSERT INTO contact VALUES('636', 'Meignier', 'Sylvain', '02 43 83 38 68', '', 'sylvain.meignier@lium.univ-lemans.fr', '74');
INSERT INTO contact VALUES('637', 'BRAULT', 'SÃ©bastien', '02 43 77 78 17', '', 'sebastien.brault@vinci-energies.com', '408');
INSERT INTO contact VALUES('688', 'PULTZ', 'FrÃ©dÃ©rique', '01 58 69 44 01', '', 'Frederique.PULTZ@vinci-energies.com', '408');
INSERT INTO contact VALUES('689', 'DUVAL', 'Sabrina', '07.83.18.14.81', '', 'sabrina.duval@proavancia.com', '439');
INSERT INTO contact VALUES('680', 'YamÃ©ogo', 'Antoine', '01 41 24 43 20', '', 'ayameogo@excilys.com', '434');
INSERT INTO contact VALUES('578', 'LEMOINE', 'David', '02 51 85 81 00', '', 'david.lemoine@mines-nantes.fr', '379');
INSERT INTO contact VALUES('675', 'RAMON', 'STEPHANE', '0610611019', '', 'stephane.ramon@ofib.fr', '430');
INSERT INTO contact VALUES('583', 'DAHAN', 'Guillomme', '02 28 20 15 05', '', 'guillomme.dahan@capgemini.com', '179');
INSERT INTO contact VALUES('584', 'ROY', 'Martin', '02 77 27 77 20', '', 'mroy@umanis.com', '284');
INSERT INTO contact VALUES('585', 'GIRAUD', 'Vincent', '06 74 44 04 58', '', 'vincent.giraud@sopragroup.com', '232');
INSERT INTO contact VALUES('586', 'CHARPENTIER', 'Wilfried', '02 99 27 45 45', '', 'wilfried.charpentier@capgemini.com', '337');
INSERT INTO contact VALUES('587', 'DIALLO', 'Mariana', '01 41 10 29 91', '', 'diallo@apside.fr', '381');
INSERT INTO contact VALUES('588', 'MOREAU', 'Julien', '02 99 27 84 74', '', 'julien.moreau@capgemini.com', '337');
INSERT INTO contact VALUES('589', 'RINCHE', 'Nicolas', '02 43 57 15 70', '', 'nicolas.rinche@infotel.com', '343');
INSERT INTO contact VALUES('590', 'DUMONT', 'Paul', '04 76 40 40 17', '', 'p.dumont@absalto.com', '382');
INSERT INTO contact VALUES('591', 'LEBLANC', 'JÃ©rÃ©my', '02 53 04 40 17', '', 'jeremy.leblanc@novia-systems.fr', '340');
INSERT INTO contact VALUES('592', 'VOGEL', 'Brice', '03 87 34 45 30', '', 'b-vogel@uem-metz.fr', '383');
INSERT INTO contact VALUES('593', 'GITEAU', 'Samuel', '02 41 29 33 46', '', 'samuel.giteau@thalesgroup.com', '384');
INSERT INTO contact VALUES('594', 'ESTEVE', 'Yannick', '02 43 83 38 55', '', 'yannick.esteve@lium.univ-lemans.fr', '74');
INSERT INTO contact VALUES('595', 'MORET', 'JÃ©rÃ´me', '07 63 00 45 65', '', 'jerome.moret@glplus.fr', '385');
INSERT INTO contact VALUES('596', 'BOILEAU', 'Thierry', '02 43 41 22 07', '', 'thierry.boileau@gkndriveline.com', '33');
INSERT INTO contact VALUES('597', 'APPARICIO', 'Denis', '02 43 57 44 66', '', 'denis.apparicio@sesam-vitale.fr', '294');
INSERT INTO contact VALUES('598', 'HAMDI', 'Issam', '06 66 84 85 48', '', 'i.hamdi@groupeonepoint.com', '386');
INSERT INTO contact VALUES('599', 'MINIAILO', 'Artem', '06 52 64 09 03', '', 'tioma@outlook.com', '321');
INSERT INTO contact VALUES('600', 'BEAUVIVRE', 'Vincent', '02 85 52 07 28', '', 'vbeauvivre@naoned-systemes.fr', '387');
INSERT INTO contact VALUES('601', 'KARPOV', 'Oleksiy', '+(38)0506382747', '', 'aleksey.karpov@datagroup.ua', '388');
INSERT INTO contact VALUES('602', 'DERAM', 'Nicolas', '01 84 16 47 87', '', 'contact@agicia.com', '389');
INSERT INTO contact VALUES('603', 'BERTON', 'Pierre', '02 43 57 42 00', '', 'pierre.berton@sesam-vitale.fr', '294');
INSERT INTO contact VALUES('604', 'TEUTSCH', 'Philippe', '02 43 83 38 66', '', 'philippe.teutsch@univ-lemans.fr', '390');
INSERT INTO contact VALUES('605', 'BAVOUZET', 'SÃ©bastien', '02.43.41.60.44', '', 'sebastien.bavouzet@groupe-mma.fr', '53');
INSERT INTO contact VALUES('606', 'THURET', 'JÃ©rÃ´me', '02.43.41.89.78', '', 'jerome.thuret@groupe-mma.fr', '53');
INSERT INTO contact VALUES('607', 'PELTIER', 'Wilfried', '02.43.41.89.78', '', 'wilfried.peltier@groupe-mma.fr', '53');
INSERT INTO contact VALUES('608', 'BETHOUX', 'Lionel', '02.43.41.59.59', '', 'lionel.bethoux@groupe-mma.fr', '53');
INSERT INTO contact VALUES('609', 'JACOB', 'Christelle', '02.43.78.72.81', '', 'Christelle.JACOB@groupe-sephira.fr', '26');
INSERT INTO contact VALUES('611', 'BLEAU', 'StÃ©phane', '02 37 33 80 10 ', '', 'stephane.bleau@groupe-mma.fr', '335');
INSERT INTO contact VALUES('612', 'GIRARD', 'Laurence', '02 53 35 72 13', '', 'ees-contact@ees-assurance.fr', '334');
INSERT INTO contact VALUES('690', 'GAZON', 'Laure', '02.53.04.40.16', '', 'LAURE.GAZON@POLYMONT.FR', '340');
INSERT INTO contact VALUES('614', 'GAUTIER', 'Benoit', ' ', '', 'benoit.gautier@capgemini.com', '179');
INSERT INTO contact VALUES('615', 'DANIEL', 'Mariane', ' ', '', 'mariane.daniel@alcatel-lucent.com', '392');
INSERT INTO contact VALUES('698', 'JABBOUR', 'Marie-HÃ©lÃ¨ne', ' ', '', 'marie-helene.jabbour@cgi.com', '163');
INSERT INTO contact VALUES('654', 'FENNICHE', 'Valentin', '02 77 27 77 20', '', 'vfenniche@umanis.com', '284');
INSERT INTO contact VALUES('655', 'Hatzenbuhler', 'Jean-Damien', '02 99 27 45 45', '', 'jean-damien.hatzenbuhler@capgemini.com', '337');
INSERT INTO contact VALUES('656', 'Lagrange', 'FrÃ©dÃ©ric', '02 44 02 13 41', '', 'frederic.lagrange@2la-software.com', '420');
INSERT INTO contact VALUES('657', 'Delafosse', 'Philippe', ' ', '', 'philippe.delafosse@groupe-mma.fr', '53');
INSERT INTO contact VALUES('658', 'MONTAGNE', 'Christian', ' ', '', 'christian.montagne@groupe-mma.fr', '53');
INSERT INTO contact VALUES('659', 'CROISEAU', 'Julien', '02 43 74 35 44', '', 'julien.croiseau@coulaines.fr', '421');
INSERT INTO contact VALUES('660', 'RODRIGUEZ', 'Ignacio', '02 43 14 10 10', '', 'ignacio.rodriguez@apotamox.fr', '261');
INSERT INTO contact VALUES('661', 'DURET', 'Vincent', '02 41 27 57 27', '', 'vincent.duret@alcuin.com', '422');
INSERT INTO contact VALUES('662', 'MORIN', 'Christian', '02 43 14 16 16', '', 'cmorin@coclico.fr', '272');
INSERT INTO contact VALUES('663', 'BOUVET', 'Michel', '01 41 56 90 19', '', ' ', '423');
INSERT INTO contact VALUES('696', 'Delafosse', 'Julien', ' ', '', 'julien.delafosse@groupe-mma.fr', '53');
INSERT INTO contact VALUES('665', 'LAUREAUX', 'Nicolas', '01 58 13 16 14', '', 'nicolas.laureaux@hsbc.com', '425');
INSERT INTO contact VALUES('666', 'CHAILLOT', 'Mathias', '02 43 57 42 00', '', 'mathias.chaillot@sesam-vitale.fr', '294');
INSERT INTO contact VALUES('667', 'BOUCLIER', 'Emmanuel', '02 43 57 42 00', '', 'emmanuel.bouclier@sesam-vitale.fr', '294');
INSERT INTO contact VALUES('668', 'CHEVALLIER', 'HervÃ©', '02 43 77 78 15', '', 'herve.chevallier@vinci-energies.com', '408');
INSERT INTO contact VALUES('669', 'GESNOUIN', 'Fabrice', '01 74 95 74 84', '', 'fabrice.gesnouin@transatel.com', '426');
INSERT INTO contact VALUES('670', 'TURPIN', 'Karine', '02.43.43.78.03', '', 'kturpin@jacques-denis.com', '239');
INSERT INTO contact VALUES('671', 'ABDILLAHI ADEN', 'Michel', '02 43 75 94 32', '', ' ', '427');
INSERT INTO contact VALUES('672', 'VIGOT', 'SÃ©verin', '06 XX XX XX XX', '', 'severin.vigot@ez-nzrgy.fr', '428');
INSERT INTO contact VALUES('673', 'RUDEAU', 'Vincent', '02.43.41.88.83', '', 'vincent.rudeau@groupe-mma.fr', '53');
INSERT INTO contact VALUES('691', 'Roudil', 'Sandra', '04.99.58.17.35', '', 'sandra.roudil@orangelogic.com', '440');
INSERT INTO contact VALUES('699', 'SIRET', 'Christine', ' ', '', 'servicerhformation@sigma.fr', '443');
INSERT INTO contact VALUES('700', ' ', 'Claire', ' ', '', 'claire@microtec.fr', '444');
INSERT INTO contact VALUES('701', 'DACUNHA', 'HÃ©lÃ¨ne', ' ', '', 'helene.dacunha@apotamox.com', '261');
INSERT INTO contact VALUES('702', 'DELOUCHE', 'GaÃ«lle', ' ', '', 'gaelle.delouche@adg-software.fr', '445');
INSERT INTO contact VALUES('703', 'SABOURET', 'Nicolas', '01 69 85 80 80', '', 'Nicolas.Sabouret@limsi.fr', '446');
INSERT INTO contact VALUES('704', 'MEUNIER', 'Adrien', '02 43 50 27 50', '', 'adrien.meunier@datasyscom.fr', '57');
INSERT INTO contact VALUES('705', 'Chaurand', 'Philippe', '0674580658', '', 'contact@anomes.com', '447');
INSERT INTO contact VALUES('706', 'CHEMIN', 'Bernard', '02 43 41 22 68', '', 'bernard.chemin@gkndriveline.com', '33');
INSERT INTO contact VALUES('708', 'SCHWARTZ', 'Johnny', ' ', '', 'johnny.schwartz@vinci-energies.com', '408');
INSERT INTO contact VALUES('709', 'BARRAULT', 'LoÃ¯c', '02 43 83 38 33', '', 'loic.barrault@univ-lemans.fr', '74');
INSERT INTO contact VALUES('710', 'LARCHER', 'Anthony', '02 43 83 38 30', '', 'anthony.larcher@univ-lemans.fr', '74');
INSERT INTO contact VALUES('711', 'PETITRENAUD', 'Simon', '02 43 83 38 28', '', 'simon.petitrenaud@univ-lemans', '74');
INSERT INTO contact VALUES('712', 'COUDRAY', 'Anthony', ' ', '', 'anthony.coudray@unfotel.com', '343');
INSERT INTO contact VALUES('713', 'MEUDEC', 'AnaÃ«lle', '02.43.57.44.39', '', 'Anaelle.MEUDEC@sesam-vitale.fr', '294');
INSERT INTO contact VALUES('714', 'ROUSSE', 'JÃ©rÃ©my', '02 77 27 77 20', '', 'jrousse@umanis.com', '284');

-- -----------------------------
-- insertions dans la table convention
-- -----------------------------
INSERT INTO convention VALUES('1', 'M2_DUGAST_Renaud_0910.pdf', '1', '0.00', '10', '9', '17', '69', '62', '4');
INSERT INTO convention VALUES('2', 'Pas de rÃ©sumÃ©', '0', '0.00', '7', '6', '4', '85', '127', '0');
INSERT INTO convention VALUES('3', 'Pas de rÃ©sumÃ©', '0', '0.00', '9', '10', '26', '67', '287', '0');
INSERT INTO convention VALUES('4', 'M2_COUTABLE_Julien_0910.pdf', '1', '0.00', '1', '2', '15', '74', '129', '0');
INSERT INTO convention VALUES('5', 'Pas de rÃ©sumÃ©', '0', '0.00', '7', '6', '5', '80', '130', '0');
INSERT INTO convention VALUES('6', 'Pas de rÃ©sumÃ©', '0', '0.00', '16', '5', '16', '88', '131', '0');
INSERT INTO convention VALUES('108', 'DÃ©veloppement d\'un intranet de rÃ©fÃ©rentiel de gestion des variables (RGV) applicative.<br/> <br/> Recueillir/valider les besoins des utilisateurs. Etablir le cahier des charges en collaboration avec l\'Ã©quipe support (responsable des dÃ©veloppements du site). DÃ©velopper les Ã©volutions, maintenances du site dans les technologies FLEX et JAVA. Fournir les documentations sur les dÃ©veloppements effectuÃ©s (Word) et Ã©tudes rÃ©alisÃ©es (powerpoint). Faire de l\'assistance technique dans le cadre du dÃ©ploiement de l\'intranet.', '0', '0.00', '2', '1', '63', '144', '141', '0');
INSERT INTO convention VALUES('7', 'Pas de rÃ©sumÃ©', '0', '0.00', '12', '22', '2', '63', '132', '0');
INSERT INTO convention VALUES('8', 'M2_BRIZARD_Adrien_0910.pdf', '1', '0.00', '2', '1', '12', '73', '133', '0');
INSERT INTO convention VALUES('9', 'M2_CLAYER_Jean-Pierre_0910.pdf', '1', '0.00', '9', '10', '13', '70', '134', '0');
INSERT INTO convention VALUES('10', 'Pas de rÃ©sumÃ©', '0', '0.00', '4', '6', '3', '78', '135', '0');
INSERT INTO convention VALUES('11', 'Pas de rÃ©sumÃ©', '0', '0.00', '4', '7', '7', '79', '136', '0');
INSERT INTO convention VALUES('101', 'M2_DEGROOT_Francois-xavier_1011.pdf', '1', '0.00', '15', '24', '38', '156', '286', '0');
INSERT INTO convention VALUES('12', 'M2_GERAULT_AurÃ©lien_0910.pdf', '1', '0.00', '6', '7', '9', '38', '137', '0');
INSERT INTO convention VALUES('13', 'Pas de rÃ©sumÃ©', '0', '0.00', '7', '6', '8', '84', '138', '0');
INSERT INTO convention VALUES('104', 'Activity Analysis est une application qui permet de fournir aux utilisateurs des statistiques et des informations dÃ©taillÃ©es sur les appels effectuÃ©s par les clients des opÃ©rateurs de tÃ©lÃ©phonie mobile.L\'application est capable de traiter en base de donnÃ©es Mysql des informations issues de plusieurs sources de donnÃ©es diffÃ©rentes. Des fichiers de configuration assez complexe (40 000 lignes) permettent d\'adapter la restitution des informations Ã  ces sources de donnÃ©es. Le stage consiste Ã  crÃ©er un outil de validation automatique des fichiers XML de configuration (DÃ©tection des balises non remplies, vÃ©rifications des doublons, ainsi que des vÃ©rifications plus avancÃ©es liÃ©es au fonctionnel). Au sein du projet Activity Analysis (5 personnes), en relation avec le chef de projet, le stagiaire sera en charge de la conception, de l\'implÃ©mentation et de la validation de ce module.', '0', '0.00', '25', '11', '54', '158', '289', '0');
INSERT INTO convention VALUES('14', 'Pas de rÃ©sumÃ©', '0', '0.00', '6', '7', '157', '82', '139', '0');
INSERT INTO convention VALUES('102', 'M2_KOZIUBERDA_Iuliia_1011.pdf', '1', '0.00', '14', '3', '48', '', '287', '0');
INSERT INTO convention VALUES('15', 'Pas de rÃ©sumÃ©', '0', '0.00', '4', '6', '1', '86', '140', '0');
INSERT INTO convention VALUES('16', 'M2_SAADAOUI_Anis_0910.pdf', '1', '0.00', '2', '1', '32', '76', '141', '0');
INSERT INTO convention VALUES('99', 'RÃ©aliser les fonctions de crÃ©er, de modifier, de supprimer et de chercher des donnÃ©es en utilisant le JSP, le XML, etcâ¦ RÃ©aliser une fonction d\'acheter des livres si nÃ©cessaire.', '0', '0.00', '1', '2', '156', '141', '284', '0');
INSERT INTO convention VALUES('100', 'M2_BEAUDOIRE_Cedrick_1011.pdf', '1', '0.00', '23', '16', '37', '138', '285', '0');
INSERT INTO convention VALUES('17', 'Pas de rÃ©sumÃ©', '0', '0.00', '1', '2', '19', '72', '142', '0');
INSERT INTO convention VALUES('106', 'M2_PAYET_Francois_1011.pdf', '1', '0.00', '10', '9', '55', '147', '291', '0');
INSERT INTO convention VALUES('18', 'M2_PARIS_Romain_0910.pdf', '1', '0.00', '5', '16', '28', '89', '12', '0');
INSERT INTO convention VALUES('19', 'M2_TROCHERIE_Julien_0910.pdf', '1', '0.00', '15', '11', '33', '91', '144', '0');
INSERT INTO convention VALUES('98', 'Maintenance Ã©volutive et corrective du Portail Mobile Orange France.', '0', '0.00', '16', '23', '43', '139', '283', '0');
INSERT INTO convention VALUES('20', 'Pas de rÃ©sumÃ©', '0', '0.00', '12', '22', '14', '65', '145', '0');
INSERT INTO convention VALUES('21', 'Pas de rÃ©sumÃ©', '0', '0.00', '6', '7', '6', '83', '146', '0');
INSERT INTO convention VALUES('22', 'M2_GUYON_Erwann_0910.pdf', '1', '0.00', '1', '2', '20', '75', '142', '0');
INSERT INTO convention VALUES('23', 'M2_LE_ROY_Jonathan_0910.pdf', '1', '0.00', '16', '23', '24', '87', '147', '0');
INSERT INTO convention VALUES('24', 'Pas de rÃ©sumÃ©', '0', '0.00', '4', '6', '27', '81', '140', '0');
INSERT INTO convention VALUES('25', 'Pas de rÃ©sumÃ©', '0', '0.00', '14', '1', '18', '93', '148', '0');
INSERT INTO convention VALUES('107', 'M2_SAEWANG_Anukun_1011.pdf', '1', '0.00', '9', '10', '59', '145', '292', '0');
INSERT INTO convention VALUES('26', 'Pas de rÃ©sumÃ©', '0', '0.00', '10', '9', '10', '68', '149', '0');
INSERT INTO convention VALUES('110', 'M2_MARTIN_Gwendal_1011.pdf', '1', '0.00', '5', '22', '50', '150', '294', '0');
INSERT INTO convention VALUES('27', 'M2_ARIS_Mariama_0910.pdf', '1', '0.00', '2', '1', '11', '71', '150', '0');
INSERT INTO convention VALUES('109', 'M2_VENOT_David_1011.pdf', '1', '0.00', '1', '2', '62', '143', '293', '0');
INSERT INTO convention VALUES('28', 'M2_LAMBERT_FranÃ§ois_0910.pdf', '1', '0.00', '4', '7', '21', '77', '151', '0');
INSERT INTO convention VALUES('29', 'Pas de rÃ©sumÃ©', '0', '0.00', '16', '23', '25', '90', '152', '0');
INSERT INTO convention VALUES('105', 'M2_PERTHUIS_Francois_1011.pdf', '1', '0.00', '24', '14', '56', '154', '290', '0');
INSERT INTO convention VALUES('30', 'M2_PERCHARD_Julien_0910.pdf', '1', '0.00', '15', '11', '30', '92', '144', '0');
INSERT INTO convention VALUES('31', 'M2_PATAULT_Kevin_0910.pdf', '1', '0.00', '14', '1', '29', '94', '153', '0');
INSERT INTO convention VALUES('35', 'M2_LEJEUNE_Bryan_0910.pdf', '1', '0.00', '11', '15', '23', '96', '143', '0');
INSERT INTO convention VALUES('32', 'M2_LECONTE_Fabien_0910.pdf', '1', '0.00', '22', '12', '22', '64', '154', '0');
INSERT INTO convention VALUES('33', 'M2_PERCHERON_William_0910.pdf', '1', '0.00', '22', '12', '31', '66', '154', '0');
INSERT INTO convention VALUES('34', 'Pas de rÃ©sumÃ©', '0', '0.00', '11', '15', '34', '95', '155', '0');
INSERT INTO convention VALUES('36', 'Pas de rÃ©sumÃ©', '0', '0.00', '9', '10', '40', '36', '40', '0');
INSERT INTO convention VALUES('37', 'Pas de rÃ©sumÃ©', '0', '13.00', '17', '18', '83', '22', '157', '0');
INSERT INTO convention VALUES('38', 'L3P_BELLANGER_Nicolas_0910.pdf', '1', '14.50', '17', '18', '65', '17', '158', '0');
INSERT INTO convention VALUES('39', 'L3P_HOHLER_Geoffrey_0910.pdf', '1', '14.00', '17', '18', '75', '21', '159', '0');
INSERT INTO convention VALUES('40', 'Pas de rÃ©sumÃ©', '0', '0.00', '18', '17', '70', '19', '160', '0');
INSERT INTO convention VALUES('41', 'Pas de rÃ©sumÃ©', '0', '12.00', '18', '17', '79', '23', '161', '0');
INSERT INTO convention VALUES('42', 'L3P_CHABROUX_Mickael_0910.pdf', '1', '14.00', '18', '17', '69', '18', '162', '0');
INSERT INTO convention VALUES('43', 'L3P_DELAFOSSE_Romain_0910.pdf', '1', '15.00', '19', '20', '71', '27', '163', '0');
INSERT INTO convention VALUES('44', 'L3P_CARIOU_Florent_0910.pdf', '1', '9.00', '19', '20', '67', '26', '62', '0');
INSERT INTO convention VALUES('124', 'L3P_RAIMBAULT_Denis_1011.pdf', '1', '14.00', '17', '18', '128', '111', '312', '0');
INSERT INTO convention VALUES('45', 'Pas de rÃ©sumÃ© ', '1', '13.00', '19', '20', '74', '25', '164', '0');
INSERT INTO convention VALUES('46', 'L3P_TURMEAU_Anthony_0910.pdf', '1', '13.00', '8', '14', '84', '31', '165', '0');
INSERT INTO convention VALUES('121', 'Analyse, conception, dÃ©veloppement de composants logiciels, dans le cadre d\'un framework utilisÃ© sur un centre de services de 12 dÃ©veloppeurs. Les dÃ©veloppements alimentent un SI de gestion pour administration publique. Le socle technique de ce framework se base sur le J2EE actuel (Java6, EJB3 en architecture distribuÃ©e, JSF2, Richfaces 4).', '0', '0.00', '25', '11', '49', '160', '304', '0');
INSERT INTO convention VALUES('47', 'L3P_DUFLOT_Alexis_0910.pdf', '1', '14.00', '8', '14', '72', '32', '166', '0');
INSERT INTO convention VALUES('54', 'L3P_HOREL_Marc-Antoine_0910.pdf', '1', '14.00', '8', '14', '76', '33', '167', '0');
INSERT INTO convention VALUES('122', 'M2_GAALOUL_Wael_1011.pdf', '1', '0.00', '16', '4', '42', '161', '305', '0');
INSERT INTO convention VALUES('55', 'Pas de rÃ©sumÃ©', '0', '0.00', '23', '16', '64', '45', '173', '0');
INSERT INTO convention VALUES('49', 'Pas de rÃ©sumÃ©', '0', '14.00', '20', '19', '78', '29', '168', '0');
INSERT INTO convention VALUES('123', 'Pas de rÃ©sumÃ©', '0', '12.00', '17', '18', '121', '112', '311', '0');
INSERT INTO convention VALUES('50', 'L3P_PERRIER_Vincent_0910.pdf', '1', '13.00', '20', '19', '81', '28', '169', '0');
INSERT INTO convention VALUES('51', 'Pas de rÃ©sumÃ©', '0', '12.00', '20', '19', '80', '30', '170', '0');
INSERT INTO convention VALUES('52', 'Pas de rÃ©sumÃ©', '0', '0.00', '17', '18', '108', '20', '171', '0');
INSERT INTO convention VALUES('53', 'Pas de rÃ©sumÃ©', '0', '12.00', '18', '17', '85', '24', '172', '0');
INSERT INTO convention VALUES('56', 'M1_MERCIER_Julien_0910.pdf', '1', '0.00', '23', '16', '53', '43', '174', '0');
INSERT INTO convention VALUES('114', 'M2_ROCHE_Sebastien_1011.pdf', '1', '0.00', '10', '9', '58', '148', '297', '0');
INSERT INTO convention VALUES('57', 'M1_JOYAUX_RÃ©mi_0910.pdf', '1', '0.00', '16', '23', '44', '39', '175', '0');
INSERT INTO convention VALUES('116', 'RÃ©alisation d\'un logiciel de gestion de laboratoire.<br/> <br/> Le logiciel a dÃ©velopper doit assurer les tÃ¢ches suivantes : enregistrement des dossiers d\'affaires, acquisition des donnÃ©es en provenance des appareils, mise en forme des donnÃ©es, Ã©dition des bulletins d\'essais et d\'analyses, Ã©tablissement et transmission des rapports techniques, management de la qualitÃ©.', '0', '0.00', '14', '24', '36', '153', '299', '0');
INSERT INTO convention VALUES('58', 'M1_DUPUY_GrÃ©gory_0910.pdf', '1', '0.00', '5', '15', '41', '59', '47', '0');
INSERT INTO convention VALUES('59', 'M1_KOZIUBERDA_Iuliia_0910.pdf', '1', '0.00', '5', '15', '48', '61', '47', '0');
INSERT INTO convention VALUES('60', 'M1_SAEWANG_Anukun_0910.pdf', '1', '0.00', '5', '15', '59', '57', '120', '0');
INSERT INTO convention VALUES('61', 'M1_DELALONDE_Thomas_0910.pdf', '1', '0.00', '5', '15', '39', '58', '126', '0');
INSERT INTO convention VALUES('117', 'Afin de sÃ©curiser les livraisons de nos solutions lors d\'un cycle projet classiques ou pour rÃ©pondre aux besoins de rÃ©activitÃ©, le projet consistera Ã  dÃ©velopper une solution de livraison qui contrÃ´le et garantisse la cohÃ©rance des Ã©lÃ©ments techniques. AprÃ¨s une pÃ©riode d\'analyse des produits HP et de dÃ©finition d\'un cahier des charges, le projet consistera en la description de la solution, au choix des technologies et Ã  leur implÃ©mentation. CompÃ©tences : Web, (perl), SGBD.', '0', '0.00', '24', '15', '57', '155', '300', '0');
INSERT INTO convention VALUES('62', 'M1_JUPIN_Jonathan_0910.pdf', '1', '0.00', '1', '2', '45', '51', '81', '0');
INSERT INTO convention VALUES('63', 'M1_KABA_LancinÃ©_0910.pdf', '1', '0.00', '15', '5', '46', '60', '125', '0');
INSERT INTO convention VALUES('64', 'Pas de rÃ©sumÃ©', '0', '0.00', '15', '5', '86', '56', '125', '0');
INSERT INTO convention VALUES('119', 'Elaboration de l\'outil d\'administration du logiciel de gestion.<br/> <br/> Participer Ã  l\'Ã©laboration du cahier des charges. Participer Ã  la rÃ©daction des spÃ©cifications techniques. Developper un outil de gestion des Ã©crans (gÃ©nÃ©rÃ©s automatiquement et couplÃ©s Ã  la base de donnÃ©es). DÃ©velopper un outil de gestion des jobs (extraction de statistiques, etc...)', '0', '0.00', '2', '1', '157', '142', '302', '0');
INSERT INTO convention VALUES('65', 'M1_GAALOUL_WaÃ«l_0910.pdf', '1', '0.00', '15', '5', '42', '62', '125', '0');
INSERT INTO convention VALUES('66', 'M1_VENOT_David_0910.pdf', '1', '0.00', '1', '2', '62', '50', '117', '0');
INSERT INTO convention VALUES('111', 'M2_MENG_Fanrong_1011.pdf', '1', '0.00', '22', '5', '52', '149', '295', '0');
INSERT INTO convention VALUES('67', 'Pas de rÃ©sumÃ©', '0', '0.00', '16', '23', '63', '44', '20', '0');
INSERT INTO convention VALUES('68', 'M1_MARTIN_Gwendal_0910.pdf', '1', '0.00', '9', '10', '50', '34', '176', '0');
INSERT INTO convention VALUES('115', 'M2_DOSU NGAMPILA_Chouga_1011.pdf', '1', '0.00', '9', '10', '40', '146', '298', '0');
INSERT INTO convention VALUES('69', 'M1_MENG_Fanrong_0910.pdf', '1', '0.00', '16', '23', '52', '40', '131', '0');
INSERT INTO convention VALUES('70', 'Pas de rÃ©sumÃ©', '0', '0.00', '12', '22', '51', '46', '177', '0');
INSERT INTO convention VALUES('71', 'Pas de rÃ©sumÃ©', '0', '0.00', '12', '22', '55', '47', '85', '0');
INSERT INTO convention VALUES('72', 'M1_PERTHUIS_FranÃ§ois_0910.pdf', '1', '0.00', '22', '12', '56', '48', '178', '0');
INSERT INTO convention VALUES('73', 'M1_RAULIC_Julien_0910.pdf', '1', '0.00', '2', '1', '57', '53', '85', '0');
INSERT INTO convention VALUES('74', 'Pas de rÃ©sumÃ©', '0', '0.00', '2', '1', '54', '52', '179', '0');
INSERT INTO convention VALUES('120', 'M2_DELALONDE_Thomas_1011.pdf', '1', '0.00', '11', '25', '39', '157', '303', '0');
INSERT INTO convention VALUES('75', 'M1_LECLERCQ_Pascal_0910.pdf', '1', '0.00', '11', '14', '49', '41', '180', '0');
INSERT INTO convention VALUES('76', 'M1_DEGROOT_FranÃ§ois-Xavier_0910.pdf', '1', '0.00', '11', '14', '38', '54', '59', '0');
INSERT INTO convention VALUES('77', 'M1_SALL_Mama_0910.pdf', '1', '0.00', '22', '12', '60', '49', '84', '0');
INSERT INTO convention VALUES('113', 'M2_STUBI_Thomas_1011.pdf', '1', '0.00', '23', '16', '61', '140', '296', '0');
INSERT INTO convention VALUES('78', 'Pas de rÃ©sumÃ©', '0', '0.00', '10', '9', '43', '35', '181', '0');
INSERT INTO convention VALUES('79', 'Pas de rÃ©sumÃ©', '0', '0.00', '10', '9', '58', '37', '181', '0');
INSERT INTO convention VALUES('80', 'Pas de rÃ©sumÃ©', '0', '0.00', '14', '11', '37', '42', '180', '0');
INSERT INTO convention VALUES('81', 'M1_STUBI_Thomas_0910.pdf', '1', '0.00', '14', '11', '61', '55', '119', '0');
INSERT INTO convention VALUES('112', 'M2_JOYAUX_Remi_1011.pdf', '1', '0.00', '5', '4', '44', '151', '47', '0');
INSERT INTO convention VALUES('82', 'D2_DURANTEAU_Florian_0910.pdf', '1', '0.00', '8', '14', '189', '15', '182', '0');
INSERT INTO convention VALUES('83', 'D2_TOUSE_Florian_0910.pdf', '1', '0.00', '21', '13', '207', '6', '183', '0');
INSERT INTO convention VALUES('84', 'Pas de rÃ©sumÃ©', '0', '0.00', '7', '6', '174', '14', '184', '0');
INSERT INTO convention VALUES('85', 'D2_DAUMAS_Antoine_0910.pdf', '1', '0.00', '6', '7', '89', '11', '185', '0');
INSERT INTO convention VALUES('127', 'L3P_LARDON_Benjamin_1011.pdf', '1', '15.00', '18', '17', '122', '110', '315', '0');
INSERT INTO convention VALUES('128', 'L3P_DE PIERREPONT_Solene_1011.pdf', '1', '12.00', '18', '17', '115', '114', '168', '0');
INSERT INTO convention VALUES('129', 'L3P_BESNARDEAU_Alan_1011.pdf', '1', '14.50', '18', '17', '111', '113', '47', '0');
INSERT INTO convention VALUES('130', 'L3P_RAULY_Julien_1011.pdf', '1', '12.00', '18', '17', '129', '108', '195', '0');
INSERT INTO convention VALUES('86', 'D2_LUTTMAN_Geoffroy_0910.pdf', '1', '0.00', '7', '6', '124', '13', '186', '0');
INSERT INTO convention VALUES('87', 'D2_CHOJNACKI_Mathieu_0910.pdf', '1', '0.00', '6', '7', '93', '12', '187', '0');
INSERT INTO convention VALUES('88', 'D2_RIVAL_Guillaume_0910.pdf', '1', '0.00', '14', '8', '100', '16', '89', '0');
INSERT INTO convention VALUES('89', 'D2_SALLEY_Karl_0910.pdf', '1', '0.00', '13', '21', '247', '7', '188', '0');
INSERT INTO convention VALUES('90', 'D2_TAMARELLE_Charly_0910.pdf', '1', '0.00', '21', '13', '90', '4', '189', '0');
INSERT INTO convention VALUES('125', 'L3P_PASCAL_Guillaume_1011.pdf', '1', '15.00', '17', '18', '125', '107', '313', '0');
INSERT INTO convention VALUES('126', 'L3P_RICORDEAU_Alexandre_1011.pdf', '1', '15.00', '17', '18', '130', '109', '314', '0');
INSERT INTO convention VALUES('91', 'Pas de rÃ©sumÃ©', '0', '0.00', '13', '21', '96', '8', '190', '0');
INSERT INTO convention VALUES('92', 'D2_BEN_HASSEN_Jonathan_0910.pdf', '1', '0.00', '21', '13', '98', '', '191', '0');
INSERT INTO convention VALUES('93', 'D2_RAULIC_Vincent_0910.pdf', '1', '0.00', '13', '21', '99', '10', '116', '0');
INSERT INTO convention VALUES('94', 'Pas de rÃ©sumÃ©', '0', '0.00', '21', '13', '109', '5', '192', '0');
INSERT INTO convention VALUES('95', 'Pas de rÃ©sumÃ©', '0', '0.00', '13', '21', '123', '9', '193', '0');
INSERT INTO convention VALUES('131', 'L3P_GOULET_Benjamin_1011.pdf', '1', '14.00', '19', '20', '120', '100', '316', '0');
INSERT INTO convention VALUES('103', 'Portage d\'application Iphone sur AndroÃ¯d.', '0', '0.00', '4', '5', '155', '152', '288', '0');
INSERT INTO convention VALUES('118', 'M2_WAN_Lei_1011.pdf', '1', '0.00', '11', '1', '64', '159', '301', '0');
INSERT INTO convention VALUES('96', 'L3P_PIERRES_Arnaud_0910.pdf', '1', '13.00', '8', '14', '82', '97', '194', '0');
INSERT INTO convention VALUES('97', 'Pas de rÃ©sumÃ©', '0', '12.00', '19', '20', '73', '98', '195', '0');
INSERT INTO convention VALUES('132', 'L3P_LUTTMANN_Geoffroy_1011.pdf', '1', '17.00', '19', '20', '124', '102', '317', '0');
INSERT INTO convention VALUES('133', 'L3P_SALMON_Yann_1011.pdf', '1', '12.00', '19', '20', '131', '104', '164', '0');
INSERT INTO convention VALUES('134', 'L3P_DUBOIS_Julien_1011.pdf', '1', '15.00', '19', '20', '117', '106', '157', '0');
INSERT INTO convention VALUES('135', 'Pas de rÃ©sumÃ©', '0', '14.00', '20', '19', '110', '105', '318', '0');
INSERT INTO convention VALUES('136', 'Pas de rÃ©sumÃ©', '0', '11.00', '20', '19', '119', '101', '319', '0');
INSERT INTO convention VALUES('137', 'Pas de rÃ©sumÃ©', '0', '12.00', '20', '19', '118', '99', '320', '0');
INSERT INTO convention VALUES('138', 'Pas de rÃ©sumÃ©', '0', '13.00', '20', '19', '123', '103', '265', '0');
INSERT INTO convention VALUES('139', 'L3P_BUON_Tristan_1011.pdf', '1', '15.00', '8', '1', '113', '115', '321', '0');
INSERT INTO convention VALUES('140', 'L3P_COME_Benjamin_1011.pdf', '1', '15.00', '8', '1', '114', '116', '322', '0');
INSERT INTO convention VALUES('141', 'M1_SAGOT_RAISSA_1011.pdf', '1', '0.00', '26', '11', '150', '130', '323', '0');
INSERT INTO convention VALUES('142', 'M1_LAMBERDIERE_KILIAN_1011.pdf', '1', '0.00', '1', '2', '141', '127', '324', '0');
INSERT INTO convention VALUES('143', 'Analyse de logiciels courants, conception et crÃ©ation d\'un nouveau logiciel d\'utilisation Ã  base de SQL.', '0', '0.00', '15', '11', '137', '136', '325', '0');
INSERT INTO convention VALUES('144', 'M1_KARTASHOV_VOLODYMYR_1011.pdf', '1', '0.00', '15', '11', '138', '137', '326', '0');
INSERT INTO convention VALUES('145', 'M1_DARDE_FABIEN_1011.pdf', '1', '0.00', '1', '2', '135', '126', '324', '0');
INSERT INTO convention VALUES('146', 'M1_BEN AYED_GHASSENE_1011.pdf', '1', '0.00', '10', '9', '132', '129', '263', '0');
INSERT INTO convention VALUES('147', 'M1_LOISEAU_ESTEBAN_1011.pdf', '1', '0.00', '23', '16', '143', '122', '327', '0');
INSERT INTO convention VALUES('148', 'M1_DEMANTEV_MIKHAIL_1011.pdf', '1', '0.00', '16', '23', '136', '123', '277', '0');
INSERT INTO convention VALUES('149', 'M1_PUSHKAREV_OLEG_1011.pdf', '1', '0.00', '21', '13', '147', '134', '328', '0');
INSERT INTO convention VALUES('150', 'M1_RANCHY_LUC_1011.pdf', '1', '0.00', '21', '13', '148', '132', '328', '0');
INSERT INTO convention VALUES('151', 'M1_LECHAT_JEREMY_1011.pdf', '1', '0.00', '13', '21', '142', '131', '328', '0');
INSERT INTO convention VALUES('152', 'M1_CHARTIER_CHRISTOPHE_1011.pdf', '1', '0.00', '22', '12', '134', '118', '195', '0');
INSERT INTO convention VALUES('153', 'M1_VIDAMENT-BROU_CHAD_1011.pdf', '1', '0.00', '12', '22', '211', '121', '195', '0');
INSERT INTO convention VALUES('154', 'M1_SAMOKHATKO_VOLODYMYR_1011.pdf', '1', '0.00', '2', '1', '151', '125', '329', '0');
INSERT INTO convention VALUES('155', 'CrÃ©ation d\'une application LIVE pour les 24H du Mans', '0', '0.00', '22', '12', '144', '120', '330', '0');
INSERT INTO convention VALUES('156', 'CrÃ©ation d\'un site internet', '0', '0.00', '12', '22', '154', '119', '331', '0');
INSERT INTO convention VALUES('157', 'M1_KOSTITCHEVA_IRINA_1011.pdf', '1', '0.00', '16', '23', '140', '124', '277', '0');
INSERT INTO convention VALUES('158', 'M1_NANPIWONG_DARIKA_1011.pdf', '1', '0.00', '11', '26', '145', '128', '332', '0');
INSERT INTO convention VALUES('159', 'DÃ©veloppement du systÃ¨me Ã  analyser SMS-s d\'un opÃ©rateur de tÃ©lÃ©phonie mobile en temps rÃ©el', '0', '0.00', '7', '6', '139', '', '333', '0');
INSERT INTO convention VALUES('160', 'DÃ©veloppement du systÃ¨me Ã  analyser SMS-s d\'un opÃ©rateur de tÃ©lÃ©phonie mobile en temps rÃ©el.', '0', '0.00', '6', '7', '149', '', '333', '0');
INSERT INTO convention VALUES('161', 'L3P_POTTIER_Nicolas_1011.pdf', '1', '14.00', '8', '1', '127', '117', '335', '0');
INSERT INTO convention VALUES('164', 'M2_KOSTITCHEVA_IRINA_1112.pdf', '1', '0.00', '9', '10', '140', '173', '374', '0');
INSERT INTO convention VALUES('387', '201_Master2_MELNYCHENKO_IVAN_1314.pdf', '1', '0.00', '1', '14', '201', '437', '615', '0');
INSERT INTO convention VALUES('418', '298_Master2_FEURPRIER_Audrey_1415.pdf', '1', '10.50', '11', '30', '298', '469', '611', '0');
INSERT INTO convention VALUES('419', 'Pas de rÃ©sumÃ©', '0', '13.00', '29', '4', '300', '482', '660', '0');
INSERT INTO convention VALUES('377', '312_Master1_STENZHORN_Julien_1314.pdf', '1', '8.00', '27', '24', '312', '394', '604', '0');
INSERT INTO convention VALUES('378', '307_Master1_PARME_Thibault_1314.pdf', '1', '14.00', '29', '4', '307', '400', '605', '0');
INSERT INTO convention VALUES('379', '315_Master1_VIRLOUVET_Xavier_1314.pdf', '1', '13.00', '4', '29', '315', '401', '606', '0');
INSERT INTO convention VALUES('380', '297_Master1_FENOUIL_SANDRINE_1314.pdf', '1', '16.00', '10', '9', '297', '433', '607', '0');
INSERT INTO convention VALUES('381', '305_Master1_MARTEAU_Morgane_1314.pdf', '1', '14.00', '10', '9', '305', '408', '608', '0');
INSERT INTO convention VALUES('382', '302_Master1_HENRY_Nathan_1314.pdf', '1', '14.00', '8', '1', '302', '402', '609', '0');
INSERT INTO convention VALUES('288', '277_Licence L3P_COLLET_Adriano_1213.pdf', '1', '0.00', '18', '17', '277', '262', '388', '0');
INSERT INTO convention VALUES('289', 'DÃ©veloppement Iphone', '0', '0.00', '4', '29', '282', '274', '428', '0');
INSERT INTO convention VALUES('290', 'DÃ©veloppement Web<br/>Mise en place d\'un site intranet. Mettre en Åuvre l\'utilisation dans l\'entreprise.', '0', '0.00', '26', '8', '271', '269', '436', '0');
INSERT INTO convention VALUES('291', '263_Licence L3P_DELAUNAY_Thomas_1213.pdf', '1', '0.00', '17', '18', '263', '265', '453', '0');
INSERT INTO convention VALUES('292', '268_Licence L3P_VALLET_Christopher_1213.pdf', '1', '0.00', '20', '19', '268', '259', '488', '0');
INSERT INTO convention VALUES('293', 'RÃ©aliser un site vitrine pour la SociÃ©tÃ© Levrat<br/>CrÃ©ation d\'un site vitrine marchand :IntÃ©gration du design du site : CrÃ©ation de 5 pages types (HTML / CSS)Base de donnÃ©es du site : CrÃ©ation d\'un back-office pour l\'ajout de produits, modification de page,â¦ (PHP/CSS, PHP, MySQL)Dynamisme du site : CrÃ©ation d\'un slide show (JQUERY, JAVASCRIPT). CrÃ©ation d\'une page produit avec effet loupe sur photo et changement de l\'image aprÃ¨s un clique sur un carrÃ© de couleur (JQUERY, JAVASCRIPT)RÃ©fÃ©rencement du site : Mise en place des norms W3C. PrÃ©paration Ã  l\'intÃ©gration du site sur Google Analytics et Webmaster. GÃ©nÃ©rer un sitemap.sml. Remplissage des balises meta.', '0', '0.00', '18', '17', '274', '261', '489', '0');
INSERT INTO convention VALUES('165', 'Stage en dÃ©veloppement WEB JAVA', '0', '0.00', '23', '22', '139', '181', '351', '0');
INSERT INTO convention VALUES('298', '267_Licence L3P_VAIRAA_Nicolas_1213.pdf', '1', '0.00', '20', '19', '267', '258', '494', '0');
INSERT INTO convention VALUES('166', 'Stage en dÃ©veloppement WEB JAVA', '0', '0.00', '23', '22', '149', '180', '351', '0');
INSERT INTO convention VALUES('167', 'M2_RANCHY_LUC_1112.pdf', '1', '0.00', '9', '10', '148', '174', '287', '0');
INSERT INTO convention VALUES('329', '283_Master2_GHORBEL_Afef_1314.pdf', '1', '12.00', '30', '14', '283', '380', '614', '0');
INSERT INTO convention VALUES('330', '233_Master2_GUEI_Kamonda_1314.pdf', '1', '13.00', '2', '1', '233', '342', '583', '0');
INSERT INTO convention VALUES('396', '320_Master1_AYDIN_Emre_1415.pdf', '1', '12.50', '8', '11', '320', '440', '618', '0');
INSERT INTO convention VALUES('446', 'Etudiante en alternance', '0', '0.00', '8', '3', '328', '0', '698', '0');
INSERT INTO convention VALUES('168', 'DÃ©veloppement d\'une application de suivi et de stratÃ©gie en temps rÃ©el de course automobile', '0', '0.00', '7', '6', '144', '179', '350', '0');
INSERT INTO convention VALUES('296', '275_Licence L3P_BUSSON_Kevin_1213.pdf', '1', '0.00', '19', '20', '275', '254', '492', '0');
INSERT INTO convention VALUES('297', '279_Licence L3P_PAPIN_Alexandre_1213.pdf', '1', '0.00', '17', '18', '279', '267', '493', '0');
INSERT INTO convention VALUES('169', 'M2_NANPIWONG_DARIKA_1112.pdf', '1', '0.00', '10', '9', '145', '175', '117', '0');
INSERT INTO convention VALUES('295', '280_Licence L3P_PET_Jeremie_1213.pdf', '1', '0.00', '18', '17', '280', '263', '491', '0');
INSERT INTO convention VALUES('170', 'M2_PUSHKAREV_OLEG_1112.pdf', '1', '0.00', '10', '9', '147', '176', '117', '0');
INSERT INTO convention VALUES('171', 'M2_DARDE_FABIEN_1112.pdf', '1', '0.00', '16', '1', '135', '183', '375', '0');
INSERT INTO convention VALUES('172', 'M2_BEN AYED_GHASSENE_1112.pdf', '1', '0.00', '1', '16', '132', '182', '376', '0');
INSERT INTO convention VALUES('300', '278_Licence L3P_DESBORDES_Romain_1213.pdf', '1', '0.00', '19', '20', '278', '255', '496', '0');
INSERT INTO convention VALUES('173', 'M2_VIDAMENT-BROU_CHAD_1112.pdf', '1', '0.00', '6', '7', '211', '167', '358', '0');
INSERT INTO convention VALUES('285', '208_Master2_TROTIN_RONAN_1213.pdf', '1', '0.00', '4', '29', '208', '315', '485', '0');
INSERT INTO convention VALUES('174', 'M2_WANG_WEI_1112.pdf', '1', '0.00', '6', '7', '154', '163', '358', '0');
INSERT INTO convention VALUES('361', '288_Master1_BLUM PHU NYIN_Ayit_1314.pdf', '1', '8.00', '31', '30', '288', '423', '428', '0');
INSERT INTO convention VALUES('284', '134_Master2_CHARTIER_CHRISTOPHE_1213.pdf', '1', '0.00', '26', '11', '134', '327', '618', '0');
INSERT INTO convention VALUES('175', 'M2_SAGOT_RAISSA_1112.pdf', '1', '0.00', '1', '2', '150', '178', '377', '0');
INSERT INTO convention VALUES('176', 'M2_LECHAT_JEREMY_1112.pdf', '1', '0.00', '1', '2', '142', '177', '377', '0');
INSERT INTO convention VALUES('177', 'M2_LAMBERDIERE_KILIAN_1112.pdf', '1', '0.00', '4', '5', '141', '185', '288', '0');
INSERT INTO convention VALUES('287', '180_Master2_BESNARD_VINCENT_1213.pdf', '1', '0.00', '1', '16', '180', '312', '487', '0');
INSERT INTO convention VALUES('178', 'M2_DEMENTEV_MIKHAIL_1112.pdf', '1', '0.00', '4', '5', '136', '184', '378', '0');
INSERT INTO convention VALUES('299', '262_Licence L3P_CAMUS_Pierre-Louis_1213.pdf', '1', '0.00', '17', '18', '262', '264', '495', '0');
INSERT INTO convention VALUES('286', '194_Master2_GREBENKOVA_YULIA_1213.pdf', '1', '0.00', '27', '24', '194', '333', '486', '0');
INSERT INTO convention VALUES('431', '338_Master1_DAOUMI_Jalil_1415.pdf', '1', '12.00', '1', '7', '338', '445', '669', '0');
INSERT INTO convention VALUES('445', 'Etudiant en alternance', '0', '0.00', '1', '2', '336', '0', '697', '0');
INSERT INTO convention VALUES('394', 'Pas de rÃ©sumÃ©', '0', '14.00', '2', '1', '312', '478', '639', '0');
INSERT INTO convention VALUES('395', 'Pas de rÃ©sumÃ©', '0', '0.00', '9', '10', '313', '474', '641', '0');
INSERT INTO convention VALUES('188', 'L3P_MENAGER_JEREMY_1112.pdf', '1', '15.00', '19', '20', '168', '202', '383', '0');
INSERT INTO convention VALUES('256', '203_Master2_PARWANY_ZUBAIR_1213.pdf', '1', '0.00', '15', '14', '203', '336', '463', '0');
INSERT INTO convention VALUES('189', 'L3P_CHAOUALI_CELINE_1112.pdf', '1', '15.00', '20', '19', '163', '200', '314', '0');
INSERT INTO convention VALUES('190', 'L3P_MORAINE_MODESTIE_1112.pdf', '1', '16.00', '17', '18', '170', '222', '167', '0');
INSERT INTO convention VALUES('350', '237_Master2_KOKHANEVYCH_Igor_1314.pdf', '1', '14.00', '4', '29', '237', '346', '117', '0');
INSERT INTO convention VALUES('191', 'L3P_ELUT_MATHURIN_1112.pdf', '1', '15.00', '18', '17', '164', '220', '385', '0');
INSERT INTO convention VALUES('192', 'L3P_RIGOT_PIERRE-OLIVIER_1112.pdf', '1', '14.00', '18', '17', '174', '221', '372', '0');
INSERT INTO convention VALUES('454', 'VÃ©rification de systÃ¨mes intÃ©grant les facteurs humains', '0', '0.00', '3', '3', '347', '0', '703', '0');
INSERT INTO convention VALUES('193', 'L3P_GUERINEAU_ROMAIN_1112.pdf', '1', '17.50', '23', '5', '165', '208', '386', '0');
INSERT INTO convention VALUES('364', '309_Master1_RIABYKINA_VIKTORIIA_1314.pdf', '1', '12.00', '21', '13', '309', '412', '595', '0');
INSERT INTO convention VALUES('194', 'L3P_CALTRE_ANAIS_1112.pdf', '1', '14.50', '8', '4', '162', '206', '47', '0');
INSERT INTO convention VALUES('195', 'L3P_VANNIER_FLORIAN_1112.pdf', '1', '15.00', '17', '18', '176', '224', '387', '0');
INSERT INTO convention VALUES('196', 'L3P_JARRIER_Maxime_1112.pdf', '1', '14.00', '19', '20', '166', '201', '311', '0');
INSERT INTO convention VALUES('278', '189_Master2_DURANTEAU_FLORIAN_1213.pdf', '1', '0.00', '10', '9', '189', '311', '391', '0');
INSERT INTO convention VALUES('279', '198_Master2_KOS_CYNTHIA_1213.pdf', '1', '0.00', '1', '2', '198', '307', '481', '0');
INSERT INTO convention VALUES('403', '295_Master2_DIET_Charles_1415.pdf', '1', '14.50', '24', '27', '295', '465', '649', '0');
INSERT INTO convention VALUES('404', '327_Master1_GOMES_Alexandre_1415.pdf', '1', '12.00', '1', '7', '327', '444', '428', '0');
INSERT INTO convention VALUES('280', '178_Master2_ANDRU_BASTIEN_1213.pdf', '1', '0.00', '1', '2', '178', '304', '481', '0');
INSERT INTO convention VALUES('384', '298_Master1_FEURPRIER_Audrey_1314.pdf', '1', '13.00', '11', '7', '298', '395', '611', '0');
INSERT INTO convention VALUES('385', '300_Master1_GUERET_Baptiste_1314.pdf', '1', '13.00', '29', '4', '300', '399', '414', '0');
INSERT INTO convention VALUES('386', '306_Master1_OBERTYSHEVA_Polina_1314.pdf', '1', '14.00', '2', '1', '306', '407', '612', '0');
INSERT INTO convention VALUES('281', '184_Master2_CARRE_GAEL_1213.pdf', '1', '0.00', '2', '1', '184', '305', '482', '0');
INSERT INTO convention VALUES('447', 'Etudiant en alternance', '0', '0.00', '10', '9', '330', '0', '668', '0');
INSERT INTO convention VALUES('448', 'Etudiant en alternance', '0', '0.00', '34', '3', '379', '0', '183', '0');
INSERT INTO convention VALUES('449', 'Etudiant en alternance', '0', '0.00', '9', '10', '346', '0', '699', '0');
INSERT INTO convention VALUES('450', 'Etudiant en alternance', '0', '0.00', '10', '9', '348', '0', '302', '8');
INSERT INTO convention VALUES('197', 'L3P_MEUNIER_GUILLAUME_1112.pdf', '1', '16.00', '19', '20', '169', '203', '388', '0');
INSERT INTO convention VALUES('198', 'Mise en place d\'un outil de supervision', '0', '13.00', '8', '1', '160', '0', '151', '0');
INSERT INTO convention VALUES('199', 'L3P_ALLAOUI MOHAMED_SAID_1112.pdf', '1', '12.00', '20', '19', '158', '198', '389', '0');
INSERT INTO convention VALUES('362', '291_Master1_CARPENTIER_Alexis_1314.pdf', '1', '12.00', '22', '33', '291', '429', '593', '0');
INSERT INTO convention VALUES('200', 'DÃ©veloppement d\'applications : base documentaire, coÃ»ts transporteurs, gestion projets.', '0', '0.00', '20', '19', '159', '199', '390', '0');
INSERT INTO convention VALUES('201', 'L3P_MARION_RENAN_1112.pdf', '1', '12.00', '8', '4', '167', '207', '391', '0');
INSERT INTO convention VALUES('372', '304_Master1_KLYMENKO_Mykyta_1314.pdf', '1', '11.00', '32', '8', '304', '406', '599', '0');
INSERT INTO convention VALUES('373', '318_Master1_BEN ABDALLAH_Amna_1314.pdf', '1', '12.00', '30', '31', '318', '421', '600', '0');
INSERT INTO convention VALUES('412', '307_Master2_PARME_Thibault_1415.pdf', '1', '14.00', '29', '4', '307', '480', '605', '0');
INSERT INTO convention VALUES('374', '303_Master1_IAKYMENKO_Artem_1314.pdf', '1', '7.00', '1', '14', '303', '428', '601', '0');
INSERT INTO convention VALUES('375', '319_Master1_CLEMENT_Noel_1314.pdf', '1', '7.00', '21', '13', '319', '410', '602', '0');
INSERT INTO convention VALUES('282', '190_Master2_DUROY_ADRIEN_1213.pdf', '1', '0.00', '2', '1', '190', '306', '482', '0');
INSERT INTO convention VALUES('402', '285_Master2_ABOUAF_Nicolas_1415.pdf', '1', '13.00', '31', '14', '285', '457', '648', '0');
INSERT INTO convention VALUES('283', '188_Master2_DETAN_NICOLAS_1213.pdf', '1', '0.00', '26', '11', '188', '328', '483', '0');
INSERT INTO convention VALUES('202', 'L3P_BRAHIM_GUILLAUME_1112.pdf', '1', '16.00', '18', '17', '161', '219', '168', '0');
INSERT INTO convention VALUES('203', 'L3P_RAPP_JOSIA_1112.pdf', '1', '14.00', '4', '8', '173', '209', '141', '0');
INSERT INTO convention VALUES('204', 'L3P_PIERRAT_JIMMY_1112.pdf', '1', '13.00', '17', '18', '171', '223', '392', '0');
INSERT INTO convention VALUES('205', 'L3P_PONGE_SMERALD_1112.pdf', '1', '14.00', '19', '20', '172', '204', '383', '0');
INSERT INTO convention VALUES('206', 'M1_DIOUF_Pape Babacar_1112.pdf', '1', '0.00', '7', '6', '215', '251', '393', '0');
INSERT INTO convention VALUES('268', '186_Master2_DAUBIAS_ESTEBAN_1213.pdf', '1', '0.00', '10', '9', '186', '310', '474', '0');
INSERT INTO convention VALUES('424', '328_Master1_KHOROLICH_Yulianna_1415.pdf', '1', '16.00', '22', '12', '328', '453', '290', '0');
INSERT INTO convention VALUES('425', '329_Master1_KULISHEV_Maksym_1415.pdf', '1', '15.00', '12', '22', '329', '454', '665', '0');
INSERT INTO convention VALUES('207', 'M1_GHORBEL_Hammadi_1112.pdf', '1', '0.00', '21', '13', '217', '237', '195', '0');
INSERT INTO convention VALUES('443', 'Etudiant en alternance', '0', '0.00', '27', '24', '332', '0', '658', '0');
INSERT INTO convention VALUES('267', '219_Master2_CHOUKET_Houda_1213.pdf', '1', '0.00', '29', '4', '219', '316', '473', '0');
INSERT INTO convention VALUES('368', '301_Master1_GUO_Jia_1314.pdf', '1', '13.00', '32', '8', '301', '404', '277', '0');
INSERT INTO convention VALUES('208', 'M1_CHAKROUN_Dhia_1112.pdf', '1', '0.00', '21', '13', '214', '236', '195', '0');
INSERT INTO convention VALUES('273', '192_Master2_GOSSELIN_QUENTIN_1213.pdf', '1', '0.00', '14', '15', '192', '326', '476', '0');
INSERT INTO convention VALUES('209', 'M1_LAAMOURI_Tarek_1112.pdf', '1', '0.00', '13', '21', '220', '238', '195', '0');
INSERT INTO convention VALUES('259', '197_Master2_JAMET_JEREMY_1213.pdf', '1', '0.00', '27', '24', '197', '334', '465', '0');
INSERT INTO convention VALUES('210', 'M1_DRIDI_Anas_1112.pdf', '1', '0.00', '13', '21', '216', '239', '195', '0');
INSERT INTO convention VALUES('420', '306_Master2_OBERTYSHEVA_Polina_1415.pdf', '1', '13.00', '2', '1', '306', '479', '612', '0');
INSERT INTO convention VALUES('421', '304_Master2_KLYMENKO_Mykyta_1415.pdf', '1', '11.00', '14', '31', '304', '462', '661', '0');
INSERT INTO convention VALUES('422', '316_Master2_VOISIN_Jeremy_1415.pdf', '1', '15.00', '1', '2', '316', '477', '662', '0');
INSERT INTO convention VALUES('423', '314_Master2_VESSEREAU_YANNIS_1415.pdf', '1', '14.00', '4', '29', '314', '483', '663', '0');
INSERT INTO convention VALUES('211', 'DÃ©veloppement technique et dÃ©veloppement commercial de projets full-web en PHP/MySQL, basÃ© sur un CMS (Wordpress, Typo3, Drupalâ¦)', '0', '0.00', '27', '24', '204', '248', '338', '0');
INSERT INTO convention VALUES('212', 'M1_GENARD_GEOFFREY_1112.pdf', '1', '0.00', '5', '23', '191', '211', '394', '0');
INSERT INTO convention VALUES('213', 'M1_KOS_CYNTHIA_1112.pdf', '1', '0.00', '5', '23', '198', '212', '47', '0');
INSERT INTO convention VALUES('214', 'M1_HADDAD_Yassine_1112.pdf', '1', '0.00', '26', '28', '218', '227', '395', '0');
INSERT INTO convention VALUES('263', '215_Master2_DIOUF_Pape Babacar_1213.pdf', '1', '0.00', '22', '12', '215', '320', '469', '0');
INSERT INTO convention VALUES('406', '301_Master2_GUO_Jia_1415.pdf', '1', '12.00', '31', '14', '301', '461', '654', '0');
INSERT INTO convention VALUES('407', '256_Master2_RAEISI_Soudeh_1415.pdf', '1', '13.50', '24', '27', '256', '466', '655', '0');
INSERT INTO convention VALUES('264', '214_Master2_CHAKROUN_Dhia_1213.pdf', '1', '0.00', '22', '12', '214', '319', '470', '0');
INSERT INTO convention VALUES('371', '292_Master1_CHARLES_Simon_1314.pdf', '1', '15.00', '1', '14', '292', '426', '574', '0');
INSERT INTO convention VALUES('265', '191_Master2_GENARD_GEOFFREY_1213.pdf', '1', '0.00', '12', '22', '191', '322', '471', '0');
INSERT INTO convention VALUES('426', '331_Master1_LE PEN_Amandine_1415.pdf', '1', '15.00', '7', '1', '331', '442', '666', '0');
INSERT INTO convention VALUES('358', '316_Master1_VOISIN_Jeremy_1314.pdf', '1', '14.00', '31', '30', '316', '424', '428', '0');
INSERT INTO convention VALUES('215', 'M1_CARRE_GAEL_1112.pdf', '1', '0.00', '10', '9', '184', '235', '373', '0');
INSERT INTO convention VALUES('428', '321_Master1_BARDET_Adrien_1415.pdf', '1', '13.00', '29', '4', '321', '438', '656', '0');
INSERT INTO convention VALUES('429', '330_Master1_LANVIN_Elyan_1415.pdf', '1', '14.50', '30', '32', '330', '455', '668', '0');
INSERT INTO convention VALUES('430', '324_Master1_CROUILLERE_Kevin_1415.pdf', '1', '14.00', '13', '21', '324', '446', '617', '0');
INSERT INTO convention VALUES('216', 'M1_RIVAL_GUILLAUME_1112.pdf', '1', '0.00', '27', '24', '100', '249', '396', '0');
INSERT INTO convention VALUES('253', '266_Licence L3P_ROULLIER_Remi_1213.pdf', '1', '0.00', '8', '26', '266', '272', '417', '0');
INSERT INTO convention VALUES('254', 'Stage en alternance', '0', '0.00', '8', '26', '269', '271', '418', '0');
INSERT INTO convention VALUES('255', '270_Licence L3P_LEGOUET_Mickael_1213.pdf', '1', '0.00', '17', '18', '270', '266', '168', '0');
INSERT INTO convention VALUES('348', '251_Master2_POLISHCHUK_Oleg_1314.pdf', '1', '14.00', '4', '29', '251', '347', '523', '0');
INSERT INTO convention VALUES('349', '226_Master2_BULANENKO_Roman_1314.pdf', '1', '15.00', '14', '30', '226', '344', '498', '0');
INSERT INTO convention VALUES('257', '179_Master2_AUBRY_BASTIEN_1213.pdf', '1', '0.00', '16', '1', '179', '313', '20', '0');
INSERT INTO convention VALUES('383', '289_Master1_BOSSART_Florent_1314.pdf', '1', '15.00', '27', '24', '289', '389', '524', '0');
INSERT INTO convention VALUES('217', 'M1_BOUAZIZ_MOHAMED_1112.pdf', '1', '0.00', '1', '2', '181', '230', '288', '0');
INSERT INTO convention VALUES('455', 'Analyste dÃ©veloppeur Java', '0', '0.00', '3', '3', '335', '0', '708', '0');
INSERT INTO convention VALUES('456', 'Utilisation de donnÃ©es multilingues pour l\'apprentissage de modÃ¨les de langue neuronaux', '0', '0.00', '24', '3', '321', '0', '709', '4');
INSERT INTO convention VALUES('458', 'RÃ©seau de neurones rÃ©current pour la reconnaissance du locuteur', '0', '0.00', '37', '3', '333', '0', '711', '0');
INSERT INTO convention VALUES('355', '314_Master1_VESSEREAU_YANNIS_1314.pdf', '1', '14.00', '21', '13', '314', '414', '20', '0');
INSERT INTO convention VALUES('275', '207_Master2_TOUSE_FLORIAN_1213.pdf', '1', '0.00', '11', '26', '207', '330', '478', '0');
INSERT INTO convention VALUES('334', '254_Master2_CHUBYNSKYI_Viacheslav_1314.pdf', '1', '16.00', '24', '27', '254', '353', '586', '0');
INSERT INTO convention VALUES('397', '291_Master2_CARPENTIER_Alexis_1415.pdf', '1', '14.00', '14', '31', '291', '458', '643', '0');
INSERT INTO convention VALUES('335', '244_Master2_OUATTARA_Florent_1314.pdf', '1', '15.00', '24', '27', '244', '355', '586', '0');
INSERT INTO convention VALUES('390', 'Pas de rÃ©sumÃ©', '0', '0.00', '3', '3', '290', '0', '636', '0');
INSERT INTO convention VALUES('336', '229_Master2_EL MOUSTAPHA SALIHY_Abdellahi_1314.docx', '1', '12.00', '22', '33', '229', '349', '587', '0');
INSERT INTO convention VALUES('337', '225_Master2_BUFFET_Hugo_1314.pdf', '1', '15.00', '33', '22', '225', '365', '588', '0');
INSERT INTO convention VALUES('398', '294_Master2_DARDE_Yohan_1415.pdf', '1', '13.00', '14', '31', '294', '459', '483', '0');
INSERT INTO convention VALUES('218', 'M1_BESNARD_VINCENT_1112.pdf', '1', '0.00', '9', '10', '180', '234', '380', '0');
INSERT INTO convention VALUES('332', '235_Master2_HENRY_Felix_1314.pdf', '1', '16.00', '32', '31', '235', '388', '585', '0');
INSERT INTO convention VALUES('333', 'Pas de rÃ©sumÃ©', '0', '14.50', '8', '7', '239', '363', '586', '0');
INSERT INTO convention VALUES('391', '292_Master2_CHARLES_Simon_1415.pdf', '1', '14.00', '30', '11', '292', '468', '637', '0');
INSERT INTO convention VALUES('219', 'M1_HENRY_AXEL_1112.pdf', '1', '0.00', '16', '11', '195', '244', '398', '0');
INSERT INTO convention VALUES('351', '242_Master2_LYTVYNOV_Anton_1314.pdf', '1', '9.00', '1', '2', '242', '341', '373', '0');
INSERT INTO convention VALUES('352', '248_Master2_SAIEVYCH_Kseniia_1314.doc', '1', '13.00', '1', '2', '248', '340', '512', '0');
INSERT INTO convention VALUES('220', 'M1_GOSSELIN_QUENTIN_1112.pdf', '1', '0.00', '14', '15', '192', '217', '399', '0');
INSERT INTO convention VALUES('221', 'M1_MARTINEAU_PIERRE-JEAN_1112.pdf', '1', '0.00', '11', '16', '200', '241', '400', '0');
INSERT INTO convention VALUES('245', '227_Master1_CHINOT_Gaulthier_1213.pdf', '1', '0.00', '9', '3', '227', '286', '425', '0');
INSERT INTO convention VALUES('246', '230_Master1_FORTINEAU_Jimmy_1213.pdf', '1', '0.00', '9', '3', '230', '287', '425', '0');
INSERT INTO convention VALUES('247', '236_Master1_JARDIN_Jeremy_1213.pdf', '1', '0.00', '11', '3', '236', '296', '425', '0');
INSERT INTO convention VALUES('248', '240_Master1_LEGAY_Jordan_1213.pdf', '1', '0.00', '11', '3', '240', '298', '425', '0');
INSERT INTO convention VALUES('249', '260_Licence L3P_ANDRE_Benjamin_1213.pdf', '1', '17.00', '18', '17', '260', '260', '415', '0');
INSERT INTO convention VALUES('250', 'Stage en alternance', '0', '14.00', '4', '29', '261', '273', '416', '0');
INSERT INTO convention VALUES('251', '264_Licence L3P_LETESSIER_Romain_1213.pdf', '1', '0.00', '26', '8', '264', '270', '317', '0');
INSERT INTO convention VALUES('222', 'M1_DAUBIAS_ESTEBAN_1112.pdf', '1', '0.00', '2', '1', '186', '232', '401', '0');
INSERT INTO convention VALUES('270', '177_Master2_ACHTE_Remi_1213.pdf', '1', '0.00', '9', '10', '177', '308', '290', '0');
INSERT INTO convention VALUES('271', '204_Master2_PETITHORY_MARC_1213.pdf', '1', '0.00', '9', '10', '204', '309', '290', '0');
INSERT INTO convention VALUES('344', '240_Master2_LEGAY_Jordan_1314.pdf', '1', '14.00', '11', '8', '240', '361', '521', '0');
INSERT INTO convention VALUES('345', '227_Master2_CHINOT_Gaulthier_1314.pdf', '1', '14.00', '9', '10', '227', '351', '521', '0');
INSERT INTO convention VALUES('346', '230_Master2_FORTINEAU_Jimmy_1314.pdf', '1', '13.00', '9', '10', '230', '352', '522', '0');
INSERT INTO convention VALUES('347', '252_Master2_MINIAILO_Artem_1314.pdf', '1', '14.00', '14', '1', '252', '357', '497', '0');
INSERT INTO convention VALUES('223', 'M1_DELORME_GUILLAUME_1112.pdf', '1', '0.00', '2', '1', '187', '233', '177', '0');
INSERT INTO convention VALUES('434', '326_Master1_GIROD_Quentin_1415.pdf', '1', '15.00', '24', '27', '326', '451', '670', '0');
INSERT INTO convention VALUES('441', 'DÃ©veloppement d\'un systÃ¨me de renseignement COLOMBE', '0', '0.00', '3', '3', '324', '0', '695', '0');
INSERT INTO convention VALUES('442', 'Etudiant en alternance', '0', '0.00', '4', '29', '334', '0', '696', '0');
INSERT INTO convention VALUES('435', '322_Master1_BERRABAH_Mohammed_1415.pdf', '1', '8.00', '13', '21', '322', '447', '671', '0');
INSERT INTO convention VALUES('436', '341_Master2_NOEL_Clement_1415.pdf', '1', '11.00', '27', '24', '341', '464', '672', '0');
INSERT INTO convention VALUES('269', '195_Master2_HENRY_AXEL_1213.pdf', '1', '0.00', '15', '14', '195', '325', '398', '0');
INSERT INTO convention VALUES('356', '290_Master1_BROUX_Pierre-Alexandre_1314.pdf', '1', '11.00', '7', '11', '290', '397', '592', '0');
INSERT INTO convention VALUES('410', '323_Master1_BIALETTI_Olivier_1415.pdf', '1', '14.00', '9', '10', '323', '450', '673', '0');
INSERT INTO convention VALUES('411', 'Etudiant en alternance', '0', '11.50', '11', '8', '333', '441', '659', '0');
INSERT INTO convention VALUES('224', 'M1_MELNYCHENKO_IVAN_1112.pdf', '1', '0.00', '11', '16', '201', '242', '402', '0');
INSERT INTO convention VALUES('225', 'M1_CHANROUX_BENJAMIN_1112.pdf', '1', '0.00', '28', '26', '185', '228', '302', '0');
INSERT INTO convention VALUES('416', '302_Master2_HENRY_Nathan_1415.pdf', '1', '0.00', '8', '1', '302', '467', '609', '0');
INSERT INTO convention VALUES('417', '289_Master2_BOSSART_Florent_1415.pdf', '1', '15.00', '27', '24', '289', '463', '524', '0');
INSERT INTO convention VALUES('226', 'M1_TOUSE_FLORIAN_1112.pdf', '1', '0.00', '28', '26', '207', '229', '302', '0');
INSERT INTO convention VALUES('252', '265_Licence L3P_OZAN_Aurelien_1213.pdf', '1', '0.00', '19', '20', '265', '256', '358', '0');
INSERT INTO convention VALUES('227', 'M1_ACHTE_REMI_1112.pdf', '1', '0.00', '26', '28', '177', '225', '403', '0');
INSERT INTO convention VALUES('453', 'Etudiant en alternance', '0', '0.00', '4', '29', '363', '0', '702', '0');
INSERT INTO convention VALUES('228', 'M1_NGENZI_DANIEL_1112.pdf', '1', '0.00', '23', '5', '202', '210', '386', '0');
INSERT INTO convention VALUES('399', '296_Master2_DUBOIS_Jerome_1415.pdf', '1', '14.00', '34', '1', '296', '470', '644', '0');
INSERT INTO convention VALUES('400', '310_Master2_ROUCOUX_Ludovic_1415.pdf', '1', '15.00', '34', '1', '310', '471', '644', '0');
INSERT INTO convention VALUES('401', 'DÃ©veloppement Web', '0', '12.00', '1', '34', '337', '449', '647', '0');
INSERT INTO convention VALUES('369', '285_Master1_ABOUAF_Nicolas_1314.pdf', '1', '12.00', '7', '11', '285', '398', '598', '0');
INSERT INTO convention VALUES('229', 'M1_WEN_JIE_1112.pdf', '1', '0.00', '14', '15', '210', '218', '404', '0');
INSERT INTO convention VALUES('439', 'IntÃ©gration d\'une solution de tests mobiles iOS Ã  un automate open source', '0', '0.00', '3', '3', '331', '0', '643', '0');
INSERT INTO convention VALUES('338', '228_Master2_COURCIER_Fabrice_1314.pdf', '1', '14.00', '27', '24', '228', '354', '589', '0');
INSERT INTO convention VALUES('339', '238_Master2_KOTOVA_Yuliia_1314.pdf', '1', '12.00', '7', '11', '238', '364', '590', '0');
INSERT INTO convention VALUES('277', '218_Master2_HADDAD_Yassine_1213.pdf', '1', '0.00', '13', '21', '218', '317', '480', '0');
INSERT INTO convention VALUES('230', 'M1_DETAN_NICOLAS_1112.pdf', '1', '0.00', '24', '27', '188', '246', '330', '0');
INSERT INTO convention VALUES('433', '335_Master1_MARCAIS_Thomas_1415.pdf', '1', '8.00', '32', '30', '335', '456', '492', '0');
INSERT INTO convention VALUES('366', '295_Master1_DIET_Charles_1314.pdf', '1', '15.00', '13', '21', '295', '419', '47', '0');
INSERT INTO convention VALUES('231', 'M1_JAMET_JEREMY_1112.pdf', '1', '0.00', '24', '27', '197', '247', '330', '0');
INSERT INTO convention VALUES('262', '210_Master2_WEN_JIE_1213.pdf', '1', '0.00', '24', '27', '210', '332', '468', '0');
INSERT INTO convention VALUES('260', '187_Master2_DELORME_GUILLAUME_1213.pdf', '1', '0.00', '27', '24', '187', '335', '466', '0');
INSERT INTO convention VALUES('438', 'DÃ©veloppement application Web', '0', '0.00', '3', '3', '337', '0', '693', '0');
INSERT INTO convention VALUES('365', '287_Master1_BELLIER FAUVET_Valerie_1314.pdf', '1', '10.00', '13', '21', '287', '416', '596', '0');
INSERT INTO convention VALUES('413', '315_Master2_VIRLOUVET_Xavier_1415.pdf', '1', '12.00', '4', '29', '315', '481', '606', '0');
INSERT INTO convention VALUES('414', '297_Master2_FENOUIL_SANDRINE_1415.odt', '1', '14.00', '10', '9', '297', '472', '607', '0');
INSERT INTO convention VALUES('415', '305_Master2_MARTEAU_Morgane_1415.pdf', '1', '13.00', '10', '9', '305', '473', '522', '0');
INSERT INTO convention VALUES('261', '200_Master2_MARTINEAU_PIERRE-JEAN_1213.pdf', '1', '0.00', '24', '27', '200', '331', '467', '0');
INSERT INTO convention VALUES('353', '250_Master2_ZHANG_Shuo_1314.pdf', '1', '12.00', '14', '1', '250', '343', '514', '0');
INSERT INTO convention VALUES('354', '310_Master1_ROUCOUX_Ludovic_1314.pdf', '1', '17.00', '24', '27', '310', '393', '591', '0');
INSERT INTO convention VALUES('405', '340_Master2_GAHAGNON_Thibaud_1415.pdf', '1', '15.00', '22', '12', '340', '475', '651', '0');
INSERT INTO convention VALUES('232', 'M1_DURANTEAU_FLORIAN_1112.pdf', '1', '0.00', '15', '14', '189', '215', '405', '0');
INSERT INTO convention VALUES('233', 'M1_ANDRU_BASTIEN_1112.pdf', '1', '0.00', '15', '14', '178', '214', '405', '0');
INSERT INTO convention VALUES('234', 'M1_GOUY_FLORIAN_1112.pdf', '1', '0.00', '15', '14', '193', '213', '406', '0');
INSERT INTO convention VALUES('376', '296_Master1_DUBOIS_Jerome_1314.pdf', '1', '13.00', '8', '1', '296', '434', '603', '0');
INSERT INTO convention VALUES('235', 'M1_DUROY_ADRIEN_1112.pdf', '1', '0.00', '16', '11', '190', '245', '407', '0');
INSERT INTO convention VALUES('367', '256_Master1_RAEISI_Soudeh_1314.pdf', '1', '10.00', '2', '1', '256', '436', '597', '0');
INSERT INTO convention VALUES('236', 'M1_GREBENKOVA_YULIA_1112.pdf', '1', '0.00', '26', '28', '194', '226', '277', '0');
INSERT INTO convention VALUES('427', '336_Master1_MICHAUD_Jerome_1415.pdf', '1', '16.00', '7', '1', '336', '443', '667', '0');
INSERT INTO convention VALUES('266', '183_Master2_BROLINSKYI_SERGEII_1213.pdf', '1', '0.00', '29', '4', '183', '314', '516', '0');
INSERT INTO convention VALUES('237', 'M1_PARWANY_ZUBAIR_1112.pdf', '1', '0.00', '14', '15', '203', '216', '408', '0');
INSERT INTO convention VALUES('258', '216_Master2_DRIDI_Anas_1213.pdf', '1', '0.00', '12', '22', '216', '321', '464', '0');
INSERT INTO convention VALUES('360', '299_Master1_FROGER_Adrien_1314.pdf', '1', '15.00', '33', '22', '299', '432', '556', '0');
INSERT INTO convention VALUES('238', 'M1_AUBRY_BASTIEN_1112.pdf', '1', '0.00', '1', '2', '179', '231', '292', '0');
INSERT INTO convention VALUES('331', '232_Master2_GOUMBALLA_Aida_1314.pdf', '1', '14.00', '31', '32', '232', '385', '584', '0');
INSERT INTO convention VALUES('276', '100_Master2_RIVAL_Guillaume_1213.pdf', '1', '0.00', '21', '13', '100', '318', '479', '0');
INSERT INTO convention VALUES('392', '309_Master2_RIABYKINA_VIKTORIIA_1415.pdf', '1', '11.00', '12', '22', '309', '476', '638', '0');
INSERT INTO convention VALUES('393', 'Pas de rÃ©sumÃ©', '0', '0.00', '3', '3', '311', '0', '594', '0');
INSERT INTO convention VALUES('340', '249_Master2_VIDAMENT-BROU_Adley_1314.pdf', '1', '10.00', '22', '33', '249', '366', '338', '0');
INSERT INTO convention VALUES('388', '299_Master2_FROGER_Adrien_1415.pdf', '1', '17.00', '31', '14', '299', '460', '584', '0');
INSERT INTO convention VALUES('389', 'Pas de rÃ©sumÃ©', '0', '0.00', '3', '3', '318', '0', '635', '0');
INSERT INTO convention VALUES('440', 'DÃ©veloppement dans le domaine de l\'assurance', '0', '0.00', '3', '13', '320', '0', '694', '6');
INSERT INTO convention VALUES('341', '223_Master2_BEGUIN_Julien_1314.pdf', '1', '12.00', '29', '4', '223', '345', '519', '0');
INSERT INTO convention VALUES('342', '224_Master2_BOUCHERIE_Elie_1314.docx', '1', '13.00', '1', '2', '224', '339', '302', '0');
INSERT INTO convention VALUES('239', 'M1_CHOUKET_Houda_1112.pdf', '1', '0.00', '6', '7', '219', '250', '409', '0');
INSERT INTO convention VALUES('343', '236_Master2_JARDIN_Jeremy_1314.pdf', '1', '13.00', '11', '8', '236', '360', '520', '0');
INSERT INTO convention VALUES('272', '185_Master2_CHANROUX_BENJAMIN_1213.pdf', '1', '0.00', '14', '15', '185', '323', '475', '0');
INSERT INTO convention VALUES('370', '313_Master1_VAKHRINA_VIKTORIIA_1314.pdf', '1', '12.00', '33', '22', '313', '430', '578', '0');
INSERT INTO convention VALUES('240', 'M1_TROTIN_RONAN_1112.pdf', '1', '0.00', '4', '11', '208', '243', '288', '0');
INSERT INTO convention VALUES('243', '223_Master1_BEGUIN_Julien_1213.pdf', '1', '0.00', '29', '3', '223', '279', '414', '0');
INSERT INTO convention VALUES('244', '224_Master1_BOUCHERIE_Elie_1213.pdf', '1', '0.00', '1', '3', '224', '276', '302', '0');
INSERT INTO convention VALUES('241', 'M1_BROLINSKYI_SERGEII_1112.pdf', '1', '0.00', '11', '4', '183', '240', '410', '0');
INSERT INTO convention VALUES('274', '220_Master2_LAAMOURI_Tarek_1213.pdf', '1', '0.00', '11', '26', '220', '329', '477', '0');
INSERT INTO convention VALUES('363', '311_Master1_SIMONNET_EDWIN_1314.pdf', '1', '15.00', '30', '31', '311', '422', '594', '0');
INSERT INTO convention VALUES('432', '325_Master1_DESNOUS_Florent_1415.pdf', '1', '14.00', '21', '13', '325', '448', '373', '0');
INSERT INTO convention VALUES('444', 'Etudiant en alternance', '0', '0.00', '9', '10', '323', '0', '673', '2');
INSERT INTO convention VALUES('451', 'Etudiant en alternance', '0', '0.00', '24', '27', '352', '0', '700', '0');
INSERT INTO convention VALUES('452', 'Etudiant en alternance et voila.', '0', '0.00', '30', '9', '360', '0', '398', '4');
INSERT INTO convention VALUES('357', '294_Master1_DARDE_Yohan_1314.pdf', '1', '12.00', '13', '21', '294', '418', '47', '0');
INSERT INTO convention VALUES('437', 'DÃ©veloppement applications Web et dÃ©veloppement applications AndroÃ¯d intÃ©grant des procÃ©dÃ©s de gÃ©olocalisation, de diffusion vidÃ©o et de publication intuitive', '0', '0.00', '3', '3', '370', '0', '428', '0');
INSERT INTO convention VALUES('408', '334_Master1_LOUVEL_Cedric_1415.pdf', '1', '13.00', '4', '29', '334', '439', '657', '0');
INSERT INTO convention VALUES('409', '332_Master1_LEDRU_Julien_1415.pdf', '1', '13.00', '27', '24', '332', '452', '658', '0');
INSERT INTO convention VALUES('301', '252_Master1_MINIAILO_Artem_1213.pdf', '1', '0.00', '16', '11', '252', '252', '497', '0');
INSERT INTO convention VALUES('302', '226_Master1_BULANENKO_Roman_1213.pdf', '1', '0.00', '22', '12', '226', '283', '498', '0');
INSERT INTO convention VALUES('303', '232_Master1_GOUMBALLA_Aida_1213.pdf', '1', '0.00', '27', '24', '232', '293', '393', '0');
INSERT INTO convention VALUES('304', '254_Master1_CHUBYNSKYI_Viacheslav_1213.pdf', '1', '0.00', '10', '9', '254', '288', '499', '0');
INSERT INTO convention VALUES('305', '245_Master1_OULD BOUKHARY_Sidi Mohamed_1213.pdf', '1', '0.00', '10', '9', '245', '289', '500', '0');
INSERT INTO convention VALUES('306', '253_Master1_BAH_Mamadou_1213.pdf', '1', '0.00', '14', '15', '253', '290', '501', '0');
INSERT INTO convention VALUES('307', '249_Master1_VIDAMENT-BROU_Adley_1213.pdf', '1', '0.00', '2', '1', '249', '278', '338', '0');
INSERT INTO convention VALUES('308', '244_Master1_OUATTARA_Florent_1213.pdf', '1', '0.00', '24', '27', '244', '300', '117', '0');
INSERT INTO convention VALUES('309', '283_Master1_GHORBEL_Afef_1213.pdf', '1', '0.00', '12', '22', '283', '284', '457', '0');
INSERT INTO convention VALUES('310', 'SystÃ¨me du management des archives et service d\'orientation<br/>DÃ©velopper un systÃ¨me (web site et logiciel du serveur) pour superviser les archives des jeunes et offrir des informations du travail et des entreprises', '0', '0.00', '12', '22', '234', '285', '502', '0');
INSERT INTO convention VALUES('311', '229_Master1_EL MOUSTAPHA SALIHY_Abdellahi_1213.pdf', '1', '0.00', '13', '21', '229', '291', '503', '0');
INSERT INTO convention VALUES('312', '228_Master1_COURCIER_Fabrice_1213.pdf', '1', '0.00', '21', '13', '228', '292', '47', '0');
INSERT INTO convention VALUES('313', '238_Master1_KOTOVA_Yuliia_1213.pdf', '1', '0.00', '21', '13', '238', '297', '47', '0');
INSERT INTO convention VALUES('314', '251_Master1_POLISCHUK_Oleg_1213.pdf', '1', '0.00', '15', '14', '251', '301', '290', '0');
INSERT INTO convention VALUES('316', '255_Master1_MAATAR_Nadia Sofia_1213.pdf', '1', '0.00', '16', '11', '255', '253', '504', '0');
INSERT INTO convention VALUES('317', '242_Master1_LYTVYNOV_Anton_1213.pdf', '1', '0.00', '13', '21', '242', '299', '505', '0');
INSERT INTO convention VALUES('318', '239_Master1_LEBRUN_Jeremy_1213.pdf', '1', '0.00', '29', '4', '239', '280', '506', '0');
INSERT INTO convention VALUES('319', '237_Master1_KOKHANEVYCH_Igor_1213.pdf', '1', '0.00', '4', '29', '237', '281', '507', '0');
INSERT INTO convention VALUES('320', '235_Master1_HENRY_Felix_1213.pdf', '1', '0.00', '24', '27', '235', '295', '508', '0');
INSERT INTO convention VALUES('321', '225_Master1_BUFFET_Hugo_1213.pdf', '1', '0.00', '22', '12', '225', '282', '509', '0');
INSERT INTO convention VALUES('322', '247_Master1_POUA SALLEY_Karl_1213.pdf', '1', '0.00', '15', '14', '247', '302', '510', '0');
INSERT INTO convention VALUES('323', '233_Master1_GUEI_Kamonda_1213.pdf', '1', '0.00', '14', '15', '233', '294', '511', '0');
INSERT INTO convention VALUES('324', '248_Master1_SAIEVYCH_Kseniia_1213.pdf', '1', '0.00', '2', '1', '248', '277', '512', '0');
INSERT INTO convention VALUES('459', 'DÃ©veloppement Web', '0', '0.00', '3', '3', '327', '0', '712', '0');
INSERT INTO convention VALUES('460', 'Stage d\'Ã©tude et dÃ©veloppement', '0', '0.00', '3', '3', '326', '0', '714', '0');
INSERT INTO convention VALUES('325', '284_Master1_AOUADNI_Wadhah_1213.pdf', '1', '0.00', '1', '2', '284', '275', '277', '0');
INSERT INTO convention VALUES('326', '250_Master1_ZHANG_Shuo_1213.pdf', '1', '0.00', '21', '13', '250', '303', '514', '0');
INSERT INTO convention VALUES('327', 'DÃ©veloppement sur plateforme Telium d\'une application d\'acceptance / QA<br/><br/>Principales missions du stagiaire : Prise en main des outils de dÃ©veloppement sur les terminaux de paiement Ingenico. SpÃ©cifier en coopÃ©ration avec l\'Ã©quipe Plateforme une application rÃ©pondant au Test Book dÃ©fini pour la rÃ©gion virtuelle STKH. Une centaine de tests au maximum sera requis pour le step 1 de l\'application. DÃ©velopper et valider sur plateforme telium et sur un des terminaux cibles l\'application spÃ©cifiÃ©e. IntÃ©grer l\'application dans l\'environnement de test automatique de la rÃ©gion virtuelle. Objectifs du stage : Mettre en application la politique de test groupe. Etablir un rÃ©fÃ©rentiel groupe pour le test des applications.', '0', '0.00', '1', '14', '144', '338', '515', '0');
INSERT INTO convention VALUES('328', '281_Licence L3P_RAMOLET_Arthur_1213.pdf', '1', '0.00', '1', '26', '281', '268', '513', '0');

-- -----------------------------
-- insertions dans la table couleur
-- -----------------------------
INSERT INTO couleur VALUES('1', 'Rouge01', 'FF0000');
INSERT INTO couleur VALUES('2', 'Rouge02', 'FF6D6D');
INSERT INTO couleur VALUES('3', 'Rouge03', 'FF5000');
INSERT INTO couleur VALUES('4', 'Rouge04', 'FF866B');
INSERT INTO couleur VALUES('5', 'Rouge05', 'FFB493');
INSERT INTO couleur VALUES('6', 'Bleu01', '0000FF');
INSERT INTO couleur VALUES('7', 'Bleu02', '7272FF');
INSERT INTO couleur VALUES('8', 'Bleu03', '00A5FF');
INSERT INTO couleur VALUES('9', 'Bleu04', '0082B2');
INSERT INTO couleur VALUES('10', 'Bleu05', '00FFFA');
INSERT INTO couleur VALUES('11', 'Vert01', '00FF00');
INSERT INTO couleur VALUES('12', 'Vert02', '75FF75');
INSERT INTO couleur VALUES('13', 'Vert03', '00AA0B');
INSERT INTO couleur VALUES('14', 'Vert04', '7DDB83');
INSERT INTO couleur VALUES('15', 'Vert05', '2CEA9B');
INSERT INTO couleur VALUES('16', 'Jaune01', 'FFE500');
INSERT INTO couleur VALUES('17', 'Jaune02', 'FFF084');
INSERT INTO couleur VALUES('18', 'Jaune03', 'E0BB00');
INSERT INTO couleur VALUES('19', 'Jaune04', 'C9C040');
INSERT INTO couleur VALUES('20', 'Jaune05', 'E7ED97');
INSERT INTO couleur VALUES('21', 'Violet01', 'E7ED97');
INSERT INTO couleur VALUES('22', 'Violet02', 'A500FF');
INSERT INTO couleur VALUES('23', 'Violet03', 'E27CFF');
INSERT INTO couleur VALUES('24', 'Violet04', 'A35BBF');
INSERT INTO couleur VALUES('25', 'Violet05', 'CC188D');
INSERT INTO couleur VALUES('26', 'Gris1', 'E5E5E5');
INSERT INTO couleur VALUES('27', 'Gris2', 'E0E0E0');
INSERT INTO couleur VALUES('28', 'Gris3', 'D8D8D8');
INSERT INTO couleur VALUES('29', 'Gris4', 'A0A0A0');
INSERT INTO couleur VALUES('30', 'Gris5', '898989');
INSERT INTO couleur VALUES('31', 'Gris6', '6B6B6B');
INSERT INTO couleur VALUES('32', 'Vert1', 'B6FFB5');
INSERT INTO couleur VALUES('33', 'Vert2', '9BDB9D');
INSERT INTO couleur VALUES('34', 'Vert3', '78A877');
INSERT INTO couleur VALUES('35', 'Vert4', '4FA54C');
INSERT INTO couleur VALUES('36', 'Vert5', '1F7F14');

-- -----------------------------
-- insertions dans la table datesoutenance
-- -----------------------------
INSERT INTO datesoutenance VALUES('1', '5', '7', '2010');
INSERT INTO datesoutenance VALUES('2', '6', '7', '2010');
INSERT INTO datesoutenance VALUES('3', '7', '7', '2010');
INSERT INTO datesoutenance VALUES('4', '6', '9', '2010');
INSERT INTO datesoutenance VALUES('5', '7', '9', '2010');
INSERT INTO datesoutenance VALUES('6', '1', '9', '2010');
INSERT INTO datesoutenance VALUES('7', '2', '9', '2010');
INSERT INTO datesoutenance VALUES('8', '3', '9', '2010');
INSERT INTO datesoutenance VALUES('9', '4', '7', '2011');
INSERT INTO datesoutenance VALUES('10', '5', '7', '2011');
INSERT INTO datesoutenance VALUES('11', '29', '8', '2011');
INSERT INTO datesoutenance VALUES('12', '30', '8', '2011');
INSERT INTO datesoutenance VALUES('13', '5', '9', '2011');
INSERT INTO datesoutenance VALUES('14', '2', '7', '2012');
INSERT INTO datesoutenance VALUES('15', '3', '7', '2012');
INSERT INTO datesoutenance VALUES('16', '3', '9', '2012');
INSERT INTO datesoutenance VALUES('17', '4', '9', '2012');
INSERT INTO datesoutenance VALUES('18', '4', '7', '2012');
INSERT INTO datesoutenance VALUES('19', '1', '7', '2013');
INSERT INTO datesoutenance VALUES('20', '2', '7', '2013');
INSERT INTO datesoutenance VALUES('21', '2', '9', '2013');
INSERT INTO datesoutenance VALUES('22', '3', '9', '2013');
INSERT INTO datesoutenance VALUES('23', '26', '6', '2013');
INSERT INTO datesoutenance VALUES('24', '9', '9', '2013');
INSERT INTO datesoutenance VALUES('25', '27', '9', '2013');
INSERT INTO datesoutenance VALUES('26', '30', '6', '2014');
INSERT INTO datesoutenance VALUES('27', '1', '7', '2014');
INSERT INTO datesoutenance VALUES('28', '1', '9', '2014');
INSERT INTO datesoutenance VALUES('29', '2', '9', '2014');
INSERT INTO datesoutenance VALUES('31', '29', '9', '2014');
INSERT INTO datesoutenance VALUES('32', '29', '6', '2015');
INSERT INTO datesoutenance VALUES('33', '31', '8', '2015');
INSERT INTO datesoutenance VALUES('34', '7', '9', '2015');

-- -----------------------------
-- insertions dans la table entreprise
-- -----------------------------
INSERT INTO entreprise VALUES('3', 'ST-Ericsson', '9-11 rue Pierre FÃ©lix Delarue', '72100', 'Le Mans', 'FRANCE', 'isabelle.dagorn@stericsson.com', '0');
INSERT INTO entreprise VALUES('264', 'Arjo Wiggins', '17 rue du 8 Mai 1945 - BP 3', '72310', 'BessÃ©-sur-Braye', 'France', '', '0');
INSERT INTO entreprise VALUES('265', 'FCI Automotive France', 'Z.I. des Longs RÃ©ages BP 25', '28231', 'Epernon Cedex', 'France', 'france@fci.com', '0');
INSERT INTO entreprise VALUES('335', 'MMA', '7 Avenue Marcel Proust', '28000', 'Chartres', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('12', 'DÃ©partement d\'Ã©ducation et pÃ©dagogie<br/>UniversitÃ© du QuÃ©bec', 'C.P. 8888, Succursale Centre-ville', ' H3C 3P8', 'MontrÃ©al', 'CANADA', '', '0');
INSERT INTO entreprise VALUES('16', 'UFC Que Choisir de la Sarthe', '21 Rue Besnier', '72000', 'Le Mans', 'FRANCE', 'quechoisir72@sarthetelecom.fr', '0');
INSERT INTO entreprise VALUES('19', 'CAPE - Ecole des Mines de Nantes', '4, rue Alfred Kastler  - BP 20722', '44307', 'Nantes Cedex 3', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('22', 'ASTELLIA', 'ZA du Plessis Rue du Plessis CS 27241', '35772', 'VERN SUR SEICHE Cedex', 'FRANCE', 'g.ledean@astellia.com', '0');
INSERT INTO entreprise VALUES('23', 'HELILEO', '553, rue Bernard Palissy Village', '40990', 'Saint-Paul-lÃ¨s-Dax', 'FRANCE', 'raymond.pusse@helileo.com', '0');
INSERT INTO entreprise VALUES('26', 'SEPHIRA', '12 rue Vincent Scotto', '72018', 'Le Mans Cedex 2', 'FRANCE', 'Christelle.JACOB@groupe-sephira.fr', '0');
INSERT INTO entreprise VALUES('29', 'Harman Becker Automotive Systems', '2 route de Tours â BP 20159', '72500', 'ChÃ¢teau du Loir', 'FRANCE', 'bfourreau@harman.com', '0');
INSERT INTO entreprise VALUES('30', 'CÃ©noSYS', '10 rue Xavier BICHAT', '72000', 'Le Mans', 'FRANCE', 'contact@cenosys.com', '0');
INSERT INTO entreprise VALUES('33', 'GKN DRIVELINE', '15 rue MAURICE TRINTIGNANT', '72236', 'ARNAGE', 'FRANCE', 'patrick.lambert@gkndriveline.com', '0');
INSERT INTO entreprise VALUES('35', 'PIXBANK', '27 RUE DES MARAIS', '72000', 'LE MANS', 'FRANCE', 'f.serusier@pixbank.org', '0');
INSERT INTO entreprise VALUES('38', 'LABOSPORT', 'Chemin aux boeufs - Technoparc du circuit des 24 heures du Mans', '72100', 'LE MANS', 'FRANCE', 'contact@labosport.com', '0');
INSERT INTO entreprise VALUES('48', 'Mercuriale DATA', '6 rue Saint Charles', '72000', 'Le Mans', 'FRANCE', 'gbrondel@mercuriale-data.com', '0');
INSERT INTO entreprise VALUES('50', 'Centre de Transfert de Technologie du Mans', '20 rue ThalÃ¨s de Milet', '72000', 'Le Mans', 'FRANCE', 'jlmary@cttm-lemans.fr', '0');
INSERT INTO entreprise VALUES('52', 'LAVIGNE Mayet', 'Z.I. de Guittion', '72360', 'MAYET', 'FRANCE', 'mayet@lavigne.fr', '0');
INSERT INTO entreprise VALUES('53', 'MMA', '14 Boulevard Marie et Alexandre Oyon', '72030', 'Le Mans Cedex 09', 'FRANCE', 'aurore.belperche@groupe-mma.fr', '0');
INSERT INTO entreprise VALUES('57', 'Data Syscom', '2, avenue d\'Haouza', '72100', 'Le Mans', 'FRANCE', 'ghislain.chaumont@datasyscom.fr', '0');
INSERT INTO entreprise VALUES('59', 'Dassault SystÃ¨mes', '10 Rue Marcel Dassault', '78140', 'Velizy-Villacoublay', 'FRANCE', 'sylvie.delhaye@3ds.com', '0');
INSERT INTO entreprise VALUES('101', 'OMEGA FINANCIAL SOLUTIONS', '28 rue CambacÃ©rÃ¨s', '75008', 'PARIS', 'FRANCE', 'dominique.roulin@omega-financial-solutions.com', '0');
INSERT INTO entreprise VALUES('100', 'EUGEN SYSTEMS', '151 rue Saint Denis', '75002', 'PARIS', 'FRANCE', 'cledressay@eugensystems.com', '0');
INSERT INTO entreprise VALUES('65', 'SynÃ©o', '15 ter Bd Jean Moulin', '44100', 'Nantes', 'FRANCE', 'ch.delavaud@syneo.fr', '0');
INSERT INTO entreprise VALUES('67', 'SCHEDSTAR', '16 rue du Docteur Leroy', '72000', 'Le Mans', 'FRANCE', 'schedstar@wanadoo.fr', '0');
INSERT INTO entreprise VALUES('70', 'Centre Hospitalier Le Mans', '194 av. Rubillard ', '72037', 'Le Mans', 'FRANCE', 'affairesgeneralessct@ch-lemans.fr', '0');
INSERT INTO entreprise VALUES('71', 'A.E.S. CHEMUNEX', 'Rue Maryse BastiÃ© Ker Lann CS17219', '35172', 'BRUZ CEDEX', 'France', 'f.gougeon@aeschemunex.com', '0');
INSERT INTO entreprise VALUES('73', 'CGI France', '9 boulevard AmpÃ¨re', '44470', 'CARQUEFOU', 'France', 'marine.heulot@logica.com', '0');
INSERT INTO entreprise VALUES('74', 'LIUM', 'UniversitÃ© du Maine Avenue Olivier Messiaen', '72085', 'Le Mans Cedex 9', 'France', 'secretariat@lium.univ-lemans.fr', '0');
INSERT INTO entreprise VALUES('75', 'SNR ROULEMENTS', ' Service Emploi 1 rue des Usines', '74000', 'ANNECY', 'France', '', '0');
INSERT INTO entreprise VALUES('76', 'DIRECTION DE LA RECHERCHE ET DE L\'INNOVATION GDF SUEZ', '361 rue du PrÃ©sident Wilson BP 33', '93211', 'ST DENIS LA PLAINE', 'FRANCE', 'cristophe.louvet@gdfsuez.com', '0');
INSERT INTO entreprise VALUES('77', 'SII Ouest', '3 bis, avenue Belle Fontaine', '35510', 'Cesson-SÃ©vignÃ©', 'FRANCE', ' jlesourd@sii.fr', '0');
INSERT INTO entreprise VALUES('78', 'ASSYSTEM France', '18 rue Bobby Sands', '44813', 'ST HERBLAIN CEDEX', 'FRANCE', 'mhuo@assystem.com', '0');
INSERT INTO entreprise VALUES('79', 'JOHNSON CONTROLS', 'ZI Route de Mamers', '72400', 'LA FERTE BERNARD', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('80', 'SOPRA GROUP', 'Tour Manhattan La DÃ©fense 5 place de l', '92095', 'COURBEVOIE', 'FRANCE', 'schopelin@sopragroup.com', '0');
INSERT INTO entreprise VALUES('81', 'CAPGEMINI TELECOM MEDIA DEFENSE', 'Tour Europlaza 20 avenue AndrÃ© Prothin', '92927', 'LA DEFENSE CEDEX', 'FRANCE', 'fanny.gicquel@capgemini.com', '0');
INSERT INTO entreprise VALUES('82', 'ATOS ORIGIN INGEGRATION', '12 F rue du PÃ¢tis Tatelin', '35000', 'RENNES', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('83', 'OCEANET', '7 rue des FrÃªnes - ZAC de la Pointe', '72190', 'SARGE-LES-LE-MANS', 'FRANCE', 'isabelle@oceanet.com', '0');
INSERT INTO entreprise VALUES('87', 'CIRTI NANTES', '2 - 4 rue de CoulongÃ© Zone de l\'EraudiÃ¨re', '44328', 'Nantes Cedex 3', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('85', 'SERVICE DEPARTEMENTALE D\'INCENDIE ET DE SECOURS DE LA SARTHE', '13 boulevard St Michel', '72190', 'COULAINES', 'FRANCE', 'ksa@sdis72.fr', '0');
INSERT INTO entreprise VALUES('86', 'TW LOGISTICS GERMANY GMBH', 'Schopfheimerstrasse 27 a', 'D - 7954', 'LORRACH-BRAMBACH', 'ALLEMAGNE', '', '0');
INSERT INTO entreprise VALUES('88', 'O2 DÃ©veloppement', 'ZA de Montheard 31 Rue Edgard Brandt', '72000', 'LE MANS', 'FRANCE', 'renaud@o2.fr', '0');
INSERT INTO entreprise VALUES('89', 'MAIRIE DE ST PATERNE', '2 rue Charles Anjubault', '72610', 'ST PATERNE', 'FRANCE', 'mairie.saintpaterne@wanadoo.fr', '0');
INSERT INTO entreprise VALUES('90', 'ALGORITHME INFORMATIQUE', '6 rue de BÃ©ner', '72530', 'YVRE L\'EVEQUE', 'FRANCE', 'tfoucault@algrithmeinformatique.fr', '0');
INSERT INTO entreprise VALUES('91', 'SCP Drs S. LANDY et J.M. MONSALLIER', 'Le Coubertin 37 - 39 avenue de QuakenbrÃ¼ck', '61000', 'ALENCON', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('92', 'CENTRE HOSPITALIER SPECIALISE DE LA SARTHE', '20 avenue du 19 mars 1962', '72700', 'ALLONNES', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('93', 'AXIANS', '18 rue Thomas Edison', '72014', 'LE MANS CEDEX 2', 'FRANCE', 'bdore@axians.com', '0');
INSERT INTO entreprise VALUES('94', 'CIN ST MANDRIER', 'Route du SÃ©maphore du Cap Cepet', '83430', 'SAINT MANDRIER SUR MER', 'FRANCE', 'cin_sm.proviseur@marine.dÃ©fense.gouv.fr', '0');
INSERT INTO entreprise VALUES('95', 'F.P.E.E.', 'ZI Ouest ', '72350', 'BRULON', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('96', 'INDUSTRIE CHIMIQUE DU SENEGAL', 'km 17 route de Rufisque ', ' ', 'DAKAR', 'SENEGAL', '', '0');
INSERT INTO entreprise VALUES('97', 'ASSOCIATION GESTION CENTRE SOCIAL DEPARTEMENTAL \"GENS DU VOYAGE\"', '22 rue FranÃ§ois Monier - BP 23068', '72003', 'LE MANS CEDEX 1', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('98', 'ACADEMIE WUDANG KUNGFU OF CHINA', 'Temple Yuanhe - Montage Wudang', '442000', 'CHIYAN Prov. HUBEI', 'CHINA', 'wdgf.cn@163.com', '0');
INSERT INTO entreprise VALUES('99', 'C.T.C.A.M.', '13 rue de Belle Ile', '72190', 'COULAINES', 'FRANCE', 'christophe.eude@ctcam.fr', '0');
INSERT INTO entreprise VALUES('102', 'ATOUT WEB INFORMATIQUE', '2 promenade Georges Godet', '85100', 'LES SABLES D\'OLONNE', 'FRANCE', 'contact@atout-web.fr', '0');
INSERT INTO entreprise VALUES('103', 'E-CONCEPT', '15 rue de la ChaussÃ©e', '61000', 'ALENCON', 'FRANCE', 'info@conceptmultimedia.fr', '0');
INSERT INTO entreprise VALUES('104', 'CROSS JOBOURG', 'Route d\'Auderville', '50440', 'JOBOURG', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('105', 'SCP OLLU-RENAUD', '4 avenue d\'Haouza', '72000', 'LE MANS', 'FRANCE', 'ollu.renaud@wanadoo.fr', '0');
INSERT INTO entreprise VALUES('106', 'FAURE HERMANN', 'Route de BonnÃ©table BP 20154', '72406', 'LA FERTE BERNARD', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('107', 'COMMUNIC-ART', '18 rue de Gergovie', '75014', 'PARIS', 'FRANCE', 'communic.art@wanadoo.fr', '0');
INSERT INTO entreprise VALUES('108', 'SOCIETE SYLEAM', '27 avenue Jean Mantelet', '61000', 'ALENCON', 'FRANCE', 'contact@syleam.fr', '0');
INSERT INTO entreprise VALUES('109', 'ALLIANCE MICRO', '7 ter de la Monnaie', '37000', 'TOURS', 'FRANCE', 'alliance@numericable.fr', '0');
INSERT INTO entreprise VALUES('110', 'ASSOCIATION LE CERCLE DES AMIS DU FORUM LE MANS LE MONDE', 'Maison de l\'UniversitÃ© Avenue Olivier Messiaen', '72085', 'LE MANS CEDEX', 'FRANCE', 'daniel.luzzati@univ-lemans.fr', '0');
INSERT INTO entreprise VALUES('111', 'MAESPIRIT SARL', '13 Rue des Labours', '77380', 'COMBS LA VILLE', 'FRANCE', 'rf@maespirit.fr', '0');
INSERT INTO entreprise VALUES('112', 'LEGRAND France', 'Route d\'Evron BP 36', '72140', 'SILLE LE GUILLAUME', 'FRANCE', 'jennifer.voillot@legrand.fr', '0');
INSERT INTO entreprise VALUES('113', '3SI', '2 bis rue de Rochefort', '23000', 'GUERET', 'FRANCE', '3si@3si.fr', '0');
INSERT INTO entreprise VALUES('114', 'BRIN DE SOLEIL', '14 allÃ©e des Pentes de l\'AntonniÃ¨re', '72650', 'AIGNE', 'FRANCE', 'brin.de.soleil@wanadoo.fr', '0');
INSERT INTO entreprise VALUES('200', 'CERIVAN', '9 chemin de la Gare', '72390', 'Dollon', 'FRANCE', 'mail@cerivan.com', '0');
INSERT INTO entreprise VALUES('208', 'DAMS Team', 'Z.A. de Bel Air', '72230', 'Ruaudin', 'France', '', '0');
INSERT INTO entreprise VALUES('209', 'AKELIO', '7 rue Camille Pissaro', '72100', 'LE MANS', 'FRANCE', 'louvel@akelio.fr', '0');
INSERT INTO entreprise VALUES('123', 'AVANTIAS INTELLIGENT DOCUMENTS', '37 RUE DE LYON', '75012', 'PARIS', 'FRANCE', 'schretien@avantias.com', '0');
INSERT INTO entreprise VALUES('125', 'CAFE FRAPPE', '15 rue Gougeard - Hall B', '72000', 'Le Mans', 'FRANCE', 'thierry.barbe@cafe-frappe.fr', '0');
INSERT INTO entreprise VALUES('142', 'I-CÃ´ne', '25 rue des marais', '72000', 'Le Mans', 'France', 'i.cone@i-cone.fr', '0');
INSERT INTO entreprise VALUES('144', 'HYC', 'ZA CHAMP FLEURI 2', '72190', 'St Pavace', 'France', 'hyc@wanadoo.fr', '0');
INSERT INTO entreprise VALUES('153', 'TAPAKAH Innovation', 'SOURCHES', '72240', 'Saint SYMPHORIEN', 'FRANCE', 'thierry@mourlanne.com', '0');
INSERT INTO entreprise VALUES('158', 'CAPGEMINI TMD', '7 rue FrÃ©dÃ©ric Clavel', '92287', 'SURESNES', 'France', 'delphine.robin@capgemini.com', '0');
INSERT INTO entreprise VALUES('159', 'DONATION CENTRE OF RAILWAY YOUTH DEVELOPMENT', 'Jia 8 YangFangDian', 'HaiDian', 'BEIJING', 'CHINE', 'zhang.ronge@gmail.com', '0');
INSERT INTO entreprise VALUES('160', 'SOPRA GROUP', 'Technopole Amor Plazza 5 et 7 impasse Nougaro', '44821', 'ST HERBLAIN', 'FRANCE', 'vparis@sopragroup.com', '0');
INSERT INTO entreprise VALUES('161', 'SMILE BENELUX', 'Gebouw \"Hendrik de Keyser\" Krelis Louwenstraat 1 F07', '1055 DA', 'AMSTERDAM', 'PAYS-BAS', 'olivier.guillaumond@smile-benelux.com', '0');
INSERT INTO entreprise VALUES('162', 'AVANTIAS', '74 rue de Paris - BÃ¢timent D - 1er Ã©tage', '35000', 'RENNES', 'FRANCE', 'ssarrazin@avantias.com', '0');
INSERT INTO entreprise VALUES('163', 'CGI France', '47 avenue Bartholdi', '72000', 'Le Mans', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('164', 'SOCIETE GENERALE', 'Espace 21/3 - 54 place de l\'Ellipse', '92972', ' PARIS LA DEFENSE 7', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('165', 'NOVAE CONSEIL', '45 avenue de Colmar', '67100', 'STRASBOURG', 'FRANCE', 'administratif@novae-conseil.fr', '0');
INSERT INTO entreprise VALUES('166', 'NADEO', '31/33 rue FalguiÃ¨re', '75015', 'Paris', 'FRANCE', 'contact@nadeo.com', '0');
INSERT INTO entreprise VALUES('167', 'ZHONGPING SHANGTONG', '74 rue Xian Yang', ' ', 'TIANJIN', 'CHINE', '', '0');
INSERT INTO entreprise VALUES('168', 'NDS TECHNOLOGIE', '65 rue Camille Desmoulins', '92130', 'ISSY LES MOULINEAUX', 'FRANCE', 'lturmel@nds.com', '0');
INSERT INTO entreprise VALUES('169', 'SHENYANG FORTUNE PRECISION EQUIPEMENT CO LDT', 'NÂ° 18-1 Feiyun Road.Hunnan New District.Shenyang', '110168', 'SHENYANG', 'CHINE', '', '0');
INSERT INTO entreprise VALUES('170', 'ENTREPRISE YE FAN', 'Parc Le Saulcy - Rue Jean Monnet ', '60180', ' NOGENT SUR OISE', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('171', 'MEKENSLEEP', '26 rue des Rosiers', '75004', 'PARIS', 'FRANCE', 'admin@mekensleep.com', '0');
INSERT INTO entreprise VALUES('172', 'APSIDE', '3 place du GÃ©nÃ©ral Giraud', '35000', 'RENNES', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('173', 'VENTES-RESPONSABLES.COM', '59 quai Le Gallo', '92100', 'BOULOGNE BILLANCOURT', 'FRANCE', 'kilian.oneill@ventes-responsables.com', '0');
INSERT INTO entreprise VALUES('178', 'LE MANS METROPOLE', '16 avenue FranÃ§ois Mitterand', '72039', ' LE MANS CEDEX 9', 'France', '', '0');
INSERT INTO entreprise VALUES('179', 'CAPGEMINI', '16 Mail Pablo Picasso - CS 81515', '44015', 'NANTES CEDEX 1', 'FRANCE', 'lucie.martins@capgemini.com', '0');
INSERT INTO entreprise VALUES('180', 'CENTRE INGIENERIE MATERIEL SNCF', '4 allÃ©e des GÃ©meaux', '72000', 'Le Mans', 'France', 'helene.renault@sncf.fr', '0');
INSERT INTO entreprise VALUES('181', 'INGENICO', '28-32 Boulevard de Grenelle', '75015', 'Paris', 'FRANCE', 'eric.decisier@ingenico.com', '0');
INSERT INTO entreprise VALUES('182', 'TRIPALL', '10 rue du Docteur Leroy', '72000', 'LE MANS', 'FRANCE', 'nils@tripall.fr', '0');
INSERT INTO entreprise VALUES('183', 'MAINE IMAGE SANTE', '20 rue St Bertrand', '72058', ' LE MANS CEDEX 2', 'FRANCE', 'martine.meunier@72mis.fr', '0');
INSERT INTO entreprise VALUES('184', 'CONTY', '6 rue de Provence', '72190', 'ST PAVACE', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('185', 'LYCEE SAINT CHARLES', '7 avenue BollÃ©e', '72000', 'LE MANS', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('186', 'NOZICAA', '20 rue de Sardaigne', '72100', 'Le Mans', 'France', 'g.forestier@nozicaa.com', '0');
INSERT INTO entreprise VALUES('187', 'LYCEE MONTESQUIEU', '1 rue de Montesquieu BP 28310', '72008', 'LE MANS CEDEX 1', 'FRANCE', 'ce.0720029Rac-nantes.fr', '0');
INSERT INTO entreprise VALUES('188', 'SPECINOV', '40 allÃ©e de la Saulaie', '49800', 'TRELAZE', 'FRANCE', 'specinov@specinov.fr', '0');
INSERT INTO entreprise VALUES('189', 'PREFECTURE DE LA SARTHE', 'Place Aristide Briand', '72041', 'Le Mans Cedex 09', 'France', '', '0');
INSERT INTO entreprise VALUES('190', 'STUBER SYSTEMS Gmbh', 'KÃ¶penicker Strasse 325', 'D 12555', 'Berlin', 'Allemagne', 'matthias@stuber.de', '0');
INSERT INTO entreprise VALUES('191', 'LA SAUVEGARDE MAYENNE SARTHE', '52 rue de BeaugÃ©', '72000', 'Le Mans', 'France', 'dired.dir@sms.asso.fr', '0');
INSERT INTO entreprise VALUES('192', 'MUGUET', '44 avenue FranÃ§ois Mitterrand', '72230', 'MULSANNE', 'FRANCE', 'muguet.stephane@free.fr', '0');
INSERT INTO entreprise VALUES('193', 'ASSOCIATION DEPARTEMENTALE DES INFIRMES MOTEURS DE LA SARTHE', '13 rue de TorcÃ©', '72000', 'LE MANS', 'FRANCE', 'adimc72@orange.fr', '0');
INSERT INTO entreprise VALUES('194', 'CALENDRIERS ALEXANDRE', '58 rue de Roumanie - ZA du Danemark', '72000', 'Le Mans', 'France', 'stephane@calendrier.fr', '0');
INSERT INTO entreprise VALUES('195', 'PNN SOFT', 'Office 312 - 1 Pivnichno-Syrets\'ka str.', '04073', 'KIEV', 'UKRAINE', 'pnninfo@pnn.com.ua', '0');
INSERT INTO entreprise VALUES('197', 'AN EX SERV', 'Appt 8 - 35 rue des Ridelleries', '53000', 'LAVAL', 'FRANCE', 'anexderv@gmail.com', '0');
INSERT INTO entreprise VALUES('361', 'MICRO-INFO-EXPERT', '3 bis place de l\'Ã©peron', '72000', 'Le Mans', 'FRANCE', 'gluttmann@m-i-e.fr', '0');
INSERT INTO entreprise VALUES('439', 'PRO AVANCIA', 'Immeuble Asturia C - 4 rue Edith Piaf', '44800', 'St Herblain', 'FRANCE', 'sabrina.duval@proavancia.com', '0');
INSERT INTO entreprise VALUES('340', 'Polymont', '19 boulevard Marie et Alexandre Oyon', '72100', 'Le Mans', 'FRANCE', 'LAURE.GAZON@POLYMONT.FR', '0');
INSERT INTO entreprise VALUES('215', 'Renault Usine Du Mans', 'BP 219 15 Av Pierre Piffault', '72005', 'Le Mans', 'FRANCE', 'jean-louis.breat@renault.com', '0');
INSERT INTO entreprise VALUES('280', 'Sauvegarde Mayenne Sarthe', '52, rue de BeaugÃ©', '72000', 'Le Mans', 'FRANCE', 'dired.dir@sms.asso.fr', '0');
INSERT INTO entreprise VALUES('446', 'LIMSI-CNRS', 'DÃ©lÃ©gation Ile-de-France Sud, Avenue de la Terrasse', '91190', 'Gif-Sur-Yvette', 'France', '', '0');
INSERT INTO entreprise VALUES('272', 'Co.cli.co', '9 rue de la Paille', '72000', 'Le Mans', 'FRANCE', 'abougard@coclico.fr&#8194;', '0');
INSERT INTO entreprise VALUES('337', 'CAPGEMINI', 'Rennes Atalante Champs Blancs, 7 rue Claude Chappe, CS67746', '35577', 'CESSON SEVIGNE', 'FRANCE', 'sayana.long@capgemini.com', '0');
INSERT INTO entreprise VALUES('261', 'Apotamox', '52 rue Belfort BP 25100', '72005', 'LE MANS CEDEX 1', 'France', 'jean-francois.simon@apotamox.com', '0');
INSERT INTO entreprise VALUES('262', 'L.D.C. SablÃ©', 'ZI St Laurent BP 88', '72302', 'SablÃ© sur Sarthe', 'France', '', '0');
INSERT INTO entreprise VALUES('227', 'Centre RÃ©gional OpÃ©rationnel de Secours et de Sauvetage maritimes (CROSS) de Jobourg', '14 route d\'Auderville', '50440', 'JOBOURG', 'FRANCE', 'thierry.pichon@developpement-durable.gouv.fr', '0');
INSERT INTO entreprise VALUES('228', 'Kocka', '28 rue edgar brandt', '72000', 'le mans', 'FRANCE', 'contact@adctp.com', '0');
INSERT INTO entreprise VALUES('229', 'AGRO-EVOLUTION', 'Domaine expÃ©rimental de Sourches', '72240', 'SAINT SYMPHORIEN', 'France', '', '0');
INSERT INTO entreprise VALUES('230', 'DECATHLON IT CRM', '4 rue du Professeur Langevin', '59000', 'LILLE', 'France', '', '0');
INSERT INTO entreprise VALUES('231', 'CGI France', 'Immeuble CB 16 - 17 place des Reflets', '92097', 'PARIS LA DEFENSE CEDEX', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('232', 'Sopra Steria', 'Immeuble Le PersÃ©e, 19 Bd Marie et Alexandre Oyon', '72100', 'Le Mans', 'France', 'dominique.lenormand@sopragroup.com', '0');
INSERT INTO entreprise VALUES('414', 'Novia Systems', '7 Mail Picasso', '44000', 'Nantes', 'France', '', '0');
INSERT INTO entreprise VALUES('427', 'MAN TELECOM', '114 Rue Nationale', '72000', 'Le Mans', 'France', '', '0');
INSERT INTO entreprise VALUES('234', 'LEONI CIA Cable Systems SAS', '1 avenue Louis Pasteur', '28630', 'GELLAINVILLE', 'FRANCE', 'leoni-cia@leoni.com', '0');
INSERT INTO entreprise VALUES('235', 'PÃ´le Formations', '186, rue nationale', '72000', 'Le Mans', 'FRANCE', 'jm.simon@pole-formations.fr', '0');
INSERT INTO entreprise VALUES('237', 'AUTO CHASSIS INTERNATIONAL', '15 avenue Pierre Piffault', '72086', 'LE MANS', 'FRANCE', 'thierry.bourdin@renault.com', '0');
INSERT INTO entreprise VALUES('238', 'CITINFO', '12 bis place d\'Alger', '72000', 'Le Mans', 'France', 'z.chaddad@citinfo.fr', '0');
INSERT INTO entreprise VALUES('239', 'ENTREPRISE JACQUES DENIS', '2 rue de la SapiniÃ¨re - ZA de la ChenardiÃ¨re', '72560', 'CHANGE', 'France', 'xdenis@jacques-denis.com', '0');
INSERT INTO entreprise VALUES('240', 'ISMANS', '44 avenue F.A. Bartholdi', '72000', 'Le Mans', 'France', '', '0');
INSERT INTO entreprise VALUES('241', 'Mairie d\'AlenÃ§on', 'Place MarÃ©chal Foch', '61000', 'ALENCON', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('242', 'FIMOR SAS', '210 rue du Polygone', '72058', 'LE MANS', 'FRANCE', 'phm@fimor.fr', '0');
INSERT INTO entreprise VALUES('243', 'SODIFRANCE ISIS', '2 rue de la Voie LactÃ©e, Novaxis 2 - BÃ¢t. B', '72100', 'LE MANS', 'FRANCE', 'llecossois@sodifrance.fr', '0');
INSERT INTO entreprise VALUES('244', 'ThÃ©tis Interactive', '1 rue Charles Fabry', '72013', 'Le Mans Cedex 2', 'France', '', '0');
INSERT INTO entreprise VALUES('245', 'APPLIMO', 'ZI Les Petites BruyÃ¨res - Route de Mamers - BP 26', '72402', ' LA FERTE BERNARD CEDEX', 'FRANCE', 'boirons@applimo.fr', '0');
INSERT INTO entreprise VALUES('246', 'IDEXLAB', '9 rue Dareau', '75014', 'PARIS', 'FRANCE', 'jean-louis.lievin@idexlab.com', '0');
INSERT INTO entreprise VALUES('247', 'L.P.S. : LES PORCS DE LA SARTHE', '15 rue Jean GrÃ©millon', '72000', 'LE MANS', 'FRANCE', 'contact@cenomans.fr', '0');
INSERT INTO entreprise VALUES('249', 'LINGUA ET MACHINA', 'Maison de la Technopole - BP 102 - 6 rue LÃ©onard de Vinci', '53001', 'LAVAL CEDEX', 'FRANCE', 'fbc@lingua-et-machina.com', '0');
INSERT INTO entreprise VALUES('250', 'MONTJOIE ASSOCIATION', '75 bd Lamartine', '72000', 'LE MANS', 'FRANCE', 'info@montjoie.asso.fr', '0');
INSERT INTO entreprise VALUES('251', 'MYSPORTCONNECT', '23/25 rue Jean-Jacques Rousseau', '75001', 'Paris', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('252', 'PHONEAXE', '22 rue Pierre Martin', '72100', 'LE MANS', 'FRANCE', 'sebastien@phoneaxe.fr', '0');
INSERT INTO entreprise VALUES('254', 'VESCAPE', 'Chausseestr. 56', '10115', 'BERLIN', 'ALLEMAGNE', '', '0');
INSERT INTO entreprise VALUES('255', 'THALES TRANSPORTATION SYSTEMS GmbH', 'Colditzstrasse 34 - 36', '12099', 'BERLIN', 'ALLEMAGNE', '', '0');
INSERT INTO entreprise VALUES('256', 'THALES COMMUNICATIONS ET SECURITY', '83 - 85 rue Emile Brault', '53000', 'LAVAL', 'LE MANS', 'mireille.seme@thalesgroup.com', '0');
INSERT INTO entreprise VALUES('257', 'SYSGO AG', 'Office Mainz - Am Pfaffenstein 14', '55270', 'KEIN-WINTERNHEIM', 'ALLEMAGNE', '', '0');
INSERT INTO entreprise VALUES('326', 'OCTOPOLUX EURL', '43 Rue Crozatier', '75012', 'Paris', 'FRANCE', 'paul@octopolux.com', '0');
INSERT INTO entreprise VALUES('432', 'talentroc solutions', '2 rue du VÃ©lodrome de Longchamp', '44300', 'Nantes', 'FRANCE', 'clement.horhant@talentroc.com', '0');
INSERT INTO entreprise VALUES('263', 'ARCHIMEN Active 3D', '2 rue RenÃ© Char BP 66606', '21066', 'Dijon Cedex', 'France', '', '0');
INSERT INTO entreprise VALUES('444', 'MicroTec Informatique', 'Courtiron', '72340', 'MarÃ§on', 'France', '', '0');
INSERT INTO entreprise VALUES('408', 'VINCI Energies SI', '24 Rue Thomas Edison', '72021', 'Le Mans Cedex 2', 'France', '', '0');
INSERT INTO entreprise VALUES('284', 'Umanis Centre de Service Tours', '18 rue du Pont de l\'Arche', '37550', 'SAINT AVERTIN', 'FRANCE', 'cdezecot@umanis.com', '0');
INSERT INTO entreprise VALUES('409', 'FuturMaster', 'Immeuble l\'AurÃ©lium, 1 cours de l\'Ã®le Seguin', '92100', 'Boulogne Billancourt', 'France', '', '0');
INSERT INTO entreprise VALUES('434', 'eBusiness Information', '45-47 avenue Carnot', '94230', 'Cachan', 'FRANCE', 'ayameogo@excilys.com', '0');
INSERT INTO entreprise VALUES('394', 'Biocoop', 'Plateforme Grand Ouest, Zone de Confortland, CS 46851 MELESSE', '35768', 'Saint-GrÃ©goire Cedex', 'FRANCE', 'f.belloir@biocoop.fr', '0');
INSERT INTO entreprise VALUES('302', 'CAPGEMINI', '3 AllÃ©e de la Croix des HÃªtres CS 46412', '35064', 'RENNES CEDEX', 'FRANCE', 'marie-evelyne.jabbour@capgemini.com', '0');
INSERT INTO entreprise VALUES('288', 'VALEO', 'ZA de l\'aubrÃ©e', '72300', 'SablÃ© sur Sarthe', 'FRANCE', 'nathalie.vandamme@valeo.com', '0');
INSERT INTO entreprise VALUES('333', 'Elsevier-Masson', '62 rue Camille Desmoulins', '92442', 'Issy-Les-Moulineaux', 'PARIS', '', '0');
INSERT INTO entreprise VALUES('334', 'EES Assurance', '4 Promenade d\'AndromÃ¨de', '72100', 'Le Mans', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('325', 'ENTREPRISE D\'INFORMATIQUE DE JINGZHOU HENGYU', 'Rue de Hongmen Jingu Ordinateur Centre Appr 1104', '434000', 'SHASHI', 'CHINE', '', '0');
INSERT INTO entreprise VALUES('292', 'CPAM de l\'Orne', '34, Place Bonet - CS 30200', '61012', 'ALENCON Cedex', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('332', 'CGI France', '3 bis Avenue de Belle Fontaine', '35510', 'Cesson-SÃ©vignÃ©', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('294', 'GIE SESAM-VITALE', '5, boulevard Marie et Alexandre Oyon', '72019', 'LE MANS Cedex 2', 'FRANCE', 'Caroline.PRODHOMME@sesam-vitale.fr', '0');
INSERT INTO entreprise VALUES('296', 'Datanaute', '10 rue des Peupliers', '72190', 'SARGE LES LE MANS', 'FRANCE', 'jcdespres@datanaute.com', '0');
INSERT INTO entreprise VALUES('447', 'Anomes', '121 boulevard Sebastopol', '75002', 'Paris', 'FRANCE', 'contact@anomes.com', '0');
INSERT INTO entreprise VALUES('445', 'ADG Sofware Engineering', '57, rue de la CrochardiÃ¨re', '72000', 'Le Mans', 'France', '', '0');
INSERT INTO entreprise VALUES('442', 'PWC', '2, rue Gerhard Mercator', 'L-1014', 'Luxembourg', 'Luxembourg', '', '0');
INSERT INTO entreprise VALUES('343', 'Infotel Ouest Le Mans', '2, promenade dâAndromÃ¨de', '72100', 'Le Mans', 'FRANCE', 'benoit.laurant@infotel.com', '0');
INSERT INTO entreprise VALUES('301', 'AAREAL BANK AG', 'Paulinenstrasse 15', '65189', 'WIESBADEN', 'ALLEMAGNE', '', '0');
INSERT INTO entreprise VALUES('303', 'CAPGEMINI', '485 Avenue de l\'Europe', '38330', 'MONTBONNOT SAINT MARTIN', 'FRANCE', 'vincent.lachambre@capgemini.com', '0');
INSERT INTO entreprise VALUES('304', 'CAPGEMINI', '37 Rue de Lyon', '75012', 'Paris', 'FRANCE', 'stephanie.chretien@capgemini.com', '0');
INSERT INTO entreprise VALUES('305', 'CONIX', '34 rue Guynemer ', '92130', 'Issy les Moulineaux', 'FRANCE', 'antoine.vilain@conix.fr', '0');
INSERT INTO entreprise VALUES('306', 'DEVOTEAM ', '3 rue Blaise Pascal', '22300', 'LANNION', 'FRANCE', 'bruno.fiter@devoteam.com', '0');
INSERT INTO entreprise VALUES('307', 'KASTELL PIC', '19,21 Rue de ThalÃ¨s de Mile', '72000', 'Le Mans', 'FRANCE', 'brunoguillaume@kastellpic.com', '0');
INSERT INTO entreprise VALUES('308', 'ODIMA Groupe OnePoint', '22, Rue de l\'Europe', '44240', 'LA CHAPELLE SUR ERDRE', 'FRANCE', 't.clapaud@groupeonepoint.com', '0');
INSERT INTO entreprise VALUES('309', 'SARL BLANC MARINE CYCLES', '281 chemin des pommiers Z.I. Les Duroux', '24230', 'Saint Antoine de Breuilh', 'FRANCE', 'blancmarine06@yahoo.fr', '0');
INSERT INTO entreprise VALUES('310', 'SAS HEAR KNOW', '9 Rue Dareau', '75014', 'Paris', 'FRANCE', 'lelievre.jp@free.fr', '0');
INSERT INTO entreprise VALUES('381', 'APSIDE', '58 Avenue du GÃ©nÃ©ral Leclerc', '92514', ' BOULOGNE Cedex', 'FRANCE', 'lemonnier@apside.fr', '0');
INSERT INTO entreprise VALUES('312', 'SORA LOGICIELS', '10 Boulevard Leprince Ringuet', '72000', 'Le Mans', 'vincent.abballe@sora.fr', '', '0');
INSERT INTO entreprise VALUES('313', 'Umanis', 'Centre Hexagone, 1121 Rue de la Bergeresse', '45160', 'OrlÃ©ans', 'FRANCE', 'eruter@umanis.com', '0');
INSERT INTO entreprise VALUES('314', 'Technocentre Renault', '1 Avenue du Golf', '78288', 'Guyancourt Cedex', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('315', 'GROUPE LEBLANC', '6-8 Rue Michel Faraday', '72000', 'Le Mans', 'FRANCE', 'lcx@lcx.fr', '0');
INSERT INTO entreprise VALUES('316', 'LEVRAT SARL', 'Z.A. La PÃ©cardiÃ¨re', '72450', 'MONTFORT LE GESNOIS', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('317', 'VALORYS MEDIA', '4 Rue HaurÃ©au', '72000', 'Le Mans', 'FRANCE', 'info@valorys.fr', '0');
INSERT INTO entreprise VALUES('318', 'ATS AUTO TECHNO SPORTS', '35B Rue Pierre Martin', '72100', 'Le Mans', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('319', 'LYCEE LE MANS SUD', '128 Rue Henri Champion', '72100', 'Le Mans', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('320', 'ATELIER PC', '426 Avenue FÃ©lix Geneslay', '72100', 'Le Mans', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('321', 'AGENCE CRAYONS DE COULEURS', 'Quartier d\'affaires Novaxis 75 Boulevard Marie et Alexandre Oyon', '72100', 'Le Mans', 'FRANCE', 'contact@crayonsdecouleurs.fr', '0');
INSERT INTO entreprise VALUES('322', 'ANTVOICE', '28, Rue du Sentier', '75002', 'Paris', 'FRANCE', 'rodolphe@antvoice.com', '0');
INSERT INTO entreprise VALUES('323', 'PERSPECTEEV SAS', '11 Rue Paul Lelong', '75002', 'Paris', 'FRANCE', 'robin@bankin.com', '0');
INSERT INTO entreprise VALUES('324', 'BANQUE POUR LE COMMERCE ET L\'INDUSTRIE', '57 Avenue Gamal Abdel Nasser', 'BP 5050', 'NOUAKCHOTT', 'MAURITANIE', '', '0');
INSERT INTO entreprise VALUES('327', 'SARL OZYTIS', '97, Boulevard FÃ©lix Grat', '53000', 'Laval', 'FRANCE', 'gregoire.larreur@ozytis.fr', '0');
INSERT INTO entreprise VALUES('328', 'Synergie AssociÃ©s', '54 boulevard Rodin ', '92137', 'Issy Les Moulineaux ', 'FRANCE', 'alexandre.rolland@synergieassocies.com ', '0');
INSERT INTO entreprise VALUES('329', 'NBM GROUPE', '152, Rue du temple', '75003', 'Paris', 'FRANCE', 'yonathan.malet@nbmgroupe.com', '0');
INSERT INTO entreprise VALUES('426', 'TRANSATEL', '192 Avenue Charles de gaulle - CS 10034', '92523', 'NEUILLY SUR SEINE', 'France', '', '0');
INSERT INTO entreprise VALUES('430', 'OFIB', '62 BD OYON', '72000', 'LE MANS', 'FRANCE', 'stephane.ramon@ofib.fr', '0');
INSERT INTO entreprise VALUES('433', 'entre', 'ferfer', '45000', 'ferfre', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('377', 'PRN de l\'UniversitÃ© du Maine', 'Avenue Olivier Messiaen', '72085', 'Le Mans', 'FRANCE', 'Nicolas.Postec@univ-lemans.fr', '0');
INSERT INTO entreprise VALUES('379', 'DAP - Ecole des Mines de Nantes', '4, rue Alfred Kastler  - BP 20722', '44307', 'Nantes Cedex 3', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('443', 'SIGMA', '8, rue Newton', '44240', 'La Chapelle-sur-Erdre', 'France', '', '0');
INSERT INTO entreprise VALUES('382', 'ABS Alto', '9 Avenue Paul Verlaine ', '38030', 'GRENOBLE CEDEX 2', 'FRANCE', 'absalto@abasalto.com', '0');
INSERT INTO entreprise VALUES('440', 'Orange Logic', '1006 RUE DE LA CROIX VERTE, BAT. 7', '34090', 'Montpellier', 'FRANCE', 'sandra.roudil@orangelogic.com', '0');
INSERT INTO entreprise VALUES('383', 'Usine d\'ElectricitÃ© de Metz', '2 Place du Pontiffroy, BP 20129', '57014', 'METZ CEDEX 01', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('384', 'THALES', '110 Avenue du MarÃ©chal Leclerc', '49300', 'CHOLET', 'FRANCE', 'mireille.seme@thalesgroup.com', '0');
INSERT INTO entreprise VALUES('385', 'GLPLUS', '16 Bis Rue Sainte-Honorine', '95150', 'TAVERNY', 'PARIS', 'michelcarre.gl@orange.fr', '0');
INSERT INTO entreprise VALUES('386', 'GROUPE ONEPOINT', '235 Avenue Le-jour-se-lÃ¨ve', '92100', 'BOULOGNE BILLANCOURT', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('387', 'NAONED SYSTEMES', '1 Ter Avenue de la Vertonne', '44120', 'VERTOU', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('388', 'Centre d\'EurointÃ©gration ', 'BÃ¢timent 45-56 Rue Dmytrivska', '01054', 'KIEV', 'UKRAINE', '', '0');
INSERT INTO entreprise VALUES('389', 'AGICIA', '46 rue RenÃ© Clair', '75018', 'Paris', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('390', 'CREN', 'UniversitÃ© du Maine Avenue Olivier Messiaen', '72085', 'Le Mans Cedex 9', 'FRANCE', '', '0');
INSERT INTO entreprise VALUES('410', 'Telecopolis', '75 Bd Alexandre Oyon ', '72100', 'Le Mans', 'France', '', '0');
INSERT INTO entreprise VALUES('392', 'ALCATEL-LUCENT International', '4, Rue Louis de Broglie', '22300', 'LANNION', 'FRANCE', 'jean-francois.civel@alcatel-lucent.com', '0');
INSERT INTO entreprise VALUES('412', 'ENSAM', '4 Rue de l\'Hermitage', '53000', 'Laval', 'France', '', '0');
INSERT INTO entreprise VALUES('435', 'D.I.C. Groupe DELTA', 'Parc d\'ActivitÃ©s des Ajeux BP 78', '72400', 'La FertÃ© Bernard', 'FRANCE', 'cbontemps@dic.fr', '0');
INSERT INTO entreprise VALUES('417', 'BWIRED', '48 High St, between Chapel St and Williams Rd Prahran', ' ', 'Melbourne', 'Australie', '', '0');
INSERT INTO entreprise VALUES('420', '2LA Software', '24, rue Edgar Brandt', '72000', 'Le Mans', 'FRANCE', 'frederic.lagrange@2la-software.com', '0');
INSERT INTO entreprise VALUES('421', 'Mairie de Coulaines', 'Square Weyhe', '72190', 'Coulaines', 'France', '', '0');
INSERT INTO entreprise VALUES('422', 'ALCUIN', 'Rue Michael Faraday', '49070', 'BEAUCOUZE', 'France', '', '0');
INSERT INTO entreprise VALUES('423', 'Air France Cargo', 'Avenue Charles de Gaulle', '95700', 'Roissy en France', 'France', '', '0');
INSERT INTO entreprise VALUES('436', 'SWORD', '8 rue Jouanet', '35700', 'Rennes', 'FRANCE', 'erwan.lehan@sword-group.com', '0');
INSERT INTO entreprise VALUES('425', 'HSBC France', '103 Avenue des Champs ElysÃ©es', '75008', 'Paris', 'France', '', '0');
INSERT INTO entreprise VALUES('428', 'eZ.nergy', '48 rue RenÃ© Clair', '75899', 'Paris Cedex 18', 'France', '', '0');
INSERT INTO entreprise VALUES('441', 'APSIDE', 'Tour Saint Pierre - 2 place de la Gare', '37700', 'St Pierre des Corps', 'FRANCE', 'bonneau@apside.fr', '0');

-- -----------------------------
-- insertions dans la table etudiant
-- -----------------------------
INSERT INTO etudiant VALUES('1', 'CHAVENEAU', 'Simon', 'Simon.CHAVENEAU@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('2', 'DIOP', 'Ousmane', 'Ousmane.DIOP@info.univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('3', 'KASZYNSKI', 'Alain', 'Alain.KASZYNSKI@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('4', 'MIOSSEC', 'Guillaume', 'Guillaume.MIOSSEC@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('5', 'NGONGO', 'Eric', 'Eric.NGONGO@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('6', 'PLUCHON', 'Thomas', 'Thomas.PLUCHON@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('7', 'ROCUET', 'Arnaud', 'Arnaud.ROCUET@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('8', 'FAVERGE', 'GaÃªtan', 'Gaetan.FAVERGE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('9', 'GERAULT', 'AurÃ©lien', 'Aurelien.GERAULT@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('10', 'AITE', 'Yasmine', 'Yasmine.AITE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('11', 'ARIS', 'Mariama', 'Mariama.ARIS@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('12', 'BRIZARD', 'Adrien', 'Adrien.BRIZARD@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('13', 'CLAYER', 'Jean-pierre', 'Jean-Pierre.CLAYER@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('14', 'COURCIER', 'SÃ©verine', 'Severine.COURCIER@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('15', 'COUTABLE', 'Julien', 'Julien.COUTABLE@infouniv-lemans.fr', '', '');
INSERT INTO etudiant VALUES('16', 'DENISE', 'Fabien', 'Fabien.DENISE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('17', 'DUGAST', 'Renaud', 'Renaud.DUGAST@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('18', 'GANDON', 'Romuald', 'Romuald.GANDON@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('19', 'GERNIGON', 'Yonnick', 'Yonnick.GERNIGON@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('20', 'GUYON', 'Erwann', 'Erwann.GUYON@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('21', 'LAMBERT', 'FranÃ§ois', 'Francois.LAMBERT@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('22', 'LECONTE', 'Fabien', 'Fabien.LECONTE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('23', 'LEJEUNE', 'Bryan', 'Bryan.LEJEUNE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('24', 'LE ROY', 'Jonathan', 'Jonathan.LE_ROY@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('25', 'LEROUX', 'MichaÃ«l', 'Michael.LEROUX@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('26', 'LOISEAU', 'Jonathan', 'Jonathan.LOISEAU@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('27', 'MADIANGA', 'Prudence', 'PRUDENCE.MADIANGA@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('28', 'PARIS', 'Romain', 'Romain.PARIS@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('29', 'PATAULT', 'KÃ©vin', 'Kevin.PATAULT@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('30', 'PERCHARD', 'Julien', 'Julien.PERCHARD@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('31', 'PERCHERON', 'William', 'WILLIAM.PERCHERON@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('32', 'SAADAOUI', 'Anis', 'Anis.SAADAOUI@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('33', 'TROCHERIE', 'Julien', 'Julien.TROCHERIE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('34', 'VENIAT', 'Eric', 'Eric.VENIAT@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('35', 'ZHOU', 'Mian', 'Mian.ZHOU@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('36', 'BAI', 'Long', 'Long.BAI@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('37', 'BEAUDOIRE', 'CÃ©drick', 'Cedrick.BEAUDOIRE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('38', 'DEGROOT', 'FranÃ§ois-xavier', 'FRANCOIS-XAVIER.DEGROOT@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('39', 'DELALONDE', 'Thomas', 'Thomas.DELALONDE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('40', 'DOSU NGAMPILA', 'Chouga', 'Chouga.DOSU_NGAMPILA@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('41', 'DUPUY', 'GrÃ©gor', 'Gregor.DUPUY@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('42', 'GAALOUL', 'WaÃ«l', 'Wael.GAALOUL@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('43', 'GUEDON', 'Pascal', 'Pascal.GUEDON@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('44', 'JOYAUX', 'RÃ©mi', 'Remi.JOYAUX@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('45', 'JUPIN', 'Jonathan', 'JONATHAN.JUPIN@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('46', 'KABA', 'LancinÃ©', 'Lancine.KABA@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('301', 'GUO', 'Jia', 'Jia_Guo.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('48', 'KOZIUBERDA', 'Iuliia', 'Iuliia.KOZIUBERDA@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('49', 'LECLERCQ', 'Pascal', 'PASCAL.LECLERCQ@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('50', 'MARTIN', 'Gwendal', 'GWENDAL.MARTIN@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('51', 'MASALITIN', 'Vadym', 'Vadym.MASALITIN@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('52', 'MENG', 'Fanrong', 'Fanrong.MENG@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('53', 'MERCIER', 'Julien', 'Julien.MERCIER@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('54', 'MINIER', 'Josselin', 'Josselin.MINIER@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('55', 'PAYET', 'FranÃ§ois', 'FRANCOIS.PAYET@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('56', 'PERTHUIS', 'FranÃ§ois', 'Francois.PERTHUIS@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('57', 'RAULIC', 'Julien', 'julien.RAULIC@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('58', 'ROCHE', 'SÃ©bastien', 'Sebastien.ROCHE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('59', 'SAEWANG', 'Anukun', 'ANUKUN.SAEWANG@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('60', 'SALL', 'Mama', 'Mama.SALL@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('61', 'STUBI', 'Thomas', 'THOMAS.STUBI@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('62', 'VENOT', 'David', 'David.VENOT@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('63', 'VERRIER', 'Vincent', 'VINCENT.VERRIER@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('64', 'WAN', 'Lei', 'Lei.WAN@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('65', 'BELLANGER', 'Nicolas', 'NICOLAS.BELLANGER@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('66', 'BOUHENNI', 'Mohamed', 'MOHAMED.BOUHENNI@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('67', 'CARIOU', 'Florent', 'FLORENT.CARIOU@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('69', 'CHABROUX', 'MickaÃ«l', 'MICKAEL.CHABROUX@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('70', 'CHARRIER', 'Cyril', 'CYRIL.CHARRIER@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('71', 'DELAFOSSE', 'Romain', 'ROMAIN.DELAFOSSE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('72', 'DUFLOT', 'Alexis', 'ALEXIS.DUFLOT@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('73', 'DUMONT', 'Charles-benoÃ®t', 'Charles-Benoit.DUMONT@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('74', 'GERBAUD', 'ClÃ©ment', 'CLEMENT.GERBAUD@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('75', 'HOHLER', 'Geoffrey', 'GEOFFREY.HOHLER@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('76', 'HOREL', 'Marc-antoine', 'MARC-ANTOINE.HOREL@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('77', 'KHERMAZ', 'Abderahman', 'ABDERAHMAN.KHERMAZ@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('78', 'LE BERRE', 'Fabien', 'FABIEN.LE_BERRE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('79', 'LE CAROU', 'Thierry', 'THIERRY.LE_CAROU@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('80', 'PELLERIN', 'Cyril', 'CYRIL.PELLERIN@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('81', 'PERRIER', 'Vincent', 'VINCENT.PERRIER@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('82', 'PIERRES', 'Arnaud', 'ARNAUD.PIERRES@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('83', 'POCHARD', 'Olivier', 'OLIVIER.POCHARD@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('84', 'TURMEAU', 'Anthony', 'ANTHONY.TURMEAU@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('85', 'YVOZ', 'Florian', 'FLORIAN.YVOZ@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('86', 'PIEBY', 'Willy', 'Willy.PIEBY@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('87', 'KRAFY', 'Moussa', 'Moussa.KRAFY@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('298', 'FEURPRIER', 'Audrey', 'Audrey.Feurprier.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('89', 'DAUMAS', 'Antoine', 'Antoine.DAUMAS@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('90', 'TAMARELLE', 'Charly', 'Charly.TAMARELLE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('93', 'CHOUNACKI', 'Mathieu', 'Mathieu.CHOUNACKI@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('300', 'GUERET', 'Baptiste', 'Baptiste.Gueret.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('96', 'RICQ', 'Julian', 'JULIAN.RICQ@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('98', 'BEN HASSEN', 'Jonathan', 'Jonathan.BEN_HASSEN@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('99', 'RAULIC', 'Vincent', 'Vincent.RAULIC@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('100', 'RIVAL', 'Guillaume', 'Guillaume.Rival.Etu@univ-lemans.fr', 'guillaume.rival@gmail.com', '');
INSERT INTO etudiant VALUES('296', 'DUBOIS', 'JÃ©rÃ´me', 'Jerome.Dubois.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('297', 'FENOUIL', 'SANDRINE', 'Sandrine.Fenouil.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('104', 'CHANOUX', 'Vianney', 'Vianney.CHANOUX@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('105', 'DEMANGEAT', 'Guillaume', 'GUILLAUME.DEMANGEAT@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('302', 'HENRY', 'Nathan', 'Nathan.Henry.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('299', 'FROGER', 'Adrien', 'Adrien.Froger.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('108', 'GADIAGA', 'Youssoupha', '', '', '');
INSERT INTO etudiant VALUES('109', 'FRESNEAU', 'Tony', '', '', '');
INSERT INTO etudiant VALUES('110', 'BERNARD', 'Sylvain', 'sylvain.bernard@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('111', 'BESNARDEAU', 'Alan', 'alan.besnardeau@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('112', 'BOISSELEAU', 'Anthony', 'anthony.boisseleau@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('113', 'BUON', 'Tristan', 'tristan.buon@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('114', 'COME', 'Benjamin', 'benjamin.come@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('115', 'DE PIERREPONT', 'SolÃ¨ne', 'solene.de_pierrepont@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('116', 'DIOP', 'Salif', 'salif.diop@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('117', 'DUBOIS', 'Julien', 'julien.dubois@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('118', 'ELLEAUME', 'Emeric', 'emeric.elleaume@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('119', 'GAUDIN', 'Florian', 'florian.gaudin@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('120', 'GOULET', 'Benjamin', 'benjamin.goulet@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('121', 'GRECI', 'Pierre-Allan', 'pierre-allan.greci@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('122', 'LARDON', 'Benjamin', 'benjamin.lardon@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('123', 'LEMAIRE', 'BenoÃ®t', 'Benoit.LEMAIRE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('124', 'LUTTMANN', 'Geoffroy', 'Geoffroy.LUTTMANN@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('125', 'PASCAL', 'Guillaume', 'guillaume.pascal@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('126', 'PERDRIX', 'Alexandre', 'alexandre.perdrix@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('127', 'POTTIER', 'Nicolas', 'nicolas.pottier@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('128', 'RAIMBAULT', 'Denis', 'denis.raimbault@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('129', 'RAULY', 'Julien', 'julien.rauly@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('130', 'RICORDEAU', 'Alexandre', 'alexandre.ricordeau@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('131', 'SALMON', 'Yann', 'yann.salmon@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('132', 'BEN AYED', 'GHASSENE', 'Ghassene.BEN_AYED@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('134', 'CHARTIER', 'CHRISTOPHE', 'Christophe.Chartier.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('135', 'DARDE', 'FABIEN', 'FABIEN.DARDE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('136', 'DEMENTEV', 'MIKHAIL', 'Mikhail.DEMENTEV@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('137', 'HURMACI', 'UGUR', 'Hugur.HURMACI@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('138', 'KARTASHOV', 'VOLODYMYR', 'Volodymyr.KARTASHOV@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('139', 'KOSTIK', 'KATERYNA', 'Kateryna.KOSTIK@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('140', 'KOSTITCHEVA', 'IRINA', 'Irina.KOSTITCHEVA@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('141', 'LAMBERDIERE', 'KILIAN', 'KILIAN.LAMBERDIERE@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('142', 'LECHAT', 'JEREMY', 'Jeremy.LECHAT@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('143', 'LOISEAU', 'ESTEBAN', 'ESTEBAN.LOISEAU@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('144', 'MONTOIS', 'MAXENCE', '', 'maxence.montois@hotmail.fr', '');
INSERT INTO etudiant VALUES('145', 'NANPIWONG', 'DARIKA', 'DARIKA.NANPIWONG@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('146', 'NGENZI', 'DANIEL', 'Daniel.NGENZI@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('147', 'PUSHKAREV', 'OLEG', 'Oleg.PUSHKAREV@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('148', 'RANCHY', 'LUC', 'LUC.RANCHY@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('149', 'SALATA', 'SEGII', 'Segii.SALATA@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('150', 'SAGOT', 'RAÃSSA', 'RAISSA.SAGOT@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('151', 'SAMOKHATKO', 'VOLODYMYR', 'Vladimir.Samokhatko.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('295', 'DIET', 'Charles', 'Charles.Diet.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('294', 'DARDE', 'Yohan', 'Yohan.Darde.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('154', 'WANG', 'WEI', 'Wei.WANG@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('155', 'AADJOU', 'ADIL', 'Adil.AADJOU@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('156', 'ZHOU', 'Mian', 'Mian.ZHOU@info.univ-lemans.fr', 'zhou_tania@hotmail.com', '');
INSERT INTO etudiant VALUES('157', 'RAKOTOMALALA', 'Sahobindrainibe', 'Sahobindrainibe.RAKOTOMALALA@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('158', 'ALLAOUI MOHAMED', 'SAID', 'Said.Allaoui_Mohamed@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('159', 'BAROUHO', 'ABDELALI', 'Abdelali.Barouho@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('160', 'BELLANGER', 'KEVIN', 'Kevin.Bellanger@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('161', 'BRAHIM', 'GUILLAUME', 'Guillaume.Brahim@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('162', 'CALTRE', 'ANAIS', 'Anais.Caltre@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('163', 'CHAOUALI', 'CELINE', 'Celine.Chaouali@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('164', 'ELUT', 'MATHURIN', 'Mathurin.Elut@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('165', 'GUERINEAU', 'ROMAIN', 'Romain.Guerineau@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('166', 'JARRIER', 'MAXIME', 'Maxime.Jarrier@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('167', 'MARION', 'RENAN', 'Renan.Marion@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('168', 'MENAGER', 'JEREMY', 'Jeremy.Menager@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('169', 'MEUNIER', 'GUILLAUME', 'Guillaume.Meunier@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('170', 'MORAINE', 'MODESTIE', 'Modestie.Moraine@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('171', 'PIERRAT', 'JIMMY', 'Jimmy.Pierrat@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('172', 'PONGE', 'SMERALD', 'Smerald.Ponge@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('173', 'RAPP', 'JOSIA', 'Josia.Rapp@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('174', 'RIGOT', 'PIERRE-OLIVIER', 'Pierre-Olivier.RIGOT@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('175', 'TESSIER', 'ANTHONY', 'Anthony.Tessier@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('176', 'VANNIER', 'FLORIAN', 'Florian.Vannier@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('177', 'ACHTE', 'RÃ©mi', 'Remi.Achte.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('178', 'ANDRU', 'BASTIEN', 'Bastien.Andru.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('179', 'AUBRY', 'BASTIEN', 'Bastien.Aubry.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('180', 'BESNARD', 'VINCENT', 'Vincent.Besnard.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('181', 'BOUAZIZ', 'MOHAMED', 'Mohamed.Bouaziz.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('183', 'BROLINSKYI', 'SERGEII', 'Sergii.Brolinskyi.Etu@univ-lemans.fr', 'brol.sergii@gmail.com', '');
INSERT INTO etudiant VALUES('184', 'CARRE', 'GAEL', 'Gael.Carre.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('185', 'CHANROUX', 'BENJAMIN', 'Benjamin.Chanroux.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('186', 'DAUBIAS', 'ESTEBAN', 'Esteban.Daubias.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('187', 'DELORME', 'GUILLAUME', 'Guillaume.Delorme.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('188', 'DETAN', 'NICOLAS', 'Nicolas.Detan.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('189', 'DURANTEAU', 'FLORIAN', 'Florian.Duranteau.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('190', 'DUROY', 'ADRIEN', 'Adrien.Duroy.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('191', 'GENARD', 'GEOFFREY', 'Geoffrey.Genard.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('192', 'GOSSELIN', 'QUENTIN', 'Quentin.Gosselin.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('193', 'GOUY', 'FLORIAN', 'Florian.GOUY@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('194', 'GREBENKOVA', 'YULIA', 'Yulia.Grebenkova.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('195', 'HENRY', 'AXEL', 'Axel.Henry.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('287', 'BELLIER FAUVET', 'ValÃ©rie', 'Valerie.Bellier_Fauvet.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('197', 'JAMET', 'JEREMY', 'Jeremy.Jamet.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('198', 'KOS', 'CYNTHIA', 'Cynthia.Kos.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('200', 'MARTINEAU', 'PIERRE-JEAN', 'Pierre-Jean.Martineau.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('201', 'MELNYCHENKO', 'IVAN', 'Ivan.Melnychenko@info.univ-lemans.fr', '', '1');
INSERT INTO etudiant VALUES('202', 'NGENZI', 'DANIEL', 'Daniel.NGENZI@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('203', 'PARWANY', 'ZUBAIR', 'Zubair.Parwany.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('204', 'PETITHORY', 'MARC', 'Marc.Petithory.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('205', 'PROVOST', 'NICOLAS', 'Nicolas.Provost@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('259', 'GHANNAY', 'Sahar', 'Sahar.Gannay.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('207', 'TOUSE', 'FLORIAN', 'Florian.Touse.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('208', 'TROTIN', 'RONAN', 'Ronan.Trotin.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('209', 'TUMNIUM', 'NOPADOL', 'NOPADOL.TUMNIUM@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('210', 'WEN', 'JIE', 'Jie.Wen.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('211', 'VIDAMENT-BROU', 'CHAD', 'CHAD.VIDAMENT-BROU@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('212', 'KAMMOUN', 'FATMA', 'Fatma.KAMMOUN@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('303', 'IAKYMENKO', 'Artem', 'Artem.Iakymenko.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('213', 'BEN HADJ MESSAOUD', 'Hichem', 'Hichem.BEN_HADJ_MESSAOUD@info.univ-lemans.fr', 'ben.haj.messaoud.hichem@gmail.com', '');
INSERT INTO etudiant VALUES('214', 'CHAKROUN', 'Dhia', 'Dhia.Chakroun.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('215', 'DIOUF', 'Pape Babacar', 'Pape_Babacar.Diouf.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('216', 'DRIDI', 'Anas', 'Anas.Ldridi.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('217', 'GHORBEL', 'Hammadi', 'Hammadi.Ghorbel@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('218', 'HADDAD', 'Yassine', 'Yassine.Haddad.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('219', 'CHOUKET', 'Houda', 'Houda.Chouket.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('220', 'LAAMOURI', 'Tarek', 'Tarek.Laamouri.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('221', 'MERCIER', 'Julien', 'Julien.MERCIER@info.univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('223', 'BEGUIN', 'Julien', 'Julien.Beguin.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('224', 'BOUCHERIE', 'Elie', 'Elie.Boucherie.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('225', 'BUFFET', 'Hugo', 'Hugo.Buffet.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('226', 'BULANENKO', 'Roman', 'Roman.Bulanenko.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('227', 'CHINOT', 'Gaulthier', 'Gaulthier.Chinot.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('228', 'COURCIER', 'Fabrice', 'Fabrice.Courcier.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('229', 'EL MOUSTAPHA SALIHY', 'Abdellahi', 'Abdellahi.El-Moustapha_Salihy.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('230', 'FORTINEAU', 'Jimmy', 'Jimmy.Fortineau.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('232', 'GOUMBALLA', 'Aida', 'Aida.Goumballa.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('233', 'GUEI', 'Kamonda', 'Kamonda.Guei.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('234', 'GUO', 'Zhenxing', 'Zhenxing.Guo.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('235', 'HENRY', 'Felix', 'Felix.Henry.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('236', 'JARDIN', 'JÃ©rÃ©my', 'Jeremy.Jardin.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('237', 'KOKHANEVYCH', 'Igor', 'Igor.Kokhanevych.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('238', 'KOTOVA', 'Yuliia', 'Yuliia.Kotova.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('239', 'LEBRUN', 'JÃ©rÃ©my', 'Jeremy.Lebrun.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('240', 'LEGAY', 'Jordan', 'Jordan.Legay.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('245', 'OULD BOUKHARY', 'Sidi Mohamed', 'Sidi_Mohamed.Ould_Boukhary.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('242', 'LYTVYNOV', 'Anton', 'Anton.Lytvynov.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('244', 'OUATTARA', 'Florent', 'Florent.Ouattara.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('247', 'POUA SALLEY', 'Karl', 'Karl.Poua_Salley.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('248', 'SAIEVYCH', 'Kseniia', 'Kseniia.Saievych.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('249', 'VIDAMENT-BROU', 'Adley', 'Adley.Vidament-Brou.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('250', 'ZHANG', 'Shuo', 'Shuo.Zhang.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('251', 'POLISHCHUK', 'Oleg', 'Oleh.Polishchuk.Etu@univ-lemans.fr', 'Oleg.Polischuk.Etu@univ-lemans.fr', '5');
INSERT INTO etudiant VALUES('252', 'MINIAILO', 'Artem', 'Artem.Miniailo.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('253', 'BAH', 'Mamadou', 'Mamadou.Bah.Etu@univ-lemans.fr', '', '1');
INSERT INTO etudiant VALUES('254', 'CHUBYNSKYI', 'Viacheslav', 'Viacheslav.Chubynskyi.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('255', 'MAATAR', 'Nadia Sofia', 'Nadia_Sofia.Maatar.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('256', 'RAEISI', 'Soudeh', 'Soudeh.Raeisi.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('260', 'ANDRE', 'Benjamin', 'Benjamin_Andre.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('261', 'BERTHIOT', 'Alexandre', 'Alexandre.Berthiot.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('262', 'CAMUS', 'Pierre-Louis', 'Pierre-Louis.Camus.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('263', 'DELAUNAY', 'Thomas', 'Thomas.Delaunay.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('264', 'LETESSIER', 'Romain', 'Romain.Letessier.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('265', 'OZAN', 'AurÃ©lien', 'Aurelien.Ozan.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('266', 'ROULLIER', 'RÃ©mi', 'Remi.Roullier.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('267', 'VAIRAA', 'Nicolas', 'Nicolas.Vairaa.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('268', 'VALLET', 'Christopher', 'Christopher.Vallet.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('269', 'POUPIN', 'Kevin', 'Kevin.Poupin.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('270', 'LEGOUET', 'MickaÃ«l', 'Mickael.Legouet.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('271', 'ARCHER', 'Fabien', 'Fabien.Archer.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('272', 'AYDIN', 'Ulgen', 'Ulgen.Aydin.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('273', 'BACARI ABDELLAH', 'Nadjma', 'Nadjma.Bacari_Abdallah.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('274', 'BODARD', 'Alexandre', 'Alexandre.Bodard.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('275', 'BUSSON', 'KÃ©vin', 'Kevin_Busson.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('276', 'CHEVEREAU', 'Eddy', 'Eddy.Chevereau.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('277', 'COLLET', 'Adriano', 'Adriano.Collet.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('278', 'DESBORDES', 'Romain', 'Romain.Desbordes.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('279', 'PAPIN', 'Alexandre', 'Alexandre.Papin.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('280', 'PET', 'JÃ©rÃ©mie', 'Jeremie.Pet.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('281', 'RAMOLET', 'Arthur', 'Arthur.Ramolet.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('282', 'ROBIN', 'MÃ©dÃ©ric', 'Mederic.Robin.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('283', 'GHORBEL', 'Afef', 'Afef.Ghorbel.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('284', 'AOUADNI', 'Wadhah', 'Wadhah.Aouadni.Etu@univ-lemans.fr', '', '');
INSERT INTO etudiant VALUES('285', 'ABOUAF', 'Nicolas', 'Nicolas.Abouaf.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('288', 'BLUM PHU NYIN', 'Ayit', 'Phu_Nyin_Ayit.Blum.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('289', 'BOSSART', 'Florent', 'Florent.Bossart.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('290', 'BROUX', 'Pierre-Alexandre', 'Pierre-Alexandre.Broux.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('291', 'CARPENTIER', 'Alexis', 'Alexis.Carpentier.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('292', 'CHARLES', 'Simon', 'Simon.Charles.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('304', 'KLYMENKO', 'Mykyta', 'Mykyta.Klymenko.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('305', 'MARTEAU', 'Morgane', 'Morgane.Marteau.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('306', 'OBERTYSHEVA', 'Polina', 'Polina.Obertysheva.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('307', 'PARME', 'Thibault', 'Thibault.Parme.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('309', 'RIABYKINA', 'VIKTORIIA', 'Viktoriia.Riabykina.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('310', 'ROUCOUX', 'Ludovic', 'Ludovic.Roucoux.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('311', 'SIMONNET', 'EDWIN', 'Edwin.Simonnet.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('312', 'STENZHORN', 'Julien', 'Julien.Stenzhorn.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('313', 'VAKHRINA', 'VIKTORIIA', 'Viktoriia.Vakhrina.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('314', 'VESSEREAU', 'YANNIS', 'Yannis.Vessereau.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('315', 'VIRLOUVET', 'Xavier', 'Xavier.Virlouvet.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('316', 'VOISIN', 'JÃ©rÃ©my', 'Jeremy_Voisin.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('317', 'SOUAI', 'Rihab', 'Rihab.Souai.Etu@univ-lemans.fr', '', '1');
INSERT INTO etudiant VALUES('318', 'BEN ABDALLAH', 'Amna', 'Amna.Ben_Abdallah.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('319', 'CLEMENT', 'NoÃªl', 'Clement.Noel.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('320', 'AYDIN', 'Emre', 'Emre.Aydin.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('321', 'BARDET', 'Adrien', 'Adrien..bardet.Etu@univ-lemans.fr', '', '6');
INSERT INTO etudiant VALUES('322', 'BERRABAH', 'Mohammed', 'Mohammed.Berrabah.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('323', 'BIALETTI', 'Olivier', 'Olivier.Bialetti.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('324', 'CROUILLERE', 'Kevin', 'Kevin.Crouillere.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('325', 'DESNOUS', 'Florent', 'Florent.Desnous.Etu@univ-lemans.fr', '', '6');
INSERT INTO etudiant VALUES('326', 'GIROD', 'Quentin', 'Quentin.Girod.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('327', 'GOMES', 'Alexandre', 'Alexandre.Pais_Gomes.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('328', 'KHOROLICH', 'Yulianna', 'Yulianna.Khorolich.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('329', 'KULISHEV', 'Maksym', 'Maksym.Kulishev.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('330', 'LANVIN', 'Elyan', 'Elyan.Lanvin.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('331', 'LE PEN', 'Amandine', 'Amandine.le_Pen.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('332', 'LEDRU', 'Julien', 'Julien.Ledru.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('333', 'LEVY', 'AdÃ©lice', 'Adelice.Levy.Etu@univ-lemans.fr', '', '6');
INSERT INTO etudiant VALUES('334', 'LOUVEL', 'CÃ©dric', 'Cedric.Louvel.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('335', 'MARCAIS', 'Thomas', 'Thomas.Marcais.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('336', 'MICHAUD', 'JÃ©rÃ´me', 'Jerome.Michaud.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('337', 'PARWANY', 'Jaweed', 'Jaweed.Parwany.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('338', 'DAOUMI', 'Jalil', 'Jalil.Daoumi.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('339', 'ZALMAD', 'Soufiane', 'Soufiane.Zalmad.Etu@univ-lemans.fr', '', '1');
INSERT INTO etudiant VALUES('340', 'GAHAGNON', 'Thibaud', 'Thibaud.Gahagnon.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('341', 'NOEL', 'ClÃ©ment', 'Clement.Noel.Etu@univ-lemans.fr', '', '2');
INSERT INTO etudiant VALUES('343', 'ABDALLAH ABANE', 'Abdoulfatah', 'Abdoulfatah.Abdallah_Abame.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('344', 'EBOUELE', 'Christian', 'Come_Amana.Ebouele_Amana.Etu@univ-lemans.fr', '', '1');
INSERT INTO etudiant VALUES('345', 'ARMANGER', 'Philippe', 'Philippe.Armanger.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('346', 'BRIAND', 'Thomas', 'Thomas.Briand.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('347', 'CARTIER', 'Pierre', 'Pierre.Cartier.Etu@univ-lemans.fr', '', '4');
INSERT INTO etudiant VALUES('348', 'CAUBRIÃ¨RE', 'Antoine', 'Antoine.Caubriere.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('349', 'DELORME', 'Corentin', 'Corentin.Delorme.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('350', 'DIDIER', 'Mathias', 'Mathias.Didier.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('351', 'GUENVER', 'LoÃ¯c', 'Loic.Guenver.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('352', 'GUERRIER', 'Julien', 'Julien.Guerrier.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('353', 'HACHICHA', 'Wiem', 'Wiem.Hachicha.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('354', 'KORESTSKYI', 'Borys', 'Borys.Koretskyi.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('355', 'KRYLOVA', 'Tatiana', 'Tetiana.Krylova.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('356', 'KUANG', 'Nanzhen', 'Nanzhen.Kuang.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('357', 'LELIUKHIN', 'Yevhen', 'Yevhen.Leliukhin.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('358', 'LETAY', 'BenoÃ®t', 'Benoit.Letay.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('359', 'LIAHUSHYN', 'Pavlo', 'Pavlo.Liahushyn.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('360', 'LOIZEAU', 'Sylvain', 'Sylvain.Loizeau.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('361', 'OFFREDI', 'Etienne', 'Etienne.Offredi.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('362', 'PINEL', 'Manon', 'Manon.Pinel.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('363', 'POIRIER', 'Godefroy', 'Godefroy.Poirier.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('364', 'SAVARRE', 'Amaury', 'Amaury.Savarre.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('365', 'SEVOSTIANOVA', 'Halyna', 'Halyna.Sevostianova.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('366', 'WEI', 'Tianqi', 'Tianqi.Wei.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('367', 'XU', 'Pengfei', 'Pengfei.Xu.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('368', 'YZEUX', 'Ronan', 'Ronan.Yzeux.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('369', 'EBOUELE', 'CÃ´me Christian', 'Come_Amana.Ebouele_Amana.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('370', 'AVENEIN', 'Vincent', 'Vincent.Avenein.Etu@univ-lemans.fr', '', '3');
INSERT INTO etudiant VALUES('371', 'AROUS', 'Olfa', 'Olfa.Arous.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('372', 'KEBE', 'Mamadou', 'Mamadou.Kebe.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('373', 'MACARY', 'Francisque', 'Francisque.Macary.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('374', 'TRIGUI', 'Sirine', 'Sirine.Trigui.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('375', 'MAHAMAT', 'Annour Mahamat', 'Annour_Mahamat.Mahamat.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('376', 'DIOUF', 'Mamadou', 'Mamadou.Diouf.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('377', 'KACEM', 'Rim', 'Rim.Kacem.Etu@univ-lemans.fr', '', '3');
INSERT INTO etudiant VALUES('378', 'MAHDI', 'Oussema', 'Oussema.Mahdi.Etu@univ-lemans.fr', '', '0');
INSERT INTO etudiant VALUES('379', 'BOURMAYER', 'Vincent', 'Vincent.Bourgmayer.Etu@univ-lemans.fr', '', '5');
INSERT INTO etudiant VALUES('380', 'BATHAHI', 'Ilyass', 'Ilyass.Bathahi.Etu@univ-lemans.fr', '', '0');

-- -----------------------------
-- insertions dans la table filiere
-- -----------------------------
INSERT INTO filiere VALUES('1', 'Master2', '50', '1');
INSERT INTO filiere VALUES('2', 'Licence L3', '20', '1');
INSERT INTO filiere VALUES('3', 'Licence L3P', '30', '0');
INSERT INTO filiere VALUES('4', 'Master1', '30', '1');
INSERT INTO filiere VALUES('5', 'Deust2', '20', '0');

-- -----------------------------
-- insertions dans la table fluxrss
-- -----------------------------
INSERT INTO fluxrss VALUES('1', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=351', '1442993351', 'E LEARNING', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('2', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=353', '1442993595', 'DÃ©veloppeur Web full-stack', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('3', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=354', '1443428213', 'Offres Sopra-Steria', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('4', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=354', '1443428809', 'Offres Sopra-Steria', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('5', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=355', '1444725548', 'Offres Groupe Excilys', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('6', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=356', '1444835449', 'Offres CGI', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('7', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=357', '1444836882', 'Stage en dÃ©veloppement d&#039;applications web', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('8', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=358', '1445335412', 'Offres Umanis (Centre de Tours)', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('9', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=359', '1445594739', 'DÃ©veloppeur Web spÃ©cialisÃ©(e) dans le Front-End', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('10', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=362', '1447088174', 'Offres VINCI Energies SI', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('11', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=363', '1447146527', 'DÃ©veloppement sur plateformes mobiles', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('12', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=364', '1447318688', 'DÃ©veloppeur Delphi 2D 3D', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('13', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=365', '1447335171', 'Offres Polymont', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('14', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=366', '1447338680', 'Offre Orange Logic', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('15', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=367', '1447774939', 'Offre APSIDE', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('16', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=368', '1447776574', 'Offres eBusinessInformation', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('17', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=369', '1447777752', 'Offres Biocoop', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('18', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=370', '1448618700', 'DÃ©veloppement Web Java au Mans', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('19', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=371', '1449678235', 'Plateforme sociale, mobile et ludique de ressources multime&amp;#769;dias : Extraction et visualisation de donne&amp;#769;es dâu', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('20', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=374', '1451907567', 'Modification d&#039;applications existantes', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('21', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=372', '1451907728', 'AmÃ©lioration et Ã©volution plateforme SaaS', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('22', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=373', '1451908191', 'Application de videomapping en 3D temps-rÃ©el', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('23', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=375', '1452599301', 'IntÃ©gration &quot;Microsoft test manager&quot; avec l&#039;environnement de dÃ©veloppement client/serveur Java', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');
INSERT INTO fluxrss VALUES('24', 'Nouvelle offre de stage', 'http://info-stages.univ-lemans.fr//stagiaire/visualiserOffre.php?id=376', '1453887509', 'Offres GIE SESAM-VITALE', 'thierry.lemeunier@univ-lemans.fr (Thierry Lemeunier)');

-- -----------------------------
-- insertions dans la table offredestage
-- -----------------------------
INSERT INTO offredestage VALUES('358', '<br/>
L\'entreprise Umanis est une entreprise partenaire du Master ISI. Depuis plusieurs annÃ©es, elle recrute de nouveaux collaborateurs Ã  l\'issue des stages de M2.<br/>
Le livret Ã  destination des futures recrues est <a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Umanis_Livret.pdf\'>accessible ici</a> 
<br/>
Voici des annonces de stage Web et BI pour lâannÃ©e 2015-2016.<br/>
Celles-ci sont valables pour Tours sans date de dÃ©marrage ni durÃ©e imposÃ©e.<br/>
Elles concernent des stages de fin dâÃ©tudes en prÃ©-embauche mais sont Ã©galement adaptables Ã  des promotions infÃ©rieures.<br/>
<ul>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Umanis_01.pdf\'>IngÃ©nieur d\'Ã©tude dÃ©cisionnel (sujet 1)</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Umanis_02.pdf\'>IngÃ©nieur d\'Ã©tude dÃ©cisionnel (sujet 2)</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Umanis_03.pdf\'>IngÃ©nieur d\'Ã©tude dÃ©cisionnel (sujet 3)</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Umanis_04.pdf\'>IngÃ©nieur d\'Ã©tude dÃ©cisionnel (sujet 4)</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Umanis_05.pdf\'>IngÃ©nieur d\'Ã©tude dÃ©cisionnel (sujet 5)</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Umanis_06.pdf\'>Inge&#769;nieur dâe&#769;tudes Sharepoint</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Umanis_07.pdf\'>Inge&#769;nieur dâe&#769;tudes Web</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Umanis_08.pdf\'>Inge&#769;nieur dâe&#769;tudes Java/JEE</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Umanis_09.pdf\'>Inge&#769;nieur dâe&#769;tudes Business Intelligence</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Umanis_10.pdf\'>Inge&#769;nieur dâe&#769;tudes Web et Business Intelligence</a></li>
</ul>
Toutes les annonces sont disponibles sur le site de recrutement de la sociÃ©tÃ© : <a href=\'http://annonces.umanis.com/\'>http://annonces.umanis.com/</a>
', 'Offres Umanis (Centre de Tours)', '', '3', '6', '0', '', '1', '683');
INSERT INTO offredestage VALUES('359', '<br/>
Dans le cadre de ses activite&#769;s digitales autour de nouvelles technologies, SWORD a de&#769;cide&#769; de lancer le de&#769;veloppement dâune application e&#769;volutive web et mobile user friendly, a&#768; destination de composants logiciels et de services cloud existants.<br/>
<br/>
L\'offre est <a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Sword.pdf\'>accessible ici</a>.<br/>
<br/>
Contactez Samuel Sarrazin.<br/>', 'DÃ©veloppeur Web spÃ©cialisÃ©(e) dans le Front-End', '', '3', '6', '0', '', '1', '685');
INSERT INTO offredestage VALUES('360', '<br/>
BenoÃ®t LAURANT (Responsable Recrutement Ouest) propose pour la sociÃ©tÃ© Infotel plusieurs offres de stages.<br/>
<br/>
<ul>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Infotel_01.pdf\'>Etude et dÃ©veloppement de modules pour GLPI</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Infotel_02.pdf\'>Outil de facturation</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Infotel_03.pdf\'>Evolution du logiciel SPOT</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Infotel_04.pdf\'>Migration dâune application dâavant-vente</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Infotel_05.pdf\'>CrÃ©ation d\'un logiciel de gestion d\'une CVThÃ¨que</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Infotel_06.pdf\'>CrÃ©ation dâun logiciel de suivi statistique Avant-vente</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Infotel_07.pdf\'>RÃ©fÃ©rentiel Personne</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Infotel_08.pdf\'>Gestion des compÃ©tences</a></li>
</ul>', 'Offres Infotel', '', '6', '6', '0', '', '1', '686');
INSERT INTO offredestage VALUES('362', '<br/>
FrÃ©dÃ©rique PULTZ (responsable de missions RH) propose 3 offres de stages de la sociÃ©tÃ© VINCI Energies SI.<br/>
<br/>
<ul>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/VESI_1.pdf\'>Analyste dÃ©veloppeur Java</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/VESI_2.pdf\'>Analyste dÃ©veloppeur .Net SharePoint</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/VESI_3.pdf\'>Analyste fonctionnel SI junior Business Intelligence</a></li>
</ul>
', 'Offres VINCI Energies SI', '', '4', '6', '0', '', '1', '688');
INSERT INTO offredestage VALUES('363', '<br/>
La sociÃ©tÃ© 2LA Games Studio basÃ©e au Mans recherche un stagiaire (si possible de M2) dans le domaine du dÃ©veloppement sur plateformes mobiles.<br/>
<br/>
L\'offre est accessible <a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/2LA.pdf\'>ici</a>.<br/>
<br/>
Cette sociÃ©tÃ© a dÃ©jÃ  pris un stagiaire l\'annÃ©e passÃ©e.<br/>
', 'DÃ©veloppement sur plateformes mobiles', '', '4', '6', '0', '', '1', '656');
INSERT INTO offredestage VALUES('364', '<br/>
Sabrina Duval (consultante RH chez PRO AVANCIA) cherche pour un Ã©diteur de logiciels un stagiaire en dÃ©veloppement informatique en Delphi 2D 3D.<br/>
<br/>
L\'offre est accessible <a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/ProAvancia.pdf\'>ici.</a><br/>
<br/>', 'DÃ©veloppeur Delphi 2D 3D', '', '3', '6', '0', '', '1', '689');
INSERT INTO offredestage VALUES('365', '<br/>
L\'entreprise Polymont (anciennement Novia Systems) est partenaire du Master ISI.<br/>
<br/>
Chaque annÃ©e diffÃ©rents stages de prÃ©-embauches sont proposÃ©s (2 stages et 2 CDI en 2015).<br/>
<ul>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Polymont_1.pdf\'>Planning dâenque&#770;tes</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Polymont_2.pdf\'>Outillage dâindustrialisation</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Polymont_3.pdf\'>Applications backoffice (gestion des cre&#769;dits, gestion des risques, ...)</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Polymont_4.pdf\'>Portails grand public, Syste&#768;me dâannuaire et dâauthentification</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Polymont_5.pdf\'>Application de gestion interne</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Polymont_6.pdf\'>PMO ope&#769;rationnel / Gestionnaire de lâoutil de suivi  ProjeQtOr</a></li>
<ul/>', 'Offres Polymont', '', '6', '6', '0', '', '1', '690');
INSERT INTO offredestage VALUES('366', '<br/>
L\'entreprise ORANGE LOGIC EUROPE (<a href=\'http://www.orangelogic.com\'>www.orangelogic.com</a>) basÃ©e Ã  Montpellier (sud de la France) a recrutÃ© un ancien Ã©tudiant ukrainien de l\'UniversitÃ© du Maine (Ã©tudiant originaire de l\'UniversitÃ© nationale de Dnipropetrovsk-DNU) qui Ã©tait inscrit en Master ISI.<br/>
<br/>
L\'entreprise souhaite pouvoir recruter des Ã©tudiants ou diplÃ´mÃ©s internationaux ayant le mÃªme type de profil.
<br/>
Cette offre (<a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Orange_Logic.pdf\'>accessible ici</a>) s\'adresse donc exclusivement aux Ã©tudiants ukrainiens.<br/>
<br/>', 'Offre Orange Logic', '', '3', '6', '0', '', '1', '691');
INSERT INTO offredestage VALUES('367', '<br/>
La sociÃ©tÃ© APSIDE est partenaire du Master ISI. Elle propose chaque annÃ©e des offres de stages et des propositions de CDI. En 2015, elle a recrutÃ© un Ã©tudiant qui avait fait le M2 en alternance.
<br/>
<br/>
Vous pouvez <a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/APSIDE.pdf\'>consultez l\'offre ici</a>.<br/>
<br/>
N\'hÃ©sitez pas Ã  contacter Valentin BONNEAU que vous avez vu lors de la confÃ©rence du lundi 16 novembre.<br/>
<br/>', 'Offre APSIDE', '', '6', '6', '0', '', '1', '692');
INSERT INTO offredestage VALUES('368', '<br/>
Voici les offres de stage destinÃ©s aux Ã©tudiants de derniÃ¨re annÃ©e de la sociÃ©tÃ© eBusinessInformation du groupe Excilys.<br/>
<br/>
- Tous nos stages sont dans une optique d\'embauche.<br/>
- Chaque stagiaire reÃ§oit une formation de 4 Ã  8 semaines sur l\'environnement JEE, dÃ¨s le dÃ©but de son stage.<br/>
- Puis il intÃ¨gre un projet et sera encadrÃ© par des experts.<br/>
- De plus, nous proposons un hÃ©bergement pendant toute la durÃ©e de leur stage (prioritÃ© aux personnes venant de province et selon les places disponibles), et une indemnitÃ© de stage de 1000 euros brut par mois.<br/>
<br/>
Tous ces Ã©lÃ©ments sont rappelÃ©s dans les offres de stages.<br/>
Les Ã©tudiants peuvent bien sÃ»r contacter Antoine YamÃ©ogo s\'ils souhaitent avoir plus de dÃ©tails sur nos offres de stage.<br/>
<br/>
<ul>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/eBiz_1.pdf\'>CAPICO Kids : Android, iPad</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/eBiz_2.pdf\'></a>CAPICO HTML5, CSS3, AngularJS, Cordova</li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/eBiz_3.pdf\'></a>DesignMyApp, HTML5, CSS3, AngularJS, Android, iOS, Cordova</li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/eBiz_4.pdf\'></a>Gatling â Stress Tool</li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/eBiz_5.pdf\'></a>Serious Game Smartphone et Tablette</li>
<ul>', 'Offres eBusinessInformation', '', '6', '6', '0', '', '1', '680');
INSERT INTO offredestage VALUES('369', '<br/>
La sociÃ©tÃ© Biocoop nous propose des stages depuis plusieurs annÃ©es. En 2015 un Ã©tudiant de M1 a fait son stage chez Biocoop.<br/>
Fabrice Belloir, qui propose ces offres, est d\'ailleurs un ancien Ã©tudiant du Master.<br/>
<br/>
<ul>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Biocoop_1.pdf\'>Sauvegarde Syste&#768;me Linux et Archivage de donne&#769;es</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Biocoop_2.pdf\'>Outils Web Automatisation du circuit de MEP Partie B Se&#769;quenceur PowerShell</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Biocoop_3.pdf\'>Outils Web Automatisation du circuit de MEP Partie A</a></li>
</ul>', 'Offres Biocoop', '', '3', '3', '0', '', '1', '617');
INSERT INTO offredestage VALUES('370', '<br/>
<a href=\'http://www.akelio.fr\'>Akelio</a> est une entreprise basÃ©e au Mans Ã©ditrice d\'une plateforme collaborative en ligne Acollab (<a href=\'http://www.acollab.fr\'>www.acollab.fr</a>), et travaille sur la rÃ©alisation de dÃ©veloppement de plateforme web et mobile sur mesure pour ses clients.<br/>
<br/>
Nous recherchons un ou deux stagiaires, en prioritÃ© de fin de cursus, pour 2016.
Les stagiaires travaillerons principalement sur notre plateforme collaborative Acollab, sur l\'amÃ©lioration et le dÃ©veloppement de nouveaux modules, eventuellement sur les applications mobiles (iPhone et Android) de Acollab.<br/>
<br/>
Ils pourront Ã©galement travailler sur le dÃ©veloppement d\'une application de synchronisation de fichiers entre les applications mobiles, l\'application Web ainsi qu\'Ã©ventuellement une application Windows.<br/>
<br/>
Les stagiaires peuvent Ã©galement Ãªtre amenÃ©s Ã  travailler sur des projets Web ou Mobile sur mesure pour nos clients.<br/>
<br/>
L\'environnement technique sur la plateforme Web est : Java, Spring, JSF, Web Services, HTML, CSS, Javascript, MySQL, Eclipse, Git.<br/>
DÃ©veloppement iPhone sur Swift<br/>
DÃ©veloppement Android sur Java<br/>
DÃ©veloppement Windows, technologie Ã  dÃ©finir<br/>
<br/>
Nous ne sommes que 2 dÃ©veloppeurs au sein d\'Akelio, donc un environnement oÃ¹ vous serez au contact quotidien des encadrants et vous serez force de proposition.
<br/>', 'DÃ©veloppement Web Java au Mans', '', '4', '6', '0', '', '1', '351');
INSERT INTO offredestage VALUES('371', '<br/>
Les appareils nomades (smartphones & tablettes) deviennent omnipre&#769;sents. Ils re&#769;volutionnent tous les secteurs et modifient en profondeur les usages. Nul doute quâils vont sâintroduire dans lâenseignement supe&#769;rieur. Le Centre d\'Appui aux Pratiques d\'Enseignement (CAPE) de l\'Ecole des Mines de Nantes explore les potentialite&#769;s de ces appareils et les nouveaux usages. Il me&#768;ne depuis 2008 des expe&#769;rimentations dâapplications de ces appareils dans lâenseignement et de&#769;veloppe des dispositifs tre&#768;s innovants. Par exemple, lâapplication Â« Parlez-vous chinois ? Â» sur mobile sâest diffuse&#769;e a&#768; plusieurs dizaines de milliers dâexemplaires a&#768; travers plus de 50 pays. En octobre 2013, le CAPE a sorti PairForm, la premie&#768;re plateforme sociale, mobile et ludique de ressources multime&#769;dias sur iPhone, iPad, Android et Web. Cette plateforme relie tous les utilisateurs dâune me&#770;me ressource et permet un e&#769;change de connaissances et un partage de savoir-faire a&#768; lâinte&#769;rieur me&#770;me du document. PairForm est en production et disponible en ligne (<a href=\'http://www.pairform.fr\'>http://www.pairform.fr</a>). Elle est utilise&#769;e par une vingtaine dâe&#769;tablissements (Universite&#769;, Grande Ecole, entreprise, collectivite&#769; territoriale). Les usages sont varie&#769;s : formation initiale, formation continue professionnelle, de&#769;mocratie participative, ... Le stage que nous proposons cette anne&#769;e se place dans le contexte de lâanalyse des usages de PairForm a&#768; partir des donne&#769;es engendre&#769;es par lâactivite&#769; du re&#769;seau social (big data).
<br/>
<br/>
L\'offre est <a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/Mines.pdf\'>accessible ici</a>.
<br/>
', 'Plateforme sociale, mobile et ludique de ressources multime&#769;dias : Extraction et visualisation de donne&#769;es dâu', '', '4', '6', '0', '', '1', '20');
INSERT INTO offredestage VALUES('372', '<br/>
BasÃ© sur le framework agile Grails, ScopSoftwareSuite est une application multi-client, multi-application en mode Saas.
Nous cherchons Ã  intÃ©grer un stagiaire sÃ©rieux et dynamique dans notre Ã©quipe dÃ©veloppement afin de faire Ã©voluer notre solution.<br/>', 'AmÃ©lioration et Ã©volution plateforme SaaS', 'win;', '3', '6', '0', '', '1', '704');
INSERT INTO offredestage VALUES('373', 'MOTS VIDEO ---> <a href=\'http://millumin.com/jobs\'>millumin.com/jobs</a><br/>
<br/>
REFERENCE : Stage.FAU7<br/>
NIVEAU : BAC+5 en fin dâÃ©tudes (perspective dâembauche)<br/>
SECTEUR : informatique appliquÃ©e aux mÃ©tiers du spectacle vivant<br/>
<br/>
LâENTREPRISE<br/>
Anomes SARL est un Ã©diteur de logiciel spÃ©cialisÃ© dans le spectacle vivant (thÃ©Ã¢tre, danse, Ã©vÃ©nementiel et musÃ©es).&#8232;Son produit phare, Millumin, est commercialisÃ© dans le monde entier, et compte de prestigieuses rÃ©fÃ©rences comme la ComÃ©die-FranÃ§aise ou le ThÃ©Ã¢tre National de Chaillot.<br/>
Nous collaborons aussi avec des artistes comme la compagnie Adrien M / Claire B (<a href=\'https://www.vimeo.com/amcb/air\'>https://www.vimeo.com/amcb/air</a>).<br/>
<br/>
LE PROJET<br/>
Il sâagit de recherche et dÃ©veloppement, axÃ©s sur le crÃ©ation de contenu graphique/vidÃ©o pour le spectacle vivant, et sur lequel les acteurs ou lâaudience pourront interagir.<br/>
Veuillez nous contacter pour obtenir plus dâinformations.<br/>
<br/>
METHODOLOGIES & TECHNOLOGIES<br/>
Use-cases, prototypes papiers, et rÃ©unions de conception en Ã©quipe.<br/>
OpenGL/WebGL/OpenCV pour le dÃ©veloppement.<br/>
Fonctionnement par itÃ©rations (mÃ©thodes agiles), avec planification et estimation rÃ©guliÃ¨re des tÃ¢ches. Point quotidien sur lâavancement du projet. DÃ©mo en fin dâitÃ©ration.<br/>
<br/>
VOUS & NOUS<br/>
Nous cherchons une personne atypique et crÃ©ative. Ayant une sensibilitÃ© artistique. FamiliÃ¨re avec la programmation graphique, et les technologies des jeux vidÃ©os.&#8232;Nous vous formerons aux bonnes pratiques de dÃ©veloppement et au travail en Ã©quipe. Vous serez confrontÃ© Ã  de nouvelles technologies, Ã  des challenges de R&D.<br/>
Nous vous accueillerons dans des bureaux conviviaux, partagÃ©s avec des photographes, designers, graphistes, vidÃ©astes. Et mÃªme des plantes.<br/>
<br/>
Les candidats avec une mauvaise orthographe sont acceptÃ©s. Ils auront la chance de progresser.<br/>
<br/>
LIEU : Paris 2Ã¨me arrondissement<br/>
DATE & DUREE : le stage dÃ©butera entre fÃ©vrier et avril 2016 pour une durÃ©e de 6 mois<br/>
REMUNERATION : 1200â¬ brut par mois, avec perspective dâembauche<br/>
CONTACT : Philippe Chaurand  /  contact@anomes.com<br/>', 'Application de videomapping en 3D temps-rÃ©el', 'mac;', '3', '6', '1200', '', '1', '705');
INSERT INTO offredestage VALUES('374', '<br/>
Applications dÃ©veloppÃ©es en PHP ; BDD MYSQL<br/>
<br/>
Analyser le cahier des charges fourni et les applications 
faire le cahier des charges  , la maquette , le planing , le dÃ©veloppement , les tests<br/>
<br/>
Le stagiaire travaillera en relation directe avec les utilisateurs <br/>', 'Modification d\'applications existantes', 'win;', '2', '3', '0', 'Le stagiaire devra faire preuve <br/>
- d\'autonomie <br/>
- d\'initiative<br/>
Il sera Ã  l\'Ã©coute des professionnels utilisateurs afin de leur livrer des solutions Ã  leur convenance<br/>
Il devra rechercher des solutions simples Ã  utiliser<br/>
Il recherchera des solutions ergonomiques<br/>', '1', '706');
INSERT INTO offredestage VALUES('376', '<br/>
Entreprise de maÃ®trise dâÅuvre de 200 collaborateurs, le GIE SESAM-Vitale est au cÅur des Ã©changes Ã©lectroniques sÃ©curisÃ©s entre les Professionnels de SantÃ© et lâAssurance Maladie. Lâinfrastructure mutualisÃ©e SESAM-Vitale gÃ¨re aujourdâhui plus dâun milliard de transactions par an en relation avec plus de 300 000 Professionnels de SantÃ©.<br/>
<br/>
Les offres de de stages sont les suivantes :
<ul>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/SESAM_VITALE_02.pdf\'>Pilote de projets informatiques</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/SESAM_VITALE_03.pdf\'>Etude de la technologie ELK</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/SESAM_VITALE_04.pdf\'>Modification d\'une application Web J2EE</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/SESAM_VITALE_05.pdf\'>Veille technologique Data Mining</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/SESAM_VITALE_06.pdf\'>Mise en place d\'un IDE et d\'un outil de tests unitaires sous Linux</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/SESAM_VITALE_07.pdf\'>Mise en oeuvre de l\'outil Webstorm de Jetbrains</a></li>
</ul>', 'Offres GIE SESAM-VITALE', '', '3', '6', '0', '', '1', '713');
INSERT INTO offredestage VALUES('351', 'CrÃ©ation d\'un site d\'E LEARNING pour une sociÃ©tÃ© de formation ', 'E LEARNING', 'win;', '1', '12', '0', 'URGENT CONTACTER STEPHANE RAMON ', '1', '675');
INSERT INTO offredestage VALUES('357', '<br/>
Nous recherchons un stagiaire en de&#769;veloppement dâapplications web pour
notre startup Sarthoise en plein essor.<br/>
<br/>
<a href=\'http://www.myassoc.org/\'>MYASSOC</a> de&#769;veloppe une plateforme en ligne de gestion dâassociations et de clubs service.<br/>
<br/>
Sur une base PHP (Ide&#769;alement CAKEPHP 2.x), vous avez une certaine expe&#769;rience personnelle dans l\'utilisation de CSS / jQuery / BOOTSTRAP. La connaissance du fonctionnement du monde associatif est un plus.<br/>
<br/>
L\'offre complÃ¨te accessible <a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/MyAssoc.pdf\'>ici</a>.<br/>
La brochure de MYASSOC <a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/MyAssoc_brochure.pdf\'>accessible ici</a>.', 'Stage en dÃ©veloppement d\'applications web', '', '3', '6', '0', '', '1', '682');
INSERT INTO offredestage VALUES('353', '<br/>
&#65532;Talentroc Solutions est une startup nantaise qui facilite la gestion des compe&#769;tences en &#65532;entreprise.<br/>
<br/>
&#65532;Nous avons de&#769;veloppe&#769; une plateforme collaborative qui repose sur une technologie mind-map &#65532;tre&#768;s intuitive. Chaque collaborateur peut y cartographier ses compe&#769;tences en quelques minutes &#65532;et quelques clics, sâautoe&#769;valuer et recevoir des e&#769;valuations par les pairs.<br/>
<br/>
&#65532;Gra&#770;ce a&#768; notre outil, les managers ont toutes les cle&#769;s en main pour optimiser la gestion des &#65532;compe&#769;tences au niveau individuel et collectif. Les collaborateurs ont eux la possibilite&#769; de se &#65532;mettre en relation les uns avec les autres dans une logique de partage de savoirs.<br/>
<br/>
Nous cherchons un stagiaire de bac +3 a&#768; bac +5, a&#768; partir de septembre 2015, pour un stage de pre&#769; embauche de longue dure&#769;e (re&#769;mune&#769;ration selon le profil, avec un minimum le&#769;gal garanti). Il sera directement supervise&#769; par le CTO - architecte logiciel Java expe&#769;rimente&#769; - et pourra ainsi monter en compe&#769;tence rapidement avec autonomie et responsabilite&#769;.<br/> 
<br/>
&#65532;Le produit e&#769;tant tre&#768;s innovant, les missions iront de la conception de nouvelles fonctionnalite&#769;s &#65532;jusquâa&#768; leur de&#769;veloppement.<br/>
<br/>
La proposition complÃ¨te est <a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/talent_troc.pdf\'>accessible ici</a>.
<br/> ', 'DÃ©veloppeur Web full-stack', '', '3', '6', '0', '', '1', '677');
INSERT INTO offredestage VALUES('356', '<br/>
Thibaud GAHAGNON, ancien Ã©tudiant du Master, a Ã©tÃ© recrutÃ© par CGI.<br/>
<br/>
CGI propose des stages via son site de recrutement <a href=\'https://cgi.njoyn.com\'>https://cgi.njoyn.com</a>.<br/>
<br/>
Afin que les candidatures soient recommandÃ©es (et ainsi maximiser les chances), lors de la crÃ©ation du profil candidat, il suffit dâindiquer quâelles sont recommandÃ©es par Thibaud GAHAGNON en indiquant son nom/prÃ©nom/mail (Ã  savoir : Thibaud GAHAGNON, thibaud.gahagnon@cgi.com)<br/>
<br/>
Pour le site du Mans, trois offres types sont proposÃ©s :
<ul>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/CGI_1.pdf\'>Offre 1</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/CGI_2.pdf\'>Offre 2</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/CGI_3.pdf\'>Offre 3</a></li>
</ul>
Que ce soit pour les offres en piÃ¨ce-jointe, oÃ¹ celles directement sur le site, il est nÃ©cessaire de postuler via le site de recrutement de CGI.
<br/>
', 'Offres CGI', '', '3', '6', '0', '', '1', '681');
INSERT INTO offredestage VALUES('354', '<br/>
Voici de la part d\'un ancien Ã©tudiant les offres de Sopra-Steria 2015-2016.<br/>
<br/>
Le dÃ©pÃ´t d\'une candidature se fait directement sur le site de recrutement de Sopra (cf. adresse dans le book).<br/>
<br/>
Le book est <a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/sopra_steria.pdf\'>accessible ici</a>.', 'Offres Sopra-Steria', '', '6', '6', '0', '', '1', '679');
INSERT INTO offredestage VALUES('355', '<br/>
La sociÃ©tÃ© eBusiness Information du Groupe Excilys propose plusieurs offres de stage dans les conditions suivantes:<br/>
- Tous les stages sont dans une optique d\'embauche.<br/>
- Chaque stagiaire reÃ§oit une formation de 4 Ã  8 semaines sur l\'environnement JEE, dÃ¨s le dÃ©but de son stage.<br/>
- Puis il intÃ¨gre un projet et sera encadrÃ© par des experts.<br/>
<br/>
De plus, l\'entreprise propose un hÃ©bergement pendant toute la durÃ©e du stage (prioritÃ© aux personnes venant de province et selon les places disponibles), et une indemnitÃ© de stage de 1000 euros brut par mois.
<br/><br/>
Voici les sujets proposÃ©s :<br/>
<ul>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/eBiz_3.pdf\'>DesignMyApp, HTML5, CSS3, AngularJS, Android, iOS, Cordova</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/eBiz_4.pdf\'>Gatling â Stress Tool</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/eBiz_1.pdf\'>CAPICO Kids : Android, iPad</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/eBiz_2.pdf\'>CAPICO HTML5, CSS3, AngularJS, Cordova</a></li>
<li><a href=\'http://info-stages.univ-lemans.fr/documents/sujetsDeStages/eBiz_5.pdf\'>Serious Game Smartphone et Tablette</a></li>
</ul>', 'Offres eBusinessInformation', '', '6', '6', '1000', '', '1', '680');

-- -----------------------------
-- insertions dans la table parcours
-- -----------------------------
INSERT INTO parcours VALUES('1', 'ASITR');
INSERT INTO parcours VALUES('2', 'CHM');
INSERT INTO parcours VALUES('3', 'CIEL');
INSERT INTO parcours VALUES('4', 'SIRI');
INSERT INTO parcours VALUES('8', 'SPI');
INSERT INTO parcours VALUES('7', 'ISR');
INSERT INTO parcours VALUES('9', 'ISI');

-- -----------------------------
-- insertions dans la table parrain
-- -----------------------------
INSERT INTO parrain VALUES('1', 'Lemeunier', 'Thierry', 'thierry.lemeunier@univ-lemans.fr', '2');
INSERT INTO parrain VALUES('2', 'Lehuen', 'JÃ©rÃ´me', 'jerome.lehuen@univ-lemans.fr', '1');
INSERT INTO parrain VALUES('3', 'Non', 'affectÃ©', '', '13');
INSERT INTO parrain VALUES('4', 'Carlier', 'Florent', 'florent.carlier@univ-lemans.fr', '25');
INSERT INTO parrain VALUES('5', 'Leroux', 'Pascal', 'pascal.leroux@univ-lemans.fr', '3');
INSERT INTO parrain VALUES('6', 'Rial', 'Angel', 'angel.rial@univ-lemans.fr', '21');
INSERT INTO parrain VALUES('7', 'Malandin', 'Emmanuel', 'emmanuel.malandin@univ-lemans.fr', '4');
INSERT INTO parrain VALUES('8', 'MontrÃ©sor', 'Silvio', 'silvio.montresor@univ-lemans.fr', '11');
INSERT INTO parrain VALUES('9', 'DesprÃ©s', 'Christophe', 'christophe.despres@univ-lemans.fr', '20');
INSERT INTO parrain VALUES('10', 'Jacoboni', 'Pierre', 'pierre.jacoboni@univ-lemans.fr', '8');
INSERT INTO parrain VALUES('11', 'Jacob', 'Bruno', 'bruno.jacob@univ-lemans.fr', '19');
INSERT INTO parrain VALUES('12', 'Meignier', 'Sylvain', 'meignier.sylvain@univ-lemans.fr', '29');
INSERT INTO parrain VALUES('13', 'Morand', 'Guy', 'guy.morand@univ-lemans.fr', '12');
INSERT INTO parrain VALUES('14', 'Py', 'Dominique', 'dominique.py@univ-lemans.fr', '15');
INSERT INTO parrain VALUES('15', 'Schwenk', 'Holger', 'holger.schwenk@univ-lemans.fr', '22');
INSERT INTO parrain VALUES('16', 'Teutsch', 'Philippe', 'philippe.teutsch@univ-lemans.fr', '24');
INSERT INTO parrain VALUES('17', 'Bernard', 'Didier', 'Didier-Michel.Bernard@ac-nantes.fr', '7');
INSERT INTO parrain VALUES('18', 'Cruchet', 'Philippe', 'phcruchet@yahoo.fr', '10');
INSERT INTO parrain VALUES('19', 'Guillet', 'Jean', 'jguillet@infonie.fr', '18');
INSERT INTO parrain VALUES('20', 'PinÃ§on', 'JoÃ«l', 'joel.pincon@ac-nantes.fr', '14');
INSERT INTO parrain VALUES('21', 'Allys', 'LoÃ¯c', 'loic.allys@univ-lemans.fr', '6');
INSERT INTO parrain VALUES('22', 'EstÃ¨ve', 'Yannick', 'yannick.esteve@univ-lemans.fr', '28');
INSERT INTO parrain VALUES('23', 'ClÃ©der', 'Catherine', 'catherine.cleder@univ-lemans.fr', '9');
INSERT INTO parrain VALUES('24', 'Barrault', 'Loic', 'loic.barrault@univ-lemans.fr', '14');
INSERT INTO parrain VALUES('25', 'Alissali', 'Mamoun', 'mamoun.alissali@univ-lemans.fr', '2');
INSERT INTO parrain VALUES('26', 'Laurent', 'Antoine', 'antoine.laurent@univ-lemans.fr', '17');
INSERT INTO parrain VALUES('27', 'Camelin', 'Nathalie', 'Nathalie.Camelin@univ-lemans.fr', '23');
INSERT INTO parrain VALUES('28', 'Rousseau', 'Anthony', 'anthony.rousseau@lium.univ-lemans.fr', '5');
INSERT INTO parrain VALUES('29', 'Renault', 'ValÃ©rie', 'valerie.renault@univ-lemans.fr', '26');
INSERT INTO parrain VALUES('30', 'Bougares', 'Fethi', 'fethi.bougares@lium.univ-lemans.fr', '16');
INSERT INTO parrain VALUES('31', 'Jousse', 'Vincent', 'vincent.jousse@lium.univ-lemans.fr', '24');
INSERT INTO parrain VALUES('32', 'DelÃ©glise', 'Paul', 'paul.deleglise@univ-lemans.fr', '19');
INSERT INTO parrain VALUES('33', 'Dupuy', 'GrÃ©gore', 'gregor.dupuy@lium.univ-lemans.fr', '3');
INSERT INTO parrain VALUES('34', 'Piau-Toffolon', 'Claudine', 'Claudine.Piau-Toffolon@univ-lemans.fr', '22');
INSERT INTO parrain VALUES('35', 'Merlin', 'Teva', 'teva.merlin@lium.univ-lemans.fr', '22');
INSERT INTO parrain VALUES('36', 'Larcher', 'Anthony', 'anthony.larcher@univ-lemans.fr', '1');
INSERT INTO parrain VALUES('37', 'Petitrenaud', 'Simon', 'simon.petitrenaud@univ-lemans.fr', '6');

-- -----------------------------
-- insertions dans la table profilsouhaite_offredestage
-- -----------------------------
INSERT INTO profilsouhaite_offredestage VALUES('353', '1');
INSERT INTO profilsouhaite_offredestage VALUES('363', '1');
INSERT INTO profilsouhaite_offredestage VALUES('364', '1');
INSERT INTO profilsouhaite_offredestage VALUES('364', '4');
INSERT INTO profilsouhaite_offredestage VALUES('362', '1');
INSERT INTO profilsouhaite_offredestage VALUES('358', '1');
INSERT INTO profilsouhaite_offredestage VALUES('357', '1');
INSERT INTO profilsouhaite_offredestage VALUES('353', '4');
INSERT INTO profilsouhaite_offredestage VALUES('360', '1');
INSERT INTO profilsouhaite_offredestage VALUES('363', '4');
INSERT INTO profilsouhaite_offredestage VALUES('362', '4');
INSERT INTO profilsouhaite_offredestage VALUES('351', '1');
INSERT INTO profilsouhaite_offredestage VALUES('376', '1');
INSERT INTO profilsouhaite_offredestage VALUES('367', '1');
INSERT INTO profilsouhaite_offredestage VALUES('361', '1');
INSERT INTO profilsouhaite_offredestage VALUES('354', '1');
INSERT INTO profilsouhaite_offredestage VALUES('366', '1');
INSERT INTO profilsouhaite_offredestage VALUES('368', '1');
INSERT INTO profilsouhaite_offredestage VALUES('356', '1');
INSERT INTO profilsouhaite_offredestage VALUES('370', '1');
INSERT INTO profilsouhaite_offredestage VALUES('369', '4');
INSERT INTO profilsouhaite_offredestage VALUES('372', '1');
INSERT INTO profilsouhaite_offredestage VALUES('371', '1');
INSERT INTO profilsouhaite_offredestage VALUES('374', '4');
INSERT INTO profilsouhaite_offredestage VALUES('371', '4');
INSERT INTO profilsouhaite_offredestage VALUES('366', '4');
INSERT INTO profilsouhaite_offredestage VALUES('376', '4');
INSERT INTO profilsouhaite_offredestage VALUES('373', '1');
INSERT INTO profilsouhaite_offredestage VALUES('373', '4');
INSERT INTO profilsouhaite_offredestage VALUES('372', '4');
INSERT INTO profilsouhaite_offredestage VALUES('370', '4');
INSERT INTO profilsouhaite_offredestage VALUES('359', '1');
INSERT INTO profilsouhaite_offredestage VALUES('356', '4');
INSERT INTO profilsouhaite_offredestage VALUES('359', '4');
INSERT INTO profilsouhaite_offredestage VALUES('358', '4');
INSERT INTO profilsouhaite_offredestage VALUES('357', '4');
INSERT INTO profilsouhaite_offredestage VALUES('365', '1');
INSERT INTO profilsouhaite_offredestage VALUES('355', '1');

-- -----------------------------
-- insertions dans la table promotion
-- -----------------------------
INSERT INTO promotion VALUES('1', '2009', '1', '1', 'm2p@info.univ-lemans.fr');
INSERT INTO promotion VALUES('2', '2009', '2', '1', 'm2p@info.univ-lemans.fr');
INSERT INTO promotion VALUES('3', '2009', '3', '2', 'l3@info.univ-lemans.fr');
INSERT INTO promotion VALUES('4', '2009', '4', '3', 'l3siri@info.univ-lemans.fr');
INSERT INTO promotion VALUES('5', '2009', '2', '4', 'm1@info.univ-lemans.fr');
INSERT INTO promotion VALUES('7', '2009', '7', '5', 'deustisr2@info.univ-lemans.fr');
INSERT INTO promotion VALUES('8', '2010', '4', '3', 'l3siri@info.univ-lemans.fr');
INSERT INTO promotion VALUES('9', '2010', '2', '4', 'm1@info.univ-lemans.fr');
INSERT INTO promotion VALUES('10', '2010', '2', '1', 'm2p@info.univ-lemans.fr');
INSERT INTO promotion VALUES('11', '2011', '4', '3', 'l3siri@info.univ-lemans.fr');
INSERT INTO promotion VALUES('12', '2011', '2', '4', 'm1@info.univ-lemans.fr');
INSERT INTO promotion VALUES('13', '2011', '2', '1', 'm2p@info.univ-lemans.fr');
INSERT INTO promotion VALUES('15', '2012', '9', '4', 'm1@info.univ-lemans.fr');
INSERT INTO promotion VALUES('16', '2012', '4', '3', 'l3siri@info.univ-lemans.fr');
INSERT INTO promotion VALUES('17', '2012', '9', '1', 'm2p@info.univ-lemans.fr');
INSERT INTO promotion VALUES('19', '2012', '8', '2', 'l3spi@info.univ-lemans.fr');
INSERT INTO promotion VALUES('20', '2013', '9', '4', 'm1init@info.univ-lemans.fr');
INSERT INTO promotion VALUES('21', '2013', '9', '1', 'm2init@info.univ-lemans.fr');
INSERT INTO promotion VALUES('24', '2014', '9', '4', 'm1init@info.univ-lemans.fr');
INSERT INTO promotion VALUES('25', '2014', '9', '1', 'm2init@info.univ-lemans.fr');
INSERT INTO promotion VALUES('26', '2015', '9', '1', 'm2init@info.univ-lemans.fr');
INSERT INTO promotion VALUES('27', '2015', '9', '4', 'm1init@info.univ-lemans.fr');

-- -----------------------------
-- insertions dans la table relation_competence_offredestage
-- -----------------------------
INSERT INTO relation_competence_offredestage VALUES('52', '363');
INSERT INTO relation_competence_offredestage VALUES('37', '363');
INSERT INTO relation_competence_offredestage VALUES('22', '363');
INSERT INTO relation_competence_offredestage VALUES('36', '374');
INSERT INTO relation_competence_offredestage VALUES('2', '360');
INSERT INTO relation_competence_offredestage VALUES('3', '359');
INSERT INTO relation_competence_offredestage VALUES('49', '372');
INSERT INTO relation_competence_offredestage VALUES('48', '372');
INSERT INTO relation_competence_offredestage VALUES('8', '374');
INSERT INTO relation_competence_offredestage VALUES('2', '376');
INSERT INTO relation_competence_offredestage VALUES('43', '372');
INSERT INTO relation_competence_offredestage VALUES('38', '372');
INSERT INTO relation_competence_offredestage VALUES('2', '358');
INSERT INTO relation_competence_offredestage VALUES('27', '373');
INSERT INTO relation_competence_offredestage VALUES('29', '368');
INSERT INTO relation_competence_offredestage VALUES('10', '373');
INSERT INTO relation_competence_offredestage VALUES('29', '372');
INSERT INTO relation_competence_offredestage VALUES('28', '372');
INSERT INTO relation_competence_offredestage VALUES('9', '372');
INSERT INTO relation_competence_offredestage VALUES('8', '372');
INSERT INTO relation_competence_offredestage VALUES('7', '372');
INSERT INTO relation_competence_offredestage VALUES('10', '367');
INSERT INTO relation_competence_offredestage VALUES('10', '366');
INSERT INTO relation_competence_offredestage VALUES('2', '365');
INSERT INTO relation_competence_offredestage VALUES('6', '374');
INSERT INTO relation_competence_offredestage VALUES('29', '353');
INSERT INTO relation_competence_offredestage VALUES('2', '368');
INSERT INTO relation_competence_offredestage VALUES('1', '368');
INSERT INTO relation_competence_offredestage VALUES('3', '372');
INSERT INTO relation_competence_offredestage VALUES('5', '374');
INSERT INTO relation_competence_offredestage VALUES('10', '371');
INSERT INTO relation_competence_offredestage VALUES('10', '370');
INSERT INTO relation_competence_offredestage VALUES('2', '354');
INSERT INTO relation_competence_offredestage VALUES('40', '351');
INSERT INTO relation_competence_offredestage VALUES('4', '374');
INSERT INTO relation_competence_offredestage VALUES('19', '353');
INSERT INTO relation_competence_offredestage VALUES('9', '353');
INSERT INTO relation_competence_offredestage VALUES('8', '353');
INSERT INTO relation_competence_offredestage VALUES('6', '353');
INSERT INTO relation_competence_offredestage VALUES('3', '353');
INSERT INTO relation_competence_offredestage VALUES('43', '357');
INSERT INTO relation_competence_offredestage VALUES('9', '357');
INSERT INTO relation_competence_offredestage VALUES('4', '357');
INSERT INTO relation_competence_offredestage VALUES('3', '357');
INSERT INTO relation_competence_offredestage VALUES('2', '356');
INSERT INTO relation_competence_offredestage VALUES('2', '355');

-- -----------------------------
-- insertions dans la table relation_promotion_datesoutenance
-- -----------------------------
INSERT INTO relation_promotion_datesoutenance VALUES('1', '4');
INSERT INTO relation_promotion_datesoutenance VALUES('1', '5');
INSERT INTO relation_promotion_datesoutenance VALUES('1', '7');
INSERT INTO relation_promotion_datesoutenance VALUES('2', '4');
INSERT INTO relation_promotion_datesoutenance VALUES('2', '5');
INSERT INTO relation_promotion_datesoutenance VALUES('2', '7');
INSERT INTO relation_promotion_datesoutenance VALUES('3', '4');
INSERT INTO relation_promotion_datesoutenance VALUES('3', '5');
INSERT INTO relation_promotion_datesoutenance VALUES('3', '7');
INSERT INTO relation_promotion_datesoutenance VALUES('4', '1');
INSERT INTO relation_promotion_datesoutenance VALUES('4', '2');
INSERT INTO relation_promotion_datesoutenance VALUES('5', '1');
INSERT INTO relation_promotion_datesoutenance VALUES('5', '2');
INSERT INTO relation_promotion_datesoutenance VALUES('6', '1');
INSERT INTO relation_promotion_datesoutenance VALUES('6', '2');
INSERT INTO relation_promotion_datesoutenance VALUES('6', '4');
INSERT INTO relation_promotion_datesoutenance VALUES('6', '5');
INSERT INTO relation_promotion_datesoutenance VALUES('6', '7');
INSERT INTO relation_promotion_datesoutenance VALUES('7', '1');
INSERT INTO relation_promotion_datesoutenance VALUES('7', '2');
INSERT INTO relation_promotion_datesoutenance VALUES('7', '4');
INSERT INTO relation_promotion_datesoutenance VALUES('7', '5');
INSERT INTO relation_promotion_datesoutenance VALUES('7', '7');
INSERT INTO relation_promotion_datesoutenance VALUES('8', '1');
INSERT INTO relation_promotion_datesoutenance VALUES('8', '2');
INSERT INTO relation_promotion_datesoutenance VALUES('8', '4');
INSERT INTO relation_promotion_datesoutenance VALUES('8', '5');
INSERT INTO relation_promotion_datesoutenance VALUES('8', '7');
INSERT INTO relation_promotion_datesoutenance VALUES('9', '8');
INSERT INTO relation_promotion_datesoutenance VALUES('9', '9');
INSERT INTO relation_promotion_datesoutenance VALUES('10', '8');
INSERT INTO relation_promotion_datesoutenance VALUES('10', '9');
INSERT INTO relation_promotion_datesoutenance VALUES('11', '9');
INSERT INTO relation_promotion_datesoutenance VALUES('11', '10');
INSERT INTO relation_promotion_datesoutenance VALUES('12', '9');
INSERT INTO relation_promotion_datesoutenance VALUES('12', '10');
INSERT INTO relation_promotion_datesoutenance VALUES('14', '11');
INSERT INTO relation_promotion_datesoutenance VALUES('14', '12');
INSERT INTO relation_promotion_datesoutenance VALUES('15', '11');
INSERT INTO relation_promotion_datesoutenance VALUES('15', '12');
INSERT INTO relation_promotion_datesoutenance VALUES('16', '13');
INSERT INTO relation_promotion_datesoutenance VALUES('17', '13');
INSERT INTO relation_promotion_datesoutenance VALUES('18', '11');
INSERT INTO relation_promotion_datesoutenance VALUES('18', '12');
INSERT INTO relation_promotion_datesoutenance VALUES('19', '15');
INSERT INTO relation_promotion_datesoutenance VALUES('19', '16');
INSERT INTO relation_promotion_datesoutenance VALUES('20', '15');
INSERT INTO relation_promotion_datesoutenance VALUES('20', '16');
INSERT INTO relation_promotion_datesoutenance VALUES('21', '16');
INSERT INTO relation_promotion_datesoutenance VALUES('21', '17');
INSERT INTO relation_promotion_datesoutenance VALUES('22', '16');
INSERT INTO relation_promotion_datesoutenance VALUES('22', '17');
INSERT INTO relation_promotion_datesoutenance VALUES('23', '15');
INSERT INTO relation_promotion_datesoutenance VALUES('24', '17');
INSERT INTO relation_promotion_datesoutenance VALUES('25', '17');
INSERT INTO relation_promotion_datesoutenance VALUES('26', '20');
INSERT INTO relation_promotion_datesoutenance VALUES('27', '20');
INSERT INTO relation_promotion_datesoutenance VALUES('28', '20');
INSERT INTO relation_promotion_datesoutenance VALUES('28', '21');
INSERT INTO relation_promotion_datesoutenance VALUES('29', '20');
INSERT INTO relation_promotion_datesoutenance VALUES('29', '21');
INSERT INTO relation_promotion_datesoutenance VALUES('32', '24');
INSERT INTO relation_promotion_datesoutenance VALUES('33', '25');
INSERT INTO relation_promotion_datesoutenance VALUES('34', '25');

-- -----------------------------
-- insertions dans la table relation_promotion_etudiant_convention
-- -----------------------------
INSERT INTO relation_promotion_etudiant_convention VALUES('1', '15', '1');
INSERT INTO relation_promotion_etudiant_convention VALUES('2', '7', '1');
INSERT INTO relation_promotion_etudiant_convention VALUES('3', '10', '1');
INSERT INTO relation_promotion_etudiant_convention VALUES('4', '2', '1');
INSERT INTO relation_promotion_etudiant_convention VALUES('5', '5', '1');
INSERT INTO relation_promotion_etudiant_convention VALUES('6', '21', '1');
INSERT INTO relation_promotion_etudiant_convention VALUES('7', '11', '1');
INSERT INTO relation_promotion_etudiant_convention VALUES('8', '13', '1');
INSERT INTO relation_promotion_etudiant_convention VALUES('9', '12', '1');
INSERT INTO relation_promotion_etudiant_convention VALUES('10', '26', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('11', '27', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('12', '8', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('13', '9', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('14', '20', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('15', '4', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('16', '6', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('17', '1', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('18', '25', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('19', '17', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('20', '22', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('21', '28', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('22', '32', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('23', '35', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('24', '23', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('25', '29', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('26', '3', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('27', '24', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('28', '18', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('29', '31', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('30', '30', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('31', '33', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('32', '16', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('33', '19', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('34', '34', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('156', '0', '2');
INSERT INTO relation_promotion_etudiant_convention VALUES('224', '244', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('109', '94', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('37', '100', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('38', '76', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('39', '61', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('40', '36', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('41', '58', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('42', '65', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('43', '78', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('44', '57', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('45', '62', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('46', '63', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('212', '0', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('48', '59', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('49', '75', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('50', '68', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('51', '70', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('52', '69', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('53', '56', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('54', '74', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('55', '71', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('56', '72', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('57', '73', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('58', '79', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('59', '60', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('60', '77', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('61', '81', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('62', '66', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('63', '67', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('64', '55', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('65', '38', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('66', '0', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('67', '44', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('69', '42', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('70', '40', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('71', '43', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('72', '47', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('73', '97', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('74', '45', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('75', '39', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('77', '0', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('78', '49', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('79', '41', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('80', '51', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('81', '50', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('82', '96', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('83', '37', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('84', '46', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('85', '53', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('86', '64', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('87', '0', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('174', '84', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('89', '85', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('90', '90', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('189', '82', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('93', '87', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('95', '89', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('96', '91', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('123', '95', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('98', '92', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('99', '93', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('100', '88', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('207', '83', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('124', '86', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('104', '0', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('105', '0', '7');
INSERT INTO relation_promotion_etudiant_convention VALUES('157', '14', '1');
INSERT INTO relation_promotion_etudiant_convention VALUES('76', '54', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('108', '52', '4');
INSERT INTO relation_promotion_etudiant_convention VALUES('110', '135', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('111', '129', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('112', '0', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('113', '139', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('114', '140', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('159', '200', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('116', '0', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('117', '134', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('118', '137', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('119', '136', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('120', '131', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('162', '194', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('122', '127', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('123', '138', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('124', '132', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('125', '125', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('126', '0', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('127', '161', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('128', '124', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('129', '130', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('130', '126', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('131', '133', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('161', '202', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('160', '198', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('121', '123', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('115', '128', '8');
INSERT INTO relation_promotion_etudiant_convention VALUES('132', '146', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('213', '0', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('134', '152', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('135', '145', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('136', '148', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('137', '143', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('138', '144', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('139', '159', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('140', '157', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('141', '142', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('142', '151', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('143', '147', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('144', '155', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('145', '158', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('146', '0', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('147', '149', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('148', '150', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('149', '160', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('150', '141', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('151', '154', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('209', '0', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('211', '153', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('154', '156', '9');
INSERT INTO relation_promotion_etudiant_convention VALUES('36', '116', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('37', '80', '5');
INSERT INTO relation_promotion_etudiant_convention VALUES('38', '101', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('39', '120', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('40', '115', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('42', '122', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('43', '98', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('44', '112', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('46', '0', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('48', '102', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('49', '121', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('50', '110', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('52', '111', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('54', '104', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('55', '106', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('56', '105', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('86', '0', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('57', '117', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('58', '114', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('59', '107', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('60', '0', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('61', '113', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('62', '109', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('63', '108', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('64', '118', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('155', '103', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('156', '99', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('157', '119', '10');
INSERT INTO relation_promotion_etudiant_convention VALUES('163', '189', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('164', '191', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('165', '193', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('166', '196', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('167', '201', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('168', '188', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('169', '197', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('170', '190', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('171', '204', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('172', '205', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('173', '203', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('174', '192', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('225', '321', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('176', '195', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('158', '199', '11');
INSERT INTO relation_promotion_etudiant_convention VALUES('177', '227', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('178', '233', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('179', '238', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('180', '218', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('181', '217', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('183', '241', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('184', '215', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('185', '225', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('186', '222', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('187', '223', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('188', '230', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('189', '232', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('190', '235', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('191', '212', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('192', '220', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('193', '234', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('194', '236', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('195', '219', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('235', '0', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('197', '231', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('198', '213', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('200', '221', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('201', '224', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('202', '228', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('203', '237', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('204', '211', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('205', '0', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('100', '216', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('207', '226', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('208', '240', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('209', '0', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('210', '229', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('132', '172', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('134', '0', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('135', '171', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('136', '178', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('138', '0', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('139', '165', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('140', '164', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('141', '177', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('142', '176', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('143', '0', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('144', '168', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('145', '169', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('147', '170', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('148', '167', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('150', '175', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('149', '166', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('151', '0', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('154', '174', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('211', '173', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('212', '0', '13');
INSERT INTO relation_promotion_etudiant_convention VALUES('236', '343', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('230', '346', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('213', '0', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('223', '243', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('215', '206', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('216', '210', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('217', '207', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('218', '214', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('219', '239', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('220', '209', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('221', '0', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('214', '208', '12');
INSERT INTO relation_promotion_etudiant_convention VALUES('226', '302', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('201', '387', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('227', '245', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('228', '312', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('240', '344', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('237', '350', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('229', '311', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('230', '246', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('233', '323', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('232', '303', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('234', '310', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('235', '320', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('236', '247', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('237', '319', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('238', '313', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('239', '318', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('240', '248', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('247', '322', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('242', '317', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('245', '305', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('244', '308', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('248', '324', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('249', '307', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('250', '326', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('242', '351', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('251', '314', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('252', '347', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('253', '306', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('251', '348', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('255', '316', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('256', '0', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('134', '284', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('244', '335', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('227', '345', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('177', '270', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('178', '280', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('179', '257', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('180', '287', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('181', '0', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('183', '266', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('184', '281', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('214', '264', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('185', '272', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('219', '267', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('186', '268', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('187', '260', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('188', '283', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('215', '263', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('216', '258', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('189', '278', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('190', '282', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('191', '265', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('192', '273', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('194', '286', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('218', '277', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('195', '269', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('197', '259', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('198', '279', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('220', '274', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('200', '261', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('203', '256', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('204', '271', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('226', '349', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('207', '275', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('208', '285', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('210', '262', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('259', '0', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('224', '342', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('223', '341', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('253', '0', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('144', '327', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('260', '249', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('261', '250', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('262', '299', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('263', '291', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('264', '251', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('285', '369', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('265', '252', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('239', '333', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('238', '339', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('266', '253', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('267', '298', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('268', '292', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('269', '254', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('235', '332', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('270', '255', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('271', '290', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('272', '0', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('232', '331', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('273', '0', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('283', '329', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('274', '293', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('233', '330', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('275', '296', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('276', '', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('277', '288', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('278', '300', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('279', '297', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('229', '336', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('280', '295', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('281', '328', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('254', '334', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('225', '337', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('282', '289', '16');
INSERT INTO relation_promotion_etudiant_convention VALUES('248', '352', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('254', '304', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('283', '309', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('100', '276', '17');
INSERT INTO relation_promotion_etudiant_convention VALUES('284', '325', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('252', '301', '15');
INSERT INTO relation_promotion_etudiant_convention VALUES('228', '338', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('286', '0', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('320', '396', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('319', '375', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('249', '340', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('250', '353', '21');
INSERT INTO relation_promotion_etudiant_convention VALUES('323', '410', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('287', '365', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('288', '361', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('322', '435', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('289', '383', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('290', '356', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('291', '362', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('292', '371', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('294', '357', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('295', '366', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('296', '376', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('297', '380', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('298', '384', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('299', '360', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('300', '385', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('301', '368', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('234', '0', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('302', '382', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('303', '374', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('304', '372', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('305', '381', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('306', '386', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('307', '378', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('324', '430', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('256', '367', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('309', '364', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('310', '354', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('311', '363', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('312', '377', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('313', '370', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('314', '355', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('315', '379', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('316', '358', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('317', '0', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('321', '428', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('318', '373', '20');
INSERT INTO relation_promotion_etudiant_convention VALUES('325', '432', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('326', '434', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('328', '446', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('327', '404', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('328', '424', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('329', '425', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('330', '429', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('323', '444', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('331', '426', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('334', '442', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('332', '409', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('324', '441', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('333', '411', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('331', '439', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('334', '408', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('335', '433', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('332', '443', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('336', '427', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('321', '456', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('330', '447', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('338', '431', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('339', '0', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('289', '417', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('297', '414', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('298', '418', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('340', '405', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('300', '419', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('302', '416', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('304', '421', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('305', '415', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('306', '420', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('307', '412', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('314', '423', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('315', '413', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('316', '422', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('285', '402', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('291', '397', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('292', '391', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('294', '398', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('295', '403', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('296', '399', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('299', '388', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('301', '406', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('320', '440', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('341', '436', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('256', '407', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('309', '392', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('310', '400', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('312', '394', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('343', '0', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('253', '0', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('336', '445', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('337', '401', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('344', '0', '24');
INSERT INTO relation_promotion_etudiant_convention VALUES('326', '460', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('318', '389', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('290', '390', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('311', '393', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('313', '395', '25');
INSERT INTO relation_promotion_etudiant_convention VALUES('335', '455', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('337', '438', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('327', '459', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('343', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('380', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('346', '449', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('346', '449', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('347', '454', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('348', '450', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('349', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('350', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('351', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('352', '451', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('353', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('354', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('355', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('356', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('357', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('358', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('359', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('360', '452', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('361', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('362', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('363', '453', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('364', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('364', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('365', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('366', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('367', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('368', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('369', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('370', '437', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('371', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('372', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('373', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('374', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('375', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('370', '437', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('2', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('376', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('377', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('378', '0', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('379', '448', '27');
INSERT INTO relation_promotion_etudiant_convention VALUES('325', '', '26');
INSERT INTO relation_promotion_etudiant_convention VALUES('333', '458', '26');

-- -----------------------------
-- insertions dans la table salle_soutenance
-- -----------------------------
INSERT INTO salle_soutenance VALUES('1', 'Salle de cours');
INSERT INTO salle_soutenance VALUES('2', 'TD1');
INSERT INTO salle_soutenance VALUES('3', 'TD2');
INSERT INTO salle_soutenance VALUES('4', 'TD3');
INSERT INTO salle_soutenance VALUES('5', 'TD4');
INSERT INTO salle_soutenance VALUES('6', 'Salle des conseils');
INSERT INTO salle_soutenance VALUES('7', 'ExtÃ©rieur');
INSERT INTO salle_soutenance VALUES('8', 'Amphi');

-- -----------------------------
-- insertions dans la table soutenances
-- -----------------------------
INSERT INTO soutenances VALUES('4', '9', '40', '0', '2', '5');
INSERT INTO soutenances VALUES('97', '9', '20', '0', '5', '5');
INSERT INTO soutenances VALUES('5', '9', '20', '0', '2', '5');
INSERT INTO soutenances VALUES('6', '10', '10', '0', '2', '5');
INSERT INTO soutenances VALUES('7', '10', '30', '0', '2', '5');
INSERT INTO soutenances VALUES('8', '11', '40', '0', '2', '5');
INSERT INTO soutenances VALUES('9', '11', '20', '0', '2', '5');
INSERT INTO soutenances VALUES('10', '10', '50', '0', '2', '5');
INSERT INTO soutenances VALUES('11', '14', '40', '0', '1', '5');
INSERT INTO soutenances VALUES('12', '15', '10', '0', '1', '5');
INSERT INTO soutenances VALUES('13', '14', '20', '0', '1', '5');
INSERT INTO soutenances VALUES('14', '14', '0', '0', '1', '5');
INSERT INTO soutenances VALUES('15', '11', '20', '0', '2', '4');
INSERT INTO soutenances VALUES('16', '11', '40', '0', '2', '4');
INSERT INTO soutenances VALUES('17', '9', '0', '0', '1', '2');
INSERT INTO soutenances VALUES('18', '11', '20', '0', '1', '2');
INSERT INTO soutenances VALUES('19', '10', '10', '0', '1', '2');
INSERT INTO soutenances VALUES('20', '10', '40', '0', '1', '2');
INSERT INTO soutenances VALUES('21', '9', '30', '0', '1', '2');
INSERT INTO soutenances VALUES('22', '14', '0', '0', '1', '2');
INSERT INTO soutenances VALUES('23', '9', '20', '0', '4', '2');
INSERT INTO soutenances VALUES('24', '14', '30', '0', '1', '2');
INSERT INTO soutenances VALUES('25', '10', '10', '0', '1', '3');
INSERT INTO soutenances VALUES('26', '9', '0', '0', '1', '3');
INSERT INTO soutenances VALUES('27', '9', '30', '0', '1', '3');
INSERT INTO soutenances VALUES('28', '11', '50', '0', '1', '3');
INSERT INTO soutenances VALUES('29', '10', '40', '0', '1', '3');
INSERT INTO soutenances VALUES('30', '11', '20', '0', '1', '3');
INSERT INTO soutenances VALUES('31', '10', '10', '0', '2', '4');
INSERT INTO soutenances VALUES('32', '9', '30', '0', '2', '4');
INSERT INTO soutenances VALUES('33', '10', '40', '0', '2', '4');
INSERT INTO soutenances VALUES('34', '14', '0', '0', '1', '4');
INSERT INTO soutenances VALUES('35', '15', '10', '0', '1', '4');
INSERT INTO soutenances VALUES('36', '14', '30', '0', '1', '4');
INSERT INTO soutenances VALUES('37', '15', '40', '0', '1', '4');
INSERT INTO soutenances VALUES('38', '15', '30', '0', '1', '5');
INSERT INTO soutenances VALUES('39', '11', '20', '0', '1', '4');
INSERT INTO soutenances VALUES('40', '10', '10', '0', '1', '4');
INSERT INTO soutenances VALUES('41', '14', '0', '0', '1', '3');
INSERT INTO soutenances VALUES('42', '14', '30', '0', '1', '3');
INSERT INTO soutenances VALUES('43', '9', '30', '0', '1', '4');
INSERT INTO soutenances VALUES('44', '10', '40', '0', '1', '4');
INSERT INTO soutenances VALUES('45', '9', '20', '0', '5', '3');
INSERT INTO soutenances VALUES('46', '14', '0', '0', '2', '5');
INSERT INTO soutenances VALUES('47', '14', '30', '0', '2', '5');
INSERT INTO soutenances VALUES('48', '15', '10', '0', '2', '5');
INSERT INTO soutenances VALUES('49', '15', '40', '0', '2', '5');
INSERT INTO soutenances VALUES('50', '14', '30', '0', '2', '4');
INSERT INTO soutenances VALUES('51', '14', '0', '0', '2', '4');
INSERT INTO soutenances VALUES('52', '15', '10', '0', '2', '4');
INSERT INTO soutenances VALUES('53', '15', '40', '0', '2', '4');
INSERT INTO soutenances VALUES('54', '15', '10', '0', '1', '3');
INSERT INTO soutenances VALUES('55', '15', '40', '0', '1', '3');
INSERT INTO soutenances VALUES('56', '10', '10', '0', '3', '4');
INSERT INTO soutenances VALUES('57', '15', '40', '0', '3', '4');
INSERT INTO soutenances VALUES('58', '15', '10', '0', '3', '4');
INSERT INTO soutenances VALUES('59', '14', '30', '0', '3', '4');
INSERT INTO soutenances VALUES('60', '10', '40', '0', '3', '4');
INSERT INTO soutenances VALUES('61', '14', '0', '0', '3', '4');
INSERT INTO soutenances VALUES('62', '11', '15', '0', '3', '4');
INSERT INTO soutenances VALUES('63', '14', '0', '0', '4', '3');
INSERT INTO soutenances VALUES('64', '10', '0', '0', '4', '3');
INSERT INTO soutenances VALUES('65', '9', '0', '0', '4', '3');
INSERT INTO soutenances VALUES('66', '11', '0', '0', '4', '3');
INSERT INTO soutenances VALUES('67', '10', '0', '0', '4', '4');
INSERT INTO soutenances VALUES('68', '11', '0', '0', '4', '4');
INSERT INTO soutenances VALUES('69', '9', '0', '0', '4', '4');
INSERT INTO soutenances VALUES('70', '14', '0', '0', '4', '4');
INSERT INTO soutenances VALUES('71', '11', '0', '0', '6', '5');
INSERT INTO soutenances VALUES('72', '15', '0', '0', '6', '5');
INSERT INTO soutenances VALUES('73', '10', '0', '0', '6', '5');
INSERT INTO soutenances VALUES('74', '14', '0', '0', '6', '5');
INSERT INTO soutenances VALUES('75', '16', '0', '0', '6', '5');
INSERT INTO soutenances VALUES('76', '9', '0', '0', '6', '5');
INSERT INTO soutenances VALUES('77', '11', '0', '0', '4', '2');
INSERT INTO soutenances VALUES('78', '14', '0', '0', '4', '2');
INSERT INTO soutenances VALUES('79', '10', '0', '0', '4', '2');
INSERT INTO soutenances VALUES('80', '10', '0', '0', '5', '4');
INSERT INTO soutenances VALUES('81', '15', '0', '0', '4', '2');
INSERT INTO soutenances VALUES('82', '14', '0', '0', '5', '4');
INSERT INTO soutenances VALUES('83', '10', '30', '0', '8', '5');
INSERT INTO soutenances VALUES('84', '11', '0', '0', '5', '4');
INSERT INTO soutenances VALUES('85', '9', '0', '0', '5', '4');
INSERT INTO soutenances VALUES('86', '16', '0', '0', '4', '2');
INSERT INTO soutenances VALUES('87', '10', '0', '0', '5', '3');
INSERT INTO soutenances VALUES('88', '16', '0', '0', '4', '3');
INSERT INTO soutenances VALUES('89', '17', '0', '0', '4', '3');
INSERT INTO soutenances VALUES('90', '11', '0', '0', '5', '3');
INSERT INTO soutenances VALUES('91', '15', '0', '0', '6', '4');
INSERT INTO soutenances VALUES('92', '14', '0', '0', '6', '4');
INSERT INTO soutenances VALUES('93', '10', '0', '0', '5', '5');
INSERT INTO soutenances VALUES('94', '11', '0', '0', '5', '5');
INSERT INTO soutenances VALUES('95', '11', '0', '0', '6', '4');
INSERT INTO soutenances VALUES('96', '10', '0', '0', '6', '4');
INSERT INTO soutenances VALUES('98', '12', '20', '0', '1', '3');
INSERT INTO soutenances VALUES('99', '10', '20', '0', '9', '4');
INSERT INTO soutenances VALUES('100', '14', '30', '0', '9', '4');
INSERT INTO soutenances VALUES('101', '11', '30', '0', '9', '4');
INSERT INTO soutenances VALUES('102', '15', '10', '0', '9', '4');
INSERT INTO soutenances VALUES('103', '11', '0', '0', '9', '4');
INSERT INTO soutenances VALUES('104', '15', '40', '0', '9', '4');
INSERT INTO soutenances VALUES('105', '9', '50', '0', '9', '4');
INSERT INTO soutenances VALUES('106', '14', '0', '0', '9', '4');
INSERT INTO soutenances VALUES('107', '15', '40', '0', '9', '3');
INSERT INTO soutenances VALUES('108', '14', '30', '0', '9', '3');
INSERT INTO soutenances VALUES('109', '11', '30', '0', '9', '3');
INSERT INTO soutenances VALUES('110', '10', '20', '0', '9', '3');
INSERT INTO soutenances VALUES('111', '15', '10', '0', '9', '3');
INSERT INTO soutenances VALUES('112', '14', '0', '0', '9', '3');
INSERT INTO soutenances VALUES('113', '9', '50', '0', '9', '3');
INSERT INTO soutenances VALUES('114', '11', '0', '0', '9', '3');
INSERT INTO soutenances VALUES('115', '11', '30', '0', '9', '5');
INSERT INTO soutenances VALUES('116', '11', '0', '0', '9', '5');
INSERT INTO soutenances VALUES('117', '9', '20', '0', '11', '5');
INSERT INTO soutenances VALUES('118', '15', '10', '0', '9', '2');
INSERT INTO soutenances VALUES('119', '14', '0', '0', '9', '2');
INSERT INTO soutenances VALUES('120', '14', '30', '0', '9', '2');
INSERT INTO soutenances VALUES('121', '15', '40', '0', '9', '2');
INSERT INTO soutenances VALUES('122', '10', '20', '0', '10', '5');
INSERT INTO soutenances VALUES('123', '11', '30', '0', '10', '5');
INSERT INTO soutenances VALUES('124', '11', '0', '0', '10', '5');
INSERT INTO soutenances VALUES('125', '15', '10', '0', '9', '5');
INSERT INTO soutenances VALUES('126', '14', '0', '0', '9', '5');
INSERT INTO soutenances VALUES('127', '14', '30', '0', '9', '5');
INSERT INTO soutenances VALUES('128', '11', '30', '0', '9', '2');
INSERT INTO soutenances VALUES('129', '10', '20', '0', '9', '5');
INSERT INTO soutenances VALUES('130', '11', '0', '0', '9', '2');
INSERT INTO soutenances VALUES('131', '10', '20', '0', '9', '1');
INSERT INTO soutenances VALUES('132', '11', '30', '0', '9', '1');
INSERT INTO soutenances VALUES('136', '9', '50', '0', '9', '2');
INSERT INTO soutenances VALUES('134', '11', '0', '0', '9', '1');
INSERT INTO soutenances VALUES('137', '10', '20', '0', '9', '2');
INSERT INTO soutenances VALUES('138', '10', '0', '0', '11', '3');
INSERT INTO soutenances VALUES('139', '16', '0', '0', '11', '3');
INSERT INTO soutenances VALUES('140', '11', '0', '0', '11', '3');
INSERT INTO soutenances VALUES('141', '11', '0', '0', '11', '5');
INSERT INTO soutenances VALUES('142', '15', '0', '0', '11', '5');
INSERT INTO soutenances VALUES('143', '10', '0', '0', '11', '5');
INSERT INTO soutenances VALUES('144', '14', '0', '0', '11', '5');
INSERT INTO soutenances VALUES('145', '11', '0', '0', '11', '4');
INSERT INTO soutenances VALUES('146', '10', '0', '0', '11', '4');
INSERT INTO soutenances VALUES('147', '14', '0', '0', '11', '4');
INSERT INTO soutenances VALUES('148', '15', '0', '0', '11', '4');
INSERT INTO soutenances VALUES('149', '14', '0', '0', '11', '3');
INSERT INTO soutenances VALUES('150', '15', '0', '0', '11', '3');
INSERT INTO soutenances VALUES('151', '11', '0', '0', '11', '2');
INSERT INTO soutenances VALUES('152', '10', '0', '0', '11', '2');
INSERT INTO soutenances VALUES('153', '9', '0', '0', '11', '1');
INSERT INTO soutenances VALUES('154', '10', '0', '0', '11', '1');
INSERT INTO soutenances VALUES('155', '15', '0', '0', '11', '2');
INSERT INTO soutenances VALUES('156', '14', '0', '0', '11', '2');
INSERT INTO soutenances VALUES('157', '11', '0', '0', '11', '1');
INSERT INTO soutenances VALUES('158', '15', '0', '0', '11', '1');
INSERT INTO soutenances VALUES('159', '16', '0', '0', '11', '1');
INSERT INTO soutenances VALUES('160', '14', '0', '0', '11', '1');
INSERT INTO soutenances VALUES('161', '9', '0', '1', '11', '2');
INSERT INTO soutenances VALUES('163', '15', '0', '0', '16', '6');
INSERT INTO soutenances VALUES('167', '14', '0', '0', '16', '6');
INSERT INTO soutenances VALUES('173', '10', '0', '0', '16', '6');
INSERT INTO soutenances VALUES('174', '11', '0', '0', '16', '6');
INSERT INTO soutenances VALUES('175', '13', '30', '0', '17', '6');
INSERT INTO soutenances VALUES('176', '14', '30', '0', '17', '6');
INSERT INTO soutenances VALUES('177', '14', '0', '0', '16', '5');
INSERT INTO soutenances VALUES('178', '15', '0', '0', '16', '5');
INSERT INTO soutenances VALUES('179', '11', '0', '0', '16', '2');
INSERT INTO soutenances VALUES('180', '9', '0', '0', '15', '3');
INSERT INTO soutenances VALUES('181', '10', '0', '0', '15', '3');
INSERT INTO soutenances VALUES('182', '10', '0', '0', '16', '5');
INSERT INTO soutenances VALUES('183', '13', '0', '0', '16', '5');
INSERT INTO soutenances VALUES('184', '14', '0', '0', '16', '2');
INSERT INTO soutenances VALUES('185', '15', '0', '0', '16', '2');
INSERT INTO soutenances VALUES('201', '11', '0', '0', '14', '1');
INSERT INTO soutenances VALUES('200', '10', '30', '0', '14', '1');
INSERT INTO soutenances VALUES('199', '9', '50', '0', '14', '1');
INSERT INTO soutenances VALUES('198', '9', '20', '0', '14', '1');
INSERT INTO soutenances VALUES('202', '14', '30', '0', '14', '7');
INSERT INTO soutenances VALUES('203', '11', '40', '0', '14', '1');
INSERT INTO soutenances VALUES('204', '15', '10', '0', '14', '7');
INSERT INTO soutenances VALUES('252', '14', '30', '0', '19', '1');
INSERT INTO soutenances VALUES('206', '10', '20', '0', '14', '2');
INSERT INTO soutenances VALUES('207', '10', '50', '0', '14', '2');
INSERT INTO soutenances VALUES('208', '9', '20', '0', '14', '6');
INSERT INTO soutenances VALUES('209', '11', '30', '0', '14', '2');
INSERT INTO soutenances VALUES('210', '9', '50', '0', '14', '6');
INSERT INTO soutenances VALUES('211', '10', '30', '0', '14', '6');
INSERT INTO soutenances VALUES('212', '11', '0', '0', '14', '6');
INSERT INTO soutenances VALUES('213', '10', '20', '0', '14', '3');
INSERT INTO soutenances VALUES('214', '14', '0', '0', '16', '4');
INSERT INTO soutenances VALUES('215', '14', '30', '0', '16', '4');
INSERT INTO soutenances VALUES('216', '15', '10', '0', '16', '4');
INSERT INTO soutenances VALUES('217', '9', '50', '0', '14', '3');
INSERT INTO soutenances VALUES('218', '9', '20', '0', '14', '3');
INSERT INTO soutenances VALUES('219', '10', '20', '0', '14', '4');
INSERT INTO soutenances VALUES('220', '10', '50', '0', '14', '4');
INSERT INTO soutenances VALUES('221', '11', '30', '0', '14', '4');
INSERT INTO soutenances VALUES('222', '14', '0', '0', '14', '4');
INSERT INTO soutenances VALUES('223', '14', '30', '0', '14', '4');
INSERT INTO soutenances VALUES('224', '15', '10', '0', '14', '4');
INSERT INTO soutenances VALUES('225', '15', '40', '0', '14', '2');
INSERT INTO soutenances VALUES('226', '16', '20', '0', '14', '2');
INSERT INTO soutenances VALUES('227', '15', '10', '0', '14', '2');
INSERT INTO soutenances VALUES('228', '14', '0', '0', '14', '2');
INSERT INTO soutenances VALUES('229', '14', '30', '0', '14', '2');
INSERT INTO soutenances VALUES('230', '14', '0', '0', '14', '5');
INSERT INTO soutenances VALUES('231', '14', '30', '0', '14', '5');
INSERT INTO soutenances VALUES('232', '14', '30', '0', '18', '5');
INSERT INTO soutenances VALUES('233', '14', '0', '0', '18', '5');
INSERT INTO soutenances VALUES('234', '10', '50', '0', '15', '1');
INSERT INTO soutenances VALUES('235', '11', '30', '0', '15', '1');
INSERT INTO soutenances VALUES('236', '14', '0', '0', '15', '1');
INSERT INTO soutenances VALUES('237', '14', '30', '0', '15', '1');
INSERT INTO soutenances VALUES('238', '15', '10', '0', '15', '1');
INSERT INTO soutenances VALUES('239', '15', '40', '0', '15', '1');
INSERT INTO soutenances VALUES('240', '11', '30', '0', '15', '2');
INSERT INTO soutenances VALUES('241', '15', '10', '0', '15', '2');
INSERT INTO soutenances VALUES('242', '15', '40', '0', '15', '2');
INSERT INTO soutenances VALUES('243', '12', '0', '0', '15', '2');
INSERT INTO soutenances VALUES('244', '14', '0', '0', '15', '2');
INSERT INTO soutenances VALUES('245', '14', '30', '0', '15', '2');
INSERT INTO soutenances VALUES('246', '14', '0', '0', '15', '3');
INSERT INTO soutenances VALUES('247', '14', '30', '0', '15', '3');
INSERT INTO soutenances VALUES('248', '15', '10', '0', '15', '3');
INSERT INTO soutenances VALUES('249', '15', '40', '0', '15', '3');
INSERT INTO soutenances VALUES('250', '10', '50', '0', '14', '5');
INSERT INTO soutenances VALUES('251', '11', '30', '0', '14', '5');
INSERT INTO soutenances VALUES('253', '14', '0', '0', '19', '1');
INSERT INTO soutenances VALUES('254', '10', '15', '0', '19', '3');
INSERT INTO soutenances VALUES('255', '11', '0', '0', '19', '3');
INSERT INTO soutenances VALUES('256', '11', '30', '0', '19', '3');
INSERT INTO soutenances VALUES('257', '14', '0', '0', '19', '3');
INSERT INTO soutenances VALUES('258', '14', '30', '0', '19', '3');
INSERT INTO soutenances VALUES('259', '15', '15', '0', '19', '3');
INSERT INTO soutenances VALUES('260', '11', '0', '0', '19', '2');
INSERT INTO soutenances VALUES('261', '10', '15', '0', '19', '2');
INSERT INTO soutenances VALUES('262', '11', '30', '0', '19', '2');
INSERT INTO soutenances VALUES('263', '9', '45', '0', '19', '2');
INSERT INTO soutenances VALUES('264', '15', '15', '0', '19', '4');
INSERT INTO soutenances VALUES('265', '14', '0', '0', '19', '4');
INSERT INTO soutenances VALUES('266', '14', '30', '0', '19', '4');
INSERT INTO soutenances VALUES('267', '15', '45', '0', '19', '4');
INSERT INTO soutenances VALUES('268', '16', '0', '0', '22', '2');
INSERT INTO soutenances VALUES('269', '9', '45', '0', '20', '1');
INSERT INTO soutenances VALUES('270', '10', '15', '0', '20', '1');
INSERT INTO soutenances VALUES('271', '11', '30', '0', '20', '1');
INSERT INTO soutenances VALUES('272', '11', '0', '0', '20', '1');
INSERT INTO soutenances VALUES('273', '14', '30', '0', '19', '2');
INSERT INTO soutenances VALUES('274', '14', '0', '0', '19', '2');
INSERT INTO soutenances VALUES('275', '14', '0', '0', '19', '5');
INSERT INTO soutenances VALUES('276', '11', '0', '0', '23', '8');
INSERT INTO soutenances VALUES('277', '14', '30', '0', '19', '5');
INSERT INTO soutenances VALUES('278', '15', '15', '0', '19', '5');
INSERT INTO soutenances VALUES('279', '11', '30', '0', '23', '8');
INSERT INTO soutenances VALUES('280', '15', '15', '0', '19', '2');
INSERT INTO soutenances VALUES('281', '15', '45', '0', '19', '2');
INSERT INTO soutenances VALUES('282', '11', '30', '0', '19', '5');
INSERT INTO soutenances VALUES('283', '11', '0', '0', '19', '5');
INSERT INTO soutenances VALUES('284', '9', '45', '0', '19', '5');
INSERT INTO soutenances VALUES('285', '10', '15', '0', '19', '5');
INSERT INTO soutenances VALUES('286', '10', '30', '0', '23', '8');
INSERT INTO soutenances VALUES('287', '10', '0', '0', '23', '8');
INSERT INTO soutenances VALUES('288', '11', '30', '0', '20', '4');
INSERT INTO soutenances VALUES('289', '11', '0', '0', '20', '4');
INSERT INTO soutenances VALUES('290', '9', '45', '0', '20', '5');
INSERT INTO soutenances VALUES('291', '9', '15', '0', '20', '2');
INSERT INTO soutenances VALUES('292', '11', '0', '0', '20', '2');
INSERT INTO soutenances VALUES('293', '10', '15', '0', '20', '3');
INSERT INTO soutenances VALUES('294', '10', '15', '0', '20', '5');
INSERT INTO soutenances VALUES('295', '11', '0', '0', '20', '3');
INSERT INTO soutenances VALUES('296', '9', '0', '0', '23', '8');
INSERT INTO soutenances VALUES('297', '10', '15', '0', '20', '2');
INSERT INTO soutenances VALUES('298', '9', '30', '0', '23', '8');
INSERT INTO soutenances VALUES('299', '9', '45', '0', '20', '2');
INSERT INTO soutenances VALUES('300', '11', '30', '0', '20', '3');
INSERT INTO soutenances VALUES('301', '11', '30', '0', '20', '5');
INSERT INTO soutenances VALUES('302', '11', '0', '0', '20', '5');
INSERT INTO soutenances VALUES('303', '11', '30', '0', '20', '2');
INSERT INTO soutenances VALUES('304', '15', '0', '0', '21', '5');
INSERT INTO soutenances VALUES('305', '11', '0', '0', '21', '5');
INSERT INTO soutenances VALUES('306', '10', '0', '0', '21', '5');
INSERT INTO soutenances VALUES('307', '14', '0', '0', '21', '5');
INSERT INTO soutenances VALUES('308', '10', '0', '0', '21', '3');
INSERT INTO soutenances VALUES('309', '11', '0', '0', '21', '3');
INSERT INTO soutenances VALUES('310', '14', '0', '0', '21', '3');
INSERT INTO soutenances VALUES('311', '15', '0', '0', '21', '3');
INSERT INTO soutenances VALUES('312', '14', '0', '0', '22', '2');
INSERT INTO soutenances VALUES('313', '15', '0', '0', '22', '2');
INSERT INTO soutenances VALUES('314', '15', '0', '0', '21', '4');
INSERT INTO soutenances VALUES('315', '16', '0', '0', '21', '4');
INSERT INTO soutenances VALUES('316', '14', '0', '0', '21', '4');
INSERT INTO soutenances VALUES('317', '10', '0', '0', '22', '2');
INSERT INTO soutenances VALUES('318', '11', '0', '0', '22', '2');
INSERT INTO soutenances VALUES('319', '15', '0', '0', '22', '4');
INSERT INTO soutenances VALUES('320', '14', '0', '0', '22', '4');
INSERT INTO soutenances VALUES('321', '10', '0', '0', '22', '4');
INSERT INTO soutenances VALUES('322', '11', '0', '0', '22', '4');
INSERT INTO soutenances VALUES('323', '11', '0', '0', '22', '3');
INSERT INTO soutenances VALUES('336', '9', '0', '0', '24', '5');
INSERT INTO soutenances VALUES('325', '14', '0', '0', '22', '3');
INSERT INTO soutenances VALUES('326', '10', '0', '0', '22', '3');
INSERT INTO soutenances VALUES('327', '10', '0', '0', '22', '5');
INSERT INTO soutenances VALUES('328', '11', '0', '0', '22', '5');
INSERT INTO soutenances VALUES('329', '14', '0', '0', '22', '5');
INSERT INTO soutenances VALUES('330', '15', '0', '0', '22', '5');
INSERT INTO soutenances VALUES('331', '14', '0', '0', '21', '2');
INSERT INTO soutenances VALUES('332', '11', '0', '0', '21', '2');
INSERT INTO soutenances VALUES('333', '10', '0', '0', '21', '2');
INSERT INTO soutenances VALUES('334', '15', '0', '0', '21', '2');
INSERT INTO soutenances VALUES('335', '16', '0', '0', '21', '2');
INSERT INTO soutenances VALUES('338', '14', '0', '0', '25', '6');
INSERT INTO soutenances VALUES('339', '16', '0', '0', '28', '5');
INSERT INTO soutenances VALUES('340', '14', '0', '0', '28', '5');
INSERT INTO soutenances VALUES('341', '11', '0', '0', '28', '4');
INSERT INTO soutenances VALUES('342', '15', '0', '0', '28', '5');
INSERT INTO soutenances VALUES('343', '10', '0', '0', '28', '5');
INSERT INTO soutenances VALUES('344', '11', '0', '0', '28', '5');
INSERT INTO soutenances VALUES('345', '14', '0', '0', '28', '4');
INSERT INTO soutenances VALUES('346', '15', '0', '0', '28', '4');
INSERT INTO soutenances VALUES('347', '16', '0', '0', '28', '4');
INSERT INTO soutenances VALUES('385', '11', '0', '0', '28', '1');
INSERT INTO soutenances VALUES('349', '15', '0', '0', '28', '3');
INSERT INTO soutenances VALUES('380', '15', '0', '0', '28', '1');
INSERT INTO soutenances VALUES('351', '10', '0', '0', '28', '2');
INSERT INTO soutenances VALUES('352', '11', '0', '0', '28', '2');
INSERT INTO soutenances VALUES('353', '15', '0', '0', '28', '2');
INSERT INTO soutenances VALUES('354', '14', '0', '0', '28', '2');
INSERT INTO soutenances VALUES('355', '16', '0', '0', '28', '2');
INSERT INTO soutenances VALUES('366', '16', '0', '0', '28', '3');
INSERT INTO soutenances VALUES('357', '9', '0', '0', '28', '5');
INSERT INTO soutenances VALUES('365', '14', '0', '0', '28', '3');
INSERT INTO soutenances VALUES('364', '11', '0', '0', '28', '3');
INSERT INTO soutenances VALUES('360', '10', '0', '0', '28', '3');
INSERT INTO soutenances VALUES('361', '9', '0', '0', '28', '3');
INSERT INTO soutenances VALUES('388', '16', '0', '0', '28', '1');
INSERT INTO soutenances VALUES('363', '14', '0', '0', '28', '1');
INSERT INTO soutenances VALUES('389', '11', '30', '0', '26', '2');
INSERT INTO soutenances VALUES('393', '10', '50', '0', '26', '2');
INSERT INTO soutenances VALUES('394', '10', '20', '0', '26', '2');
INSERT INTO soutenances VALUES('395', '11', '30', '0', '26', '3');
INSERT INTO soutenances VALUES('397', '10', '50', '0', '26', '3');
INSERT INTO soutenances VALUES('398', '10', '20', '0', '26', '3');
INSERT INTO soutenances VALUES('399', '11', '30', '0', '26', '4');
INSERT INTO soutenances VALUES('400', '10', '20', '0', '26', '4');
INSERT INTO soutenances VALUES('401', '10', '50', '0', '26', '4');
INSERT INTO soutenances VALUES('402', '11', '30', '0', '26', '5');
INSERT INTO soutenances VALUES('404', '10', '50', '0', '26', '5');
INSERT INTO soutenances VALUES('406', '10', '20', '0', '26', '5');
INSERT INTO soutenances VALUES('407', '10', '50', '0', '26', '1');
INSERT INTO soutenances VALUES('408', '11', '30', '0', '26', '1');
INSERT INTO soutenances VALUES('410', '14', '0', '0', '26', '2');
INSERT INTO soutenances VALUES('412', '14', '30', '0', '26', '2');
INSERT INTO soutenances VALUES('414', '15', '10', '0', '26', '2');
INSERT INTO soutenances VALUES('416', '10', '20', '0', '27', '2');
INSERT INTO soutenances VALUES('418', '10', '50', '0', '27', '2');
INSERT INTO soutenances VALUES('419', '11', '30', '0', '27', '2');
INSERT INTO soutenances VALUES('421', '15', '10', '0', '26', '3');
INSERT INTO soutenances VALUES('422', '15', '40', '0', '26', '3');
INSERT INTO soutenances VALUES('423', '14', '30', '0', '26', '3');
INSERT INTO soutenances VALUES('424', '14', '0', '0', '26', '3');
INSERT INTO soutenances VALUES('426', '9', '30', '0', '26', '1');
INSERT INTO soutenances VALUES('428', '10', '0', '0', '26', '1');
INSERT INTO soutenances VALUES('429', '14', '30', '0', '26', '4');
INSERT INTO soutenances VALUES('430', '15', '10', '0', '26', '4');
INSERT INTO soutenances VALUES('432', '14', '0', '0', '26', '4');
INSERT INTO soutenances VALUES('433', '11', '30', '0', '27', '3');
INSERT INTO soutenances VALUES('434', '11', '30', '1', '27', '5');
INSERT INTO soutenances VALUES('436', '11', '0', '0', '27', '5');
INSERT INTO soutenances VALUES('437', '10', '0', '0', '31', '6');
INSERT INTO soutenances VALUES('438', '9', '0', '0', '32', '3');
INSERT INTO soutenances VALUES('439', '9', '30', '0', '32', '3');
INSERT INTO soutenances VALUES('440', '14', '0', '0', '32', '3');
INSERT INTO soutenances VALUES('441', '14', '30', '0', '32', '3');
INSERT INTO soutenances VALUES('442', '10', '10', '0', '32', '2');
INSERT INTO soutenances VALUES('443', '10', '40', '0', '32', '2');
INSERT INTO soutenances VALUES('444', '9', '0', '0', '32', '2');
INSERT INTO soutenances VALUES('445', '9', '30', '0', '32', '2');
INSERT INTO soutenances VALUES('446', '9', '50', '0', '32', '5');
INSERT INTO soutenances VALUES('447', '10', '20', '0', '32', '5');
INSERT INTO soutenances VALUES('448', '11', '0', '0', '32', '5');
INSERT INTO soutenances VALUES('449', '9', '20', '0', '33', '3');
INSERT INTO soutenances VALUES('450', '14', '0', '0', '32', '5');
INSERT INTO soutenances VALUES('451', '10', '40', '0', '32', '3');
INSERT INTO soutenances VALUES('452', '10', '10', '0', '32', '3');
INSERT INTO soutenances VALUES('453', '14', '0', '0', '32', '2');
INSERT INTO soutenances VALUES('454', '14', '30', '0', '32', '2');
INSERT INTO soutenances VALUES('455', '14', '0', '0', '32', '1');
INSERT INTO soutenances VALUES('456', '14', '30', '0', '32', '1');
INSERT INTO soutenances VALUES('457', '15', '0', '0', '33', '1');
INSERT INTO soutenances VALUES('458', '9', '0', '0', '33', '1');
INSERT INTO soutenances VALUES('459', '10', '0', '0', '33', '1');
INSERT INTO soutenances VALUES('460', '16', '0', '0', '33', '1');
INSERT INTO soutenances VALUES('461', '14', '0', '0', '33', '1');
INSERT INTO soutenances VALUES('462', '11', '0', '0', '33', '1');
INSERT INTO soutenances VALUES('463', '10', '0', '0', '33', '5');
INSERT INTO soutenances VALUES('464', '11', '0', '0', '33', '5');
INSERT INTO soutenances VALUES('465', '14', '0', '0', '33', '5');
INSERT INTO soutenances VALUES('466', '15', '0', '0', '33', '5');
INSERT INTO soutenances VALUES('467', '10', '0', '0', '34', '6');
INSERT INTO soutenances VALUES('468', '10', '0', '0', '33', '2');
INSERT INTO soutenances VALUES('469', '11', '0', '0', '33', '2');
INSERT INTO soutenances VALUES('470', '10', '0', '0', '33', '3');
INSERT INTO soutenances VALUES('471', '11', '0', '0', '33', '3');
INSERT INTO soutenances VALUES('472', '14', '0', '0', '33', '2');
INSERT INTO soutenances VALUES('473', '15', '0', '0', '33', '2');
INSERT INTO soutenances VALUES('474', '16', '0', '0', '33', '2');
INSERT INTO soutenances VALUES('475', '14', '0', '0', '33', '3');
INSERT INTO soutenances VALUES('476', '15', '0', '0', '33', '3');
INSERT INTO soutenances VALUES('477', '14', '0', '0', '33', '4');
INSERT INTO soutenances VALUES('478', '15', '0', '0', '33', '4');
INSERT INTO soutenances VALUES('479', '16', '0', '0', '33', '4');
INSERT INTO soutenances VALUES('480', '10', '0', '0', '33', '8');
INSERT INTO soutenances VALUES('481', '11', '0', '0', '33', '8');
INSERT INTO soutenances VALUES('482', '14', '0', '0', '33', '8');
INSERT INTO soutenances VALUES('483', '15', '0', '0', '33', '8');

-- -----------------------------
-- insertions dans la table sujetdestage
-- -----------------------------
INSERT INTO sujetdestage VALUES('297', '326_GIROD_Quentin_18-01-2016_23H04min53.pdf', '1', '0', '326', '26');
INSERT INTO sujetdestage VALUES('296', '327_GOMES_Alexandre_11-01-2016_10H52min41.pdf', '1', '0', '327', '26');
INSERT INTO sujetdestage VALUES('295', '324_CROUILLERE_Kevin_30-11-2015_21H17min12.pdf', '1', '0', '324', '26');
INSERT INTO sujetdestage VALUES('292', '320_AYDIN_Emre_12-11-2015_15H54min56.pdf', '1', '0', '320', '26');
INSERT INTO sujetdestage VALUES('293', '331_LE PEN_Amandine_12-11-2015_21H17min49.pdf', '1', '0', '331', '26');
INSERT INTO sujetdestage VALUES('294', '347_CARTIER_Pierre_30-11-2015_11H48min44.pdf', '1', '0', '347', '27');
INSERT INTO sujetdestage VALUES('291', 'dzedezd', '0', '0', '339', '24');

-- -----------------------------
-- insertions dans la table taches
-- -----------------------------
INSERT INTO taches VALUES('2', 'DÃ©finir les dates (soutenances, rÃ©unions)', 'Finie', '3', '2015-09-08');
INSERT INTO taches VALUES('3', 'PrÃ©parer le site (pages et base de donnÃ©es)', 'Finie', '0', '2015-09-15');
INSERT INTO taches VALUES('4', 'Mail informations aux enseignants', 'Pas fait', '0', '2016-02-16');
INSERT INTO taches VALUES('5', 'Mail attributions stagiaires M2', 'Pas fait', '0', '2016-03-02');
INSERT INTO taches VALUES('6', 'Mail attributions stagiaires M1', 'Pas fait', '0', '2016-04-20');
INSERT INTO taches VALUES('7', 'Mail relecture CV stagiaires', 'Finie', '0', '2015-10-06');
INSERT INTO taches VALUES('8', 'RÃ©union informations M2', 'Finie', '2', '2015-09-08');
INSERT INTO taches VALUES('9', 'RÃ©union informations M1', 'Finie', '2', '2015-09-08');
INSERT INTO taches VALUES('11', 'Mail relance entreprises', 'Pas fait', '0', '2016-02-29');
INSERT INTO taches VALUES('12', 'Mail bilan recherche M1', 'Pas fait', '5', '2016-03-09');
INSERT INTO taches VALUES('16', 'Affichage du planning dans le hall', 'Pas fait', '0', '2016-06-26');
INSERT INTO taches VALUES('13', 'Mail soutenances M1 et M2', 'Pas fait', '0', '2016-06-02');
INSERT INTO taches VALUES('14', 'Mail rappel soutenances rÃ©fÃ©rents M1 + fiche soutenance', 'Pas fait', '0', '2016-06-22');
INSERT INTO taches VALUES('15', 'Mail rappel soutenances rÃ©fÃ©rents M2', 'Pas fait', '0', '2016-08-25');
INSERT INTO taches VALUES('21', 'Envoyer fiche Ã©valuation stagiaire par les entreprises', 'Pas fait', '0', '2016-06-16');
INSERT INTO taches VALUES('18', 'TÃ¢che test exÃ©cution daemon', 'Pas fait', '0', '2015-09-01');
INSERT INTO taches VALUES('19', 'Bilan recherche stage mi-parcours M2', 'Finie', '0', '2015-12-06');
INSERT INTO taches VALUES('20', 'Bilan recherche stage mi-parcours M1', 'En cours', '0', '2016-01-05');

-- -----------------------------
-- insertions dans la table theme_destage
-- -----------------------------
INSERT INTO theme_destage VALUES('2', 'COBOL', '9');
INSERT INTO theme_destage VALUES('3', 'C++', '18');
INSERT INTO theme_destage VALUES('4', 'ASSEMBLEUR', '11');
INSERT INTO theme_destage VALUES('5', 'ANDROID', '4');
INSERT INTO theme_destage VALUES('6', 'JEE', '22');
INSERT INTO theme_destage VALUES('7', 'DELPHI', '17');
INSERT INTO theme_destage VALUES('8', 'PHP5', '25');
INSERT INTO theme_destage VALUES('9', 'javascript', '1');
INSERT INTO theme_destage VALUES('10', 'pomme', '16');
INSERT INTO theme_destage VALUES('11', 'pomme', '16');
INSERT INTO theme_destage VALUES('12', 'pomme', '10');
INSERT INTO theme_destage VALUES('13', 'pomme', '8');
INSERT INTO theme_destage VALUES('14', 'pomme', '29');
INSERT INTO theme_destage VALUES('15', 'pomme', '28');
INSERT INTO theme_destage VALUES('16', 'pomme', '6');
INSERT INTO theme_destage VALUES('17', 'pomme', '7');
INSERT INTO theme_destage VALUES('18', 'pomme', '22');

-- -----------------------------
-- insertions dans la table theme_offredestage
-- -----------------------------
INSERT INTO theme_offredestage VALUES('9', '356');
INSERT INTO theme_offredestage VALUES('9', '353');
INSERT INTO theme_offredestage VALUES('9', '351');
INSERT INTO theme_offredestage VALUES('9', '357');
INSERT INTO theme_offredestage VALUES('9', '368');
INSERT INTO theme_offredestage VALUES('9', '358');
INSERT INTO theme_offredestage VALUES('9', '359');
INSERT INTO theme_offredestage VALUES('9', '355');
INSERT INTO theme_offredestage VALUES('9', '354');
INSERT INTO theme_offredestage VALUES('9', '360');
INSERT INTO theme_offredestage VALUES('9', '374');
INSERT INTO theme_offredestage VALUES('9', '367');
INSERT INTO theme_offredestage VALUES('9', '366');
INSERT INTO theme_offredestage VALUES('9', '372');
INSERT INTO theme_offredestage VALUES('9', '373');
INSERT INTO theme_offredestage VALUES('9', '376');
INSERT INTO theme_offredestage VALUES('9', '370');
INSERT INTO theme_offredestage VALUES('9', '371');
INSERT INTO theme_offredestage VALUES('9', '369');
INSERT INTO theme_offredestage VALUES('9', '365');
INSERT INTO theme_offredestage VALUES('9', '363');
INSERT INTO theme_offredestage VALUES('9', '364');
INSERT INTO theme_offredestage VALUES('9', '362');

-- -----------------------------
-- insertions dans la table type_entreprise
-- -----------------------------
INSERT INTO type_entreprise VALUES('14', 'moyenne', '9');
INSERT INTO type_entreprise VALUES('15', 'basses', '13');
INSERT INTO type_entreprise VALUES('16', 'hautes', '18');
INSERT INTO type_entreprise VALUES('17', 'Enorme', '6');

